import { AdScheduleItem, CampaignObjective, CustomAudience, GeoLocationTargeting, Interest } from '../types';

const API_VERSION = 'v20.0';
const BASE_URL = `https://graph.facebook.com/${API_VERSION}`;

const getCurrencyOffset = (currency: string): number => {
    const zeroDecimalCurrencies = ['VND', 'JPY', 'KRW', 'CLP', 'ISK'];
    if (zeroDecimalCurrencies.includes(currency.toUpperCase())) {
        return 1;
    }
    return 100;
};

export const parseBudgetInput = (budgetInput: string): number => {
    if (typeof budgetInput !== 'string' || !budgetInput) {
        return NaN;
    }
    const budget = budgetInput.toLowerCase().trim().replace(/,/g, '');
    let numericValue: number;

    if (budget.endsWith('k')) {
        numericValue = parseFloat(budget.slice(0, -1)) * 1000;
    } else if (budget.endsWith('tr') || budget.endsWith('m')) {
        numericValue = parseFloat(budget.replace(/tr|m/, '')) * 1000000;
    } else {
        numericValue = parseFloat(budget);
    }
    return numericValue;
};


const convertBudgetForApi = (budgetInput: string | number, currency: string): number => {
    let numericValue: number;

    if (typeof budgetInput === 'number') {
        numericValue = budgetInput;
    } else {
        numericValue = parseBudgetInput(budgetInput);
        if (isNaN(numericValue)) {
            throw new Error(`Invalid budget format: ${budgetInput}. Must be a number, "50k", "1tr", "1m", etc.`);
        }
    }
    
    const offset = getCurrencyOffset(currency);
    return Math.round(numericValue * offset);
};

export const createCampaign = async (adAccountId: string, userAccessToken: string, campaignName: string, objective: CampaignObjective): Promise<string> => {
    const campaignParams = new URLSearchParams({
        name: campaignName,
        objective: objective,
        status: 'PAUSED',
        special_ad_categories: '[]',
        access_token: userAccessToken
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/campaigns`, { method: 'POST', body: campaignParams });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Campaign: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const createAdSet = async (
    adAccountId: string, 
    userAccessToken: string, 
    config: { 
        campaignId: string, 
        name: string, 
        dailyBudget?: string,
        lifetimeBudget?: string,
        startTime?: string,
        endTime?: string,
        adSchedule?: AdScheduleItem[],
        currency: string,
        targeting: any,
        optimizationGoal: string,
        billingEvent?: string,
        conversationCap?: string,
        promotedObject?: { page_id: string },
    }
): Promise<string> => {
    const adSetPayload: any = {
        name: config.name,
        campaign_id: config.campaignId,
        status: 'PAUSED',
        billing_event: config.billingEvent || 'IMPRESSIONS',
        optimization_goal: config.optimizationGoal,
        targeting: JSON.stringify(config.targeting),
        access_token: userAccessToken,
    };

    if (config.lifetimeBudget) {
        const budgetForApi = convertBudgetForApi(config.lifetimeBudget, config.currency);
        adSetPayload.lifetime_budget = String(budgetForApi);
        adSetPayload.bid_strategy = 'LOWEST_COST_WITHOUT_CAP';
        if (config.startTime) adSetPayload.start_time = config.startTime;
        if (config.endTime) adSetPayload.end_time = config.endTime;
        if (config.adSchedule && config.adSchedule.length > 0) {
            adSetPayload.adschedule = JSON.stringify(config.adSchedule);
        }
    } else if (config.dailyBudget) {
        const budgetForApi = convertBudgetForApi(config.dailyBudget, config.currency);
        adSetPayload.daily_budget = String(budgetForApi);
        adSetPayload.bid_strategy = 'LOWEST_COST_WITHOUT_CAP';
    } else {
        throw new Error("A daily or lifetime budget must be provided.");
    }
        
    if (config.conversationCap && parseInt(config.conversationCap, 10) > 0) {
        adSetPayload.conversation_cap = config.conversationCap;
    }

    if (config.optimizationGoal === 'CONVERSATIONS') {
        adSetPayload.destination_type = 'MESSENGER';
    }
    
    if (config.promotedObject) {
        adSetPayload.promoted_object = JSON.stringify(config.promotedObject);
    }
    
    const adSetParams = new URLSearchParams(adSetPayload);

    const response = await fetch(`${BASE_URL}/${adAccountId}/adsets`, { method: 'POST', body: adSetParams });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Set: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const createAdCreativeFromPost = async (
    adAccountId: string,
    objectStoryId: string,
    accessToken: string
): Promise<string> => {
    const params = new URLSearchParams({
        name: `Creative from post ${objectStoryId}`,
        object_story_id: objectStoryId,
        access_token: accessToken,
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Creative: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const createAd = async (
    adAccountId: string, 
    accessToken: string,
    config: { 
        adSetId: string, 
        name: string, 
        creativeId: string 
    }
): Promise<string> => {
    const creativePayload = {
        creative_id: config.creativeId,
    };
    
    const adParams = new URLSearchParams({
        name: config.name,
        adset_id: config.adSetId,
        status: 'PAUSED',
        creative: JSON.stringify(creativePayload),
        access_token: accessToken
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/ads`, { method: 'POST', body: adParams });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

interface SearchResponse<T> {
    data: T[];
}

export const searchInterests = async (query: string, accessToken: string): Promise<Interest[]> => {
    if (!query) return [];
    const url = `${BASE_URL}/search?type=adinterest&q=${encodeURIComponent(query)}&limit=10&access_token=${accessToken}`;
    const response = await fetch(url);
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Không thể tìm kiếm sở thích.');
    }
    const data: SearchResponse<Interest> = await response.json();
    return data.data;
}