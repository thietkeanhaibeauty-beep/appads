import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("Gemini API key is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const model = 'gemini-2.5-flash';

export interface QuickCampaignParseResult {
    campaignName: string;
    ageMin: number;
    ageMax: number;
    gender: 'male' | 'female' | 'all';
    dailyBudget: string;
    latitude?: number;
    longitude?: number;
    interestKeywords: string[];
    postUrl: string;
}

export interface QuickCreativeParseResult {
    campaignName: string;
    ageMin: number;
    ageMax: number;
    gender: 'male' | 'female' | 'all';
    dailyBudget: string;
    latitude?: number;
    longitude?: number;
    interestKeywords: string[];
    adContent: string;
    adHeadline: string;
    greetingText?: string;
    iceBreakerQuestions?: string[];
}


export const parseQuickCampaignPrompt = async (
    promptText: string
): Promise<QuickCampaignParseResult> => {
    if (!API_KEY) {
        throw new Error("Gemini API key is not configured.");
    }
    
    const prompt = `
        Phân tích đoạn văn bản sau đây từ người dùng để lấy thông tin tạo chiến dịch quảng cáo Facebook. **Văn bản có thể là một dòng duy nhất, sử dụng các nhãn như "Tên chiến dịch:", "tuổi:", "vị trí:" để phân tách thông tin.** Trả về kết quả dưới dạng JSON.

        Văn bản của người dùng:
        ---
        ${promptText}
        ---

        Hướng dẫn trích xuất:
        1.  **campaignName**: Tìm và lấy giá trị từ "Tên chiến dịch:".
        2.  **ageMin & ageMax**: Tìm và lấy giá trị từ "Độ tuổi:" hoặc "tuổi:", ví dụ từ "20 40t" hoặc "20-40".
        3.  **gender**: Tìm và lấy giá trị từ "Giới tính:". Chuyển "nữ" thành "female", "nam" thành "male". Nếu không có, mặc định là "all".
        4.  **dailyBudget**: Tìm và lấy giá trị từ "Ngân sách hàng ngày:". Giữ nguyên định dạng như "400k".
        5.  **location**: Tìm "Vị trí:". Nếu có tọa độ dạng "số, số" (VD: 21.39, 106.62), hãy trích xuất số thứ nhất là "latitude" và số thứ hai là "longitude". Bỏ qua các từ "kinh độ", "vĩ độ". Nếu không có tọa độ, để trống.
        6.  **interestKeywords**: Tìm và lấy danh sách sở thích từ "sở thích:", thường được tách nhau bằng dấu phẩy.
        7.  **postUrl**: Tìm "link bài viết:" hoặc một URL Facebook đầy đủ. Chỉ trích xuất phần URL (bắt đầu bằng "http").
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    campaignName: { type: Type.STRING, description: "Campaign name" },
                    ageMin: { type: Type.NUMBER, description: "Minimum age" },
                    ageMax: { type: Type.NUMBER, description: "Maximum age" },
                    gender: { type: Type.STRING, description: "Gender: male, female, or all" },
                    dailyBudget: { type: Type.STRING, description: "Daily budget as a string, e.g., '400k'" },
                    latitude: { type: Type.NUMBER, nullable: true, description: "Latitude of the target location" },
                    longitude: { type: Type.NUMBER, nullable: true, description: "Longitude of the target location" },
                    interestKeywords: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of interest keywords" },
                    postUrl: { type: Type.STRING, description: "URL of the Facebook post" },
                },
                required: ['campaignName', 'ageMin', 'ageMax', 'gender', 'dailyBudget', 'interestKeywords', 'postUrl']
            }
        }
    });
    
    return JSON.parse(response.text) as QuickCampaignParseResult;
};

export const parseQuickCreativePrompt = async (
    promptText: string
): Promise<QuickCreativeParseResult> => {
    if (!API_KEY) {
        throw new Error("Gemini API key is not configured.");
    }

    const prompt = `
        Analyze the following unstructured text provided by a Vietnamese user to extract information for creating a Facebook ad campaign.
        **Crucially, the input might be a single block of text where different sections are separated by numbered prefixes like "1:", "2:", "7:", etc., OR by keyword labels like "Tên chiến dịch:". You must use these prefixes and labels as primary delimiters to identify each piece of information, even if there are no line breaks.**
        Be flexible. Return the result as a JSON object.

        User's Text:
        ---
        ${promptText}
        ---

        Extraction Guidelines:
        1.  **campaignName**: Look for the text following "1: Tên chiến dịch:".
        2.  **ageMin & ageMax**: Look for the text following "2: Độ tuổi:". Extract the two numbers from a range like "20 40t" or "20-40".
        3.  **gender**: Look for "3: Giới tính:". Convert "Nữ" to "female", "Nam" to "male". Default to "all".
        4.  **dailyBudget**: Look for "4: Ngân sách hàng ngày:". Keep the original format (e.g., "400k").
        5.  **location**: Look for "5: Vị trí:". If you find two decimal numbers, extract the first as "latitude" and the second as "longitude".
        6.  **interestKeywords**: Look for "6: Sở thích:". Extract the comma-separated list of interests.
        7.  **adContent**: This is the main ad text, following "7: Nội dung content:". Extract all text until the next numbered prefix (e.g., "8:") or another major keyword label. This content can be multi-line and include hashtags.
        8.  **adHeadline**: This follows "8: Tiêu đề:". Extract the text until the next major label like "Mẫu chào hỏi".
        9.  **greetingText**: Find the text following "Mẫu chào hỏi" or "Câu chào". This is the Page's welcome message. If it contains patterns like "+ full họ tên", "họ tên khách", automatically replace that part with the string "{{full_name}}".
        10. **iceBreakerQuestions**: These are the phrases or questions that follow the greetingText, often without clear separation. Infer the questions based on context. For example, "Còn khuyến mại không? Cho em dk Tư vấn cho em" should become an array like \`["Còn khuyến mại không?", "Cho em dk", "Tư vấn cho em"]\`.

        If a field is missing, use a sensible default or leave it null/empty as appropriate for the JSON schema.
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    campaignName: { type: Type.STRING },
                    ageMin: { type: Type.NUMBER },
                    ageMax: { type: Type.NUMBER },
                    gender: { type: Type.STRING },
                    dailyBudget: { type: Type.STRING },
                    latitude: { type: Type.NUMBER, nullable: true },
                    longitude: { type: Type.NUMBER, nullable: true },
                    interestKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                    adContent: { type: Type.STRING },
                    adHeadline: { type: Type.STRING },
                    greetingText: { type: Type.STRING, nullable: true, description: "The Messenger greeting text. Should contain {{full_name}} if applicable." },
                    iceBreakerQuestions: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true, description: "A list of suggested questions for the user." },
                },
                required: ['campaignName', 'ageMin', 'ageMax', 'gender', 'dailyBudget', 'interestKeywords', 'adContent', 'adHeadline']
            }
        }
    });

    return JSON.parse(response.text) as QuickCreativeParseResult;
};