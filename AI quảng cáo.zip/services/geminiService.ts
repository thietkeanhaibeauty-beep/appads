
import { GoogleGenAI } from "@google/genai";

// Ensure API_KEY is set in the environment variables
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("Gemini API key is not set. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const extractPhoneNumber = async (conversationText: string): Promise<string | null> => {
  if (!API_KEY) {
    return null; // or throw an error
  }
  try {
    const prompt = `Please analyze the following conversation text and extract the first valid Vietnamese mobile phone number you find. A valid number starts with '0' followed by 9 digits (e.g., 09..., 03..., 08...). Return only the phone number itself. If no valid phone number is found, return the exact string "null".

Conversation:
---
${conversationText}
---
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const text = response.text.trim();

    if (text.toLowerCase() === 'null' || text === '') {
      return null;
    }
    
    // Simple validation
    if (/^0\d{9}$/.test(text)) {
        return text;
    }
    
    return null;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return null;
  }
};