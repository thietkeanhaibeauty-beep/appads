import { Conversation, Message, AdAccount, Country, Page, PostPreview, CampaignObjective, Interest, City, GeoLocationTargeting, ReachEstimate, AdScheduleItem, CustomAudience, Insight } from '../types';

const API_VERSION = 'v20.0';
const BASE_URL = `https://graph.facebook.com/${API_VERSION}`;

interface ConversationsResponse {
  data: Conversation[];
  paging?: {
    next?: string;
  };
}

interface MessagesResponse {
  data: Message[];
  paging?: {
    next?: string;
  };
}

// FIX: Export PageDetails to be used in function signatures
export interface PageDetails {
  name: string;
  id: string;
}

interface AdAccountsResponse {
  data: AdAccount[];
  paging?: {
    next?: string;
  };
}

interface SearchResponse<T> {
    data: T[];
}

export const getCurrencyOffset = (currency: string): number => {
    const zeroDecimalCurrencies = ['VND', 'JPY', 'KRW', 'CLP', 'ISK'];
    if (zeroDecimalCurrencies.includes(currency.toUpperCase())) {
        return 1;
    }
    return 100;
};

// NEW: Exportable helper to parse budget strings with abbreviations
export const parseBudgetInput = (budgetInput: string): number => {
    if (typeof budgetInput !== 'string' || !budgetInput) {
        return NaN;
    }
    const budget = budgetInput.toLowerCase().trim().replace(/,/g, '');
    let numericValue: number;

    if (budget.endsWith('k')) {
        numericValue = parseFloat(budget.slice(0, -1)) * 1000;
    } else if (budget.endsWith('tr') || budget.endsWith('m')) {
        numericValue = parseFloat(budget.replace(/tr|m/, '')) * 1000000;
    } else {
        numericValue = parseFloat(budget);
    }
    return numericValue; // Will be NaN if parsing fails
};


// Helper function to convert UI budget string to API-ready integer
const convertBudgetForApi = (budgetInput: string | number, currency: string): number => {
    let numericValue: number;

    if (typeof budgetInput === 'number') {
        numericValue = budgetInput;
    } else {
        numericValue = parseBudgetInput(budgetInput);
        if (isNaN(numericValue)) {
            throw new Error(`Invalid budget format: ${budgetInput}. Must be a number, "50k", "1tr", "1m", etc.`);
        }
    }
    
    const offset = getCurrencyOffset(currency);
    return Math.round(numericValue * offset);
};


// Get list of pages the user manages
export const getManagedPages = async (userAccessToken: string): Promise<Page[]> => {
    try {
        const url = `${BASE_URL}/me/accounts?fields=id,name,access_token&limit=100&access_token=${userAccessToken}`;
        const response = await fetch(url);
        const data = await response.json();
        if (!response.ok) {
            // @ts-ignore
            throw new Error(data.error?.message || "Không thể tải danh sách trang. User Token có thể thiếu quyền 'pages_show_list'.");
        }
        return data.data;
    } catch (err: any) {
         throw new Error(err.message || "Đã xảy ra lỗi không xác định khi tải trang.");
    }
};

// FIX: Add missing function to verify credentials and fetch preview data for login.
export const verifyCredentialsAndFetchPreview = async (pageId: string, accessToken: string): Promise<{ pageDetails: PageDetails; conversations: Conversation[] }> => {
    try {
        // 1. Verify token and get page details
        const pageDetailsUrl = `${BASE_URL}/${pageId}?fields=name,id&access_token=${accessToken}`;
        const pageDetailsResponse = await fetch(pageDetailsUrl);
        const pageDetailsData = await pageDetailsResponse.json();

        if (!pageDetailsResponse.ok) {
            throw new Error(pageDetailsData.error?.message || 'Token không hợp lệ hoặc Page ID sai.');
        }

        const pageDetails: PageDetails = { id: pageDetailsData.id, name: pageDetailsData.name };

        // 2. Fetch a few recent conversations for preview
        const conversations = await getConversations(pageId, accessToken);
        
        return { pageDetails, conversations: conversations.slice(0, 10) };

    } catch (err: any) {
        throw new Error(err.message || "Không thể xác thực. Vui lòng kiểm tra lại thông tin.");
    }
};


export const getConversations = async (pageId: string, accessToken: string): Promise<Conversation[]> => {
  const url = `${BASE_URL}/${pageId}/conversations?fields=participants&access_token=${accessToken}`;
  const response = await fetch(url);
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error.message || 'Failed to fetch conversations');
  }
  const data: ConversationsResponse = await response.json();
  return data.data;
};

export const getMessages = async (conversationId: string, accessToken: string): Promise<Message[]> => {
  const url = `${BASE_URL}/${conversationId}/messages?fields=id,created_time,from,message&limit=100&access_token=${accessToken}`;
  const response = await fetch(url);
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error.message || `Failed to fetch messages for conversation ${conversationId}`);
  }
  const data: MessagesResponse = await response.json();
  return data.data.reverse(); // reverse to show oldest first
};

export const getAdAccounts = async (adsAccessToken: string): Promise<AdAccount[]> => {
  let allAccounts: AdAccount[] = [];
  let url: string | undefined = `${BASE_URL}/me/adaccounts?fields=name,business_name,account_status,currency,timezone_name&limit=100&access_token=${adsAccessToken}`;

  while (url) {
    const response = await fetch(url);
    const data = await response.json(); // Read JSON regardless of status to get error details

    if (!response.ok) {
      const errorMessage = data.error?.message || 'Không thể tải danh sách tài khoản quảng cáo. Token có thể không hợp lệ hoặc thiếu quyền.';
      if (allAccounts.length > 0) {
        // If we fail on a subsequent page, it's better to return what we have than nothing.
        console.error("Failed to fetch next page of ad accounts:", errorMessage);
        break; 
      }
      throw new Error(errorMessage);
    }
    
    if (data.data && Array.isArray(data.data)) {
        allAccounts = allAccounts.concat(data.data);
    }
    
    // The 'next' URL from Facebook's paging object already includes the necessary authentication parameters.
    url = data.paging?.next; 
  }

  return allAccounts;
};

export const searchCountries = async (query: string, accessToken: string): Promise<Country[]> => {
    if (!query) return [];
    const url = `${BASE_URL}/search?type=adgeolocation&location_types=['country']&q=${query}&limit=5&access_token=${accessToken}`;
    const response = await fetch(url);
    if (!response.ok) return [];
    const data: SearchResponse<{name: string, country_code: string}> = await response.json();
    return data.data.map(c => ({ name: c.name, key: c.country_code }));
}

export const searchCities = async (query: string, accessToken: string): Promise<City[]> => {
    if (!query) return [];
    const url = `${BASE_URL}/search?type=adgeolocation&location_types=['city']&q=${encodeURIComponent(query)}&limit=10&access_token=${accessToken}`;
    const response = await fetch(url);
    if (!response.ok) return [];
    const data: SearchResponse<City> = await response.json();
    return data.data;
}

export const getReachEstimate = async (adAccountId: string, accessToken: string, targetingSpec: { geo_locations: GeoLocationTargeting }): Promise<ReachEstimate> => {
    // Only pass geo_locations for a simple estimate, don't need the full spec
    const targetingSpecString = JSON.stringify(targetingSpec);
    const url = `${BASE_URL}/${adAccountId}/reachestimate?targeting_spec=${encodeURIComponent(targetingSpecString)}&access_token=${accessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok) {
        throw new Error(`Lỗi lấy ước tính: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }
    if (!data?.data) {
         throw new Error('API không trả về dữ liệu ước tính.');
    }
    return data.data;
};


export const searchInterests = async (query: string, accessToken: string): Promise<Interest[]> => {
    if (!query) return [];
    const url = `${BASE_URL}/search?type=adinterest&q=${encodeURIComponent(query)}&limit=10&access_token=${accessToken}`;
    const response = await fetch(url);
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Không thể tìm kiếm sở thích.');
    }
    const data: SearchResponse<Interest> = await response.json();
    return data.data;
}

// --- WIZARD API FUNCTIONS ---

export const createCampaign = async (adAccountId: string, userAccessToken: string, campaignName: string, objective: CampaignObjective): Promise<string> => {
    const campaignParams = new URLSearchParams({
        name: campaignName,
        objective: objective,
        status: 'PAUSED',
        special_ad_categories: '[]',
        access_token: userAccessToken
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/campaigns`, { method: 'POST', body: campaignParams });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Campaign: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const createAdSet = async (
    adAccountId: string, 
    userAccessToken: string, 
    config: { 
        campaignId: string, 
        name: string, 
        dailyBudget?: string,
        lifetimeBudget?: string,
        startTime?: string,
        endTime?: string,
        adSchedule?: AdScheduleItem[],
        currency: string,
        targeting: any,
        optimizationGoal: string,
        billingEvent?: string,
        conversationCap?: string,
        promotedObject?: { page_id: string },
    }
): Promise<string> => {
    const adSetPayload: any = {
        name: config.name,
        campaign_id: config.campaignId,
        status: 'PAUSED',
        billing_event: config.billingEvent || 'IMPRESSIONS',
        optimization_goal: config.optimizationGoal,
        targeting: JSON.stringify(config.targeting),
        access_token: userAccessToken,
    };

    if (config.lifetimeBudget) {
        const budgetForApi = convertBudgetForApi(config.lifetimeBudget, config.currency);
        adSetPayload.lifetime_budget = String(budgetForApi);
        adSetPayload.bid_strategy = 'LOWEST_COST_WITHOUT_CAP';
        if (config.startTime) adSetPayload.start_time = config.startTime;
        if (config.endTime) adSetPayload.end_time = config.endTime;
        if (config.adSchedule && config.adSchedule.length > 0) {
            adSetPayload.adschedule = JSON.stringify(config.adSchedule);
        }
    } else if (config.dailyBudget) {
        const budgetForApi = convertBudgetForApi(config.dailyBudget, config.currency);
        adSetPayload.daily_budget = String(budgetForApi);
        adSetPayload.bid_strategy = 'LOWEST_COST_WITHOUT_CAP';
    } else {
        throw new Error("A daily or lifetime budget must be provided.");
    }
        
    if (config.conversationCap && parseInt(config.conversationCap, 10) > 0) {
        adSetPayload.conversation_cap = config.conversationCap;
    }

    if (config.optimizationGoal === 'CONVERSATIONS') {
        adSetPayload.destination_type = 'MESSENGER';
    }
    
    if (config.promotedObject) {
        adSetPayload.promoted_object = JSON.stringify(config.promotedObject);
    }
    
    const adSetParams = new URLSearchParams(adSetPayload);

    const response = await fetch(`${BASE_URL}/${adAccountId}/adsets`, { method: 'POST', body: adSetParams });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Set: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const resolvePostUrlAndValidate = async (
    url: string,
    accessToken: string
): Promise<{ success: boolean; message: string; objectStoryId?: string }> => {
    try {
        const apiUrl = `${BASE_URL}/?id=${encodeURIComponent(url.trim())}&access_token=${accessToken}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (!response.ok || !data.id) {
            throw new Error("Không thể lấy ID từ link này. Vui lòng kiểm tra lại.");
        }
        
        const objectStoryId = data.id; // This is the page_id_post_id
        const postId = objectStoryId.split('_')[1] || objectStoryId;

        return {
            success: true,
            message: `Bài viết hợp lệ. Post ID: ${postId}`,
            objectStoryId: objectStoryId,
        };
    } catch (err: any) {
        return { success: false, message: err.message || "Không thể lấy ID từ link này. Vui lòng kiểm tra lại." };
    }
};

export const createAdCreativeFromPost = async (
    adAccountId: string,
    objectStoryId: string,
    accessToken: string
): Promise<string> => {
    const params = new URLSearchParams({
        name: `Creative from post ${objectStoryId}`,
        object_story_id: objectStoryId,
        access_token: accessToken,
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Creative: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const createAdCreativeForImage = async (
    adAccountId: string,
    accessToken: string,
    config: {
        pageId: string;
        name: string; // Ad name/headline
        message: string;
        imageHash: string;
        ctaType: 'MESSAGE_PAGE' | 'LEARN_MORE' | 'SHOP_NOW';
        ctaLink?: string;
        messageTemplateData?: any;
    }
): Promise<string> => {
    const adHeadline = config.name;
    
    let callToAction;
    let link;

    if (config.ctaType === 'MESSAGE_PAGE') {
        callToAction = {
            type: 'MESSAGE_PAGE',
            value: { app_destination: 'MESSENGER' }
        };
        link = `https://m.me/${config.pageId}`;
    } else { // LEARN_MORE or SHOP_NOW
        if (!config.ctaLink) throw new Error(`Link is required for CTA type ${config.ctaType}`);
        callToAction = {
            type: config.ctaType,
            value: { link: config.ctaLink }
        };
        link = config.ctaLink;
    }

    const objectStorySpec: any = {
        page_id: config.pageId,
        link_data: {
            message: config.message,
            name: adHeadline,
            image_hash: config.imageHash,
            link: link,
            call_to_action: callToAction
        }
    };

    if (config.ctaType === 'MESSAGE_PAGE' && config.messageTemplateData?.page_welcome_message) {
        objectStorySpec.link_data.page_welcome_message = JSON.stringify(config.messageTemplateData.page_welcome_message);
    }

    const params = new URLSearchParams({
        name: `Creative from Image - ${adHeadline}`,
        object_story_spec: JSON.stringify(objectStorySpec),
        access_token: accessToken,
    });

    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Creative ảnh: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};


export const createAdCreativeForVideo = async (
    adAccountId: string,
    accessToken: string,
    config: {
        pageId: string;
        title: string; // Video title, used as headline
        message: string;
        videoId: string;
        thumbnailUrl: string; // <-- NEW
        ctaType: 'MESSAGE_PAGE' | 'LEARN_MORE' | 'SHOP_NOW';
        ctaLink?: string;
        messageTemplateData?: any;
    }
): Promise<string> => {
    const adHeadline = config.title;

    let callToAction;
    
    if (config.ctaType === 'MESSAGE_PAGE') {
        callToAction = {
            type: 'MESSAGE_PAGE',
            value: { app_destination: 'MESSENGER' }
        };
    } else { // LEARN_MORE or SHOP_NOW
        if (!config.ctaLink) throw new Error(`Link is required for CTA type ${config.ctaType}`);
        callToAction = {
            type: config.ctaType,
            value: { link: config.ctaLink }
        };
    }

    const objectStorySpec: any = {
        page_id: config.pageId,
        video_data: { 
            message: config.message,
            title: adHeadline,
            video_id: config.videoId,
            image_url: config.thumbnailUrl,
            call_to_action: callToAction
        }
    };

    if (config.ctaType === 'MESSAGE_PAGE' && config.messageTemplateData?.page_welcome_message) {
        objectStorySpec.video_data.page_welcome_message = JSON.stringify(config.messageTemplateData.page_welcome_message);
    }

    const params = new URLSearchParams({
        name: `Creative from Video - ${adHeadline}`,
        object_story_spec: JSON.stringify(objectStorySpec),
        access_token: accessToken,
    });

    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Creative video: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

export const createAd = async (
    adAccountId: string, 
    accessToken: string,
    config: { 
        adSetId: string, 
        name: string, 
        creativeId: string 
    }
): Promise<string> => {
    const creativePayload = {
        creative_id: config.creativeId,
    };
    
    const adParams = new URLSearchParams({
        name: config.name,
        adset_id: config.adSetId,
        status: 'PAUSED',
        creative: JSON.stringify(creativePayload),
        access_token: accessToken
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/ads`, { method: 'POST', body: adParams });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};


// --- FIELD VALIDATION FUNCTIONS (for debugging) ---

export const getPageDetails = async (pageId: string, accessToken: string): Promise<{ id:string, name: string }> => {
    const url = `${BASE_URL}/${pageId}?fields=id,name&access_token=${accessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi kiểm tra Page ID: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data;
};

export const validateAdImageHash = async (adAccountId: string, imageHash: string, accessToken: string): Promise<{ hash: string, url: string }> => {
    const hashes = JSON.stringify([imageHash]);
    const url = `${BASE_URL}/${adAccountId}/adimages?hashes=${encodeURIComponent(hashes)}&fields=hash,url&access_token=${accessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok || !data[imageHash] || data[imageHash].hash !== imageHash) {
         throw new Error(`Lỗi kiểm tra Image Hash: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message || 'Hash không hợp lệ hoặc không tìm thấy.'}`);
    }
    return data[imageHash];
}

export const validateCreativeField = async (
    adAccountId: string,
    accessToken: string,
    pageId: string,
    fieldToTest: { link: string } | { call_to_action: any }
): Promise<{ success: boolean }> => {
    const objectStorySpec: any = {
        page_id: pageId,
        link_data: {
            message: "Validation test message.",
        }
    };
    
    if ('link' in fieldToTest) {
        objectStorySpec.link_data.link = fieldToTest.link;
    } else if ('call_to_action' in fieldToTest) {
        // A CTA needs a link to attach to. We'll use the page's FB link as a placeholder.
        objectStorySpec.link_data.link = `https://facebook.com/${pageId}`;
        objectStorySpec.link_data.call_to_action = fieldToTest.call_to_action;
    }

    const params = new URLSearchParams({
        name: `Validation Test - ${Date.now()}`,
        object_story_spec: JSON.stringify(objectStorySpec),
        validate_only: 'true',
        access_token: accessToken,
    });
    
    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();

    if (!response.ok) {
         throw new Error(`Lỗi validation: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }
    
    return data; // Should be { "success": true } on HTTP 200
}

export const validateMessageTemplate = async (
    adAccountId: string,
    accessToken: string,
    pageId: string,
    messageTemplateData: any
): Promise<{ success: boolean }> => {
    if (!messageTemplateData?.page_welcome_message) {
        throw new Error("Payload for validation is missing the 'page_welcome_message' wrapper.");
    }
    // A welcome message needs a base creative to be part of.
    // We'll create a minimal link ad spec for validation.
    const objectStorySpec = {
        page_id: pageId,
        link_data: {
            message: "Validation test for message template.",
            link: `https://facebook.com/${pageId}`, // A valid link is required.
            page_welcome_message: JSON.stringify(messageTemplateData.page_welcome_message),
        }
    };

    const params = new URLSearchParams({
        name: `Validation Test - Message Template - ${Date.now()}`,
        object_story_spec: JSON.stringify(objectStorySpec),
        validate_only: 'true',
        access_token: accessToken,
    });
    
    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();

    if (!response.ok) {
         throw new Error(`Lỗi validation template: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }
    
    return data; // Should be { "success": true } on HTTP 200
}


// --- NEW MEDIA UPLOAD FUNCTIONS ---

/**
 * Uploads an image to the ad account and returns its hash and URL.
 * @param adAccountId - The ID of the ad account.
 * @param accessToken - The user's access token.
 * @param file - The image file to upload.
 * @returns The hash and URL of the uploaded image.
 */
export const uploadAdImage = async (
    adAccountId: string,
    accessToken: string,
    file: File
): Promise<{ hash: string; url: string }> => {
    // 1. Create FormData to handle multipart/form-data upload.
    const formData = new FormData();
    formData.append('access_token', accessToken);
    formData.append('filename', file); // The API expects the file data under the 'filename' key.

    // 2. Make the POST request to the adimages endpoint.
    const response = await fetch(`${BASE_URL}/${adAccountId}/adimages`, {
        method: 'POST',
        body: formData,
    });

    const data = await response.json();

    // 3. Handle any API errors.
    if (!response.ok) {
        throw new Error(`Lỗi upload ảnh: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }

    // 4. Extract the hash and URL from the response and return it.
    // The response structure is { images: { 'original_filename.jpg': { hash: '...', url: '...' } } }
    const firstImageKey = Object.keys(data.images)[0];
    const imageData = data.images[firstImageKey];
    
    if (!imageData?.hash || !imageData?.url) {
        throw new Error("Không thể lấy image_hash hoặc url từ phản hồi của API.");
    }
    return { hash: imageData.hash, url: imageData.url };
};


/**
 * Fetches available thumbnails for a given video ID.
 * @param videoId - The ID of the video.
 * @param accessToken - The user's access token.
 * @returns The URL of the first available thumbnail.
 */
export const getVideoThumbnails = async (videoId: string, accessToken: string): Promise<string> => {
    const url = `${BASE_URL}/${videoId}/thumbnails?access_token=${accessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok) {
        throw new Error(`Lỗi lấy thumbnail: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }
    if (!data.data || data.data.length === 0 || !data.data[0].uri) {
        throw new Error("Video chưa có thumbnail. Vui lòng đợi hoặc upload thủ công.");
    }
    return data.data[0].uri;
};

/**
 * Uploads a video to the ad account and returns its ID.
 * @param adAccountId - The ID of the ad account.
 * @param accessToken - The user's access token.
 * @param file - The video file to upload.
 * @returns The ID of the uploaded video.
 */
export const uploadAdVideo = async (
    adAccountId: string,
    accessToken: string,
    file: File
): Promise<string> => {
    // 1. Create FormData.
    const formData = new FormData();
    formData.append('access_token', accessToken);
    formData.append('file', file); // For videos, the API expects the file data under the 'file' key.

    // 2. Make the POST request to the separate graph-video endpoint.
    const response = await fetch(`https://graph-video.facebook.com/${API_VERSION}/${adAccountId}/advideos`, {
        method: 'POST',
        body: formData,
    });

    const data = await response.json();

    // 3. Handle API errors.
    if (!response.ok) {
        throw new Error(`Lỗi upload video: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }

    // 4. Return the video ID from the response.
    if (!data.id) {
        throw new Error("Không thể lấy video_id từ phản hồi của API.");
    }
    return data.id;
};

export const uploadGreetingImage = async (pageId: string, pageAccessToken: string, file: File): Promise<{ attachment_id: string }> => {
  const formData = new FormData();
  formData.append('access_token', pageAccessToken);
  formData.append('type', 'image');
  formData.append('filedata', file);

  const response = await fetch(`${BASE_URL}/${pageId}/message_attachments`, { method: 'POST', body: formData });
  const data = await response.json();

  if (!response.ok) throw new Error(data.error?.message || "Lỗi upload greeting image");
  
  if (!data.attachment_id) {
      throw new Error("API did not return an attachment_id for the greeting image.");
  }

  return { attachment_id: data.attachment_id };
};

export const uploadGreetingVideo = async (pageId: string, pageAccessToken: string, file: File): Promise<{ attachment_id: string }> => {
  const formData = new FormData();
  formData.append('access_token', pageAccessToken);
  formData.append('type', 'video');
  formData.append('filedata', file);

  const response = await fetch(`${BASE_URL}/${pageId}/message_attachments`, { method: 'POST', body: formData });
  const data = await response.json();

  if (!response.ok) throw new Error(data.error?.message || "Lỗi upload greeting video");
    if (!data.attachment_id) {
        throw new Error("Không thể lấy attachment_id từ phản hồi của API.");
    }

  return { attachment_id: data.attachment_id };
};

// --- NEW AUDIENCE CREATION FUNCTIONS ---

/**
 * Normalizes a Vietnamese phone number to E.164 format for hashing.
 * Removes non-digit characters and replaces leading '0' with '84'.
 * @param phoneNumber - The raw phone number string.
 * @returns The normalized phone number string.
 */
const normalizePhoneNumber = (phoneNumber: string): string => {
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    if (digitsOnly.startsWith('0')) {
        return `84${digitsOnly.substring(1)}`;
    }
    if (digitsOnly.startsWith('84')) {
        return digitsOnly;
    }
    // If it's a number but doesn't start with 0 or 84, we can't be sure, but we'll prepend 84 as the most likely case.
    if (digitsOnly.length >= 9) {
        return `84${digitsOnly}`;
    }
    return digitsOnly; // Return as is if it's not a recognizable format
};


/**
 * Hashes a string using SHA-256.
 * @param data - The string to hash.
 * @returns The SHA-256 hash as a hex string.
 */
const hashDataSHA256 = async (data: string): Promise<string> => {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex;
};

/**
 * Creates a new custom audience container.
 * @param adAccountId - The ad account ID.
 * @param accessToken - The user's access token.
 * @param name - The name for the new audience.
 * @param description - An optional description.
 * @returns The ID of the newly created custom audience.
 */
export const createCustomAudience = async (
    adAccountId: string,
    accessToken: string,
    name: string,
    description: string
): Promise<string> => {
    const audienceParams = new URLSearchParams({
        name: name,
        description: description,
        subtype: 'CUSTOM',
        customer_file_source: 'USER_PROVIDED_ONLY',
        access_token: accessToken,
    });
    
    const response = await fetch(`${BASE_URL}/${adAccountId}/customaudiences`, { method: 'POST', body: audienceParams });
    const data = await response.json();

    if (!response.ok) {
        throw new Error(`Lỗi tạo đối tượng: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }
    
    if (!data.id) {
        throw new Error("API không trả về ID đối tượng.");
    }

    return data.id;
};

/**
 * Adds users to a custom audience by hashing their phone numbers.
 * @param audienceId - The ID of the custom audience.
 * @param accessToken - The user's access token.
 * @param phoneNumbers - An array of raw phone number strings.
 * @returns The result from the Facebook API.
 */
export const addUsersToCustomAudience = async (
    audienceId: string,
    accessToken: string,
    phoneNumbers: string[]
): Promise<any> => {
    // 1. Normalize and filter valid-looking numbers
    const normalizedNumbers = phoneNumbers
        .map(normalizePhoneNumber)
        .filter(p => p.startsWith('84') && p.length >= 11);

    if (normalizedNumbers.length === 0) {
        throw new Error("Không tìm thấy số điện thoại hợp lệ để thêm vào đối tượng.");
    }
    
    // 2. Hash all numbers
    const hashedNumbers = await Promise.all(
        normalizedNumbers.map(p => hashDataSHA256(p))
    );

    // 3. Prepare payload in batches of 10,000
    const BATCH_SIZE = 10000;
    const batches = [];
    for (let i = 0; i < hashedNumbers.length; i += BATCH_SIZE) {
        batches.push(hashedNumbers.slice(i, i + BATCH_SIZE));
    }
    
    let lastResponseData = null;

    for (const batch of batches) {
        const payload = {
            schema: ['PHONE'],
            data: batch.map(hash => [hash]), // API expects an array of arrays
        };

        const userParams = new URLSearchParams({
            payload: JSON.stringify(payload),
            access_token: accessToken,
        });
        
        const response = await fetch(`${BASE_URL}/${audienceId}/users`, { method: 'POST', body: userParams });
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(`Lỗi thêm người dùng: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
        }
        lastResponseData = data;
    }
    
    return lastResponseData;
};

/**
 * Creates a custom audience of people who have messaged a Facebook Page.
 * @param adAccountId - The ad account ID.
 * @param accessToken - The user's access token.
 * @param name - The name for the new audience.
 * @param description - An optional description.
 * @param pageId - The ID of the Facebook Page.
 * @param retentionDays - The number of days to keep users in the audience (max 365).
 * @returns The ID of the newly created custom audience.
 */
export const createPageMessengersAudience = async (
    adAccountId: string,
    accessToken: string,
    name: string,
    description: string,
    pageId: string,
    retentionDays: number
): Promise<string> => {
    
    const retentionSeconds = retentionDays * 24 * 60 * 60;
    const rule = {
        inclusions: {
            operator: "or",
            rules: [{
                event_sources: [{
                    id: pageId,
                    type: "page"
                }],
                retention_seconds: retentionSeconds,
                filter: {
                    operator: "and",
                    filters: [{
                        field: "event",
                        operator: "eq",
                        value: "page_messaged"
                    }]
                }
            }]
        }
    };

    const formData = new FormData();
    formData.append('name', name);
    formData.append('description', description);
    formData.append('rule', JSON.stringify(rule));
    formData.append('prefill', 'true');
    formData.append('access_token', accessToken);

    const response = await fetch(`${BASE_URL}/${adAccountId}/customaudiences`, { 
        method: 'POST', 
        body: formData 
    });
    const data = await response.json();

    if (!response.ok) {
        throw new Error(`Lỗi tạo đối tượng tương tác: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }

    if (!data.id) {
        throw new Error("API không trả về ID đối tượng.");
    }

    return data.id;
};

/**
 * Fetches existing custom audiences that can be used as a source for lookalikes.
 */
export const getCustomAudiences = async (adAccountId: string, accessToken: string): Promise<CustomAudience[]> => {
    const filtering = JSON.stringify([{ field: "subtype", operator: "IN", value: ["CUSTOM", "ENGAGEMENT", "WEBSITE", "MOBILE_APP", "OFFLINE_CONVERSION"] }]);
    const url = `${BASE_URL}/${adAccountId}/customaudiences?fields=id,name&limit=200&filtering=${encodeURIComponent(filtering)}&access_token=${accessToken}`;
    
    const response = await fetch(url);
    const data = await response.json();

    if (!response.ok) {
        throw new Error(`Lỗi tải đối tượng nguồn: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }

    return data.data || [];
};

/**
 * Creates a lookalike audience.
 */
export const createLookalikeAudience = async (
    adAccountId: string,
    accessToken: string,
    name: string,
    description: string,
    sourceAudienceId: string,
    countryCode: string,
    ratio: number // e.g., 1 for 1%
): Promise<string> => {
    const lookalikeSpec = {
        type: 'similarity',
        country: countryCode.toUpperCase(),
        ratio: ratio / 100, // API expects 0.01 for 1%
    };

    const params = new URLSearchParams({
        name: name,
        description: description,
        subtype: 'LOOKALIKE',
        origin_audience_id: sourceAudienceId,
        lookalike_spec: JSON.stringify(lookalikeSpec),
        access_token: accessToken,
    });

    const response = await fetch(`${BASE_URL}/${adAccountId}/customaudiences`, {
        method: 'POST',
        body: params,
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(`Lỗi tạo đối tượng tương tự: (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    }

    if (!data.id) {
        throw new Error("API không trả về ID đối tượng tương tự.");
    }

    return data.id;
};

// --- NEW INSIGHTS FUNCTIONS ---

export const getInsights = async (
  adAccountId: string,
  accessToken: string,
  currency: string,
  timeRange: { since: string; until: string },
  apiFields: string[]
): Promise<Insight[]> => {
  // Always fetch these for logic, merging, etc.
  const essentialFields = [
    'campaign_name', 'adset_name', 'ad_name',
    'campaign_id', 'adset_id', 'ad_id'
  ];
  const allFields = [...new Set([...essentialFields, ...apiFields])];
  const insightsUrl = `${BASE_URL}/${adAccountId}/insights?level=ad&fields=${allFields.join(',')}&time_range=${JSON.stringify(timeRange)}&limit=500&access_token=${accessToken}`;

  const insightsResponse = await fetch(insightsUrl);
  const insightsData = await insightsResponse.json();

  if (!insightsResponse.ok) {
    throw new Error(insightsData.error?.message || 'Failed to fetch insights.');
  }

  const baseInsights: Omit<Insight, 'status' | 'budget'>[] = insightsData.data || [];

  if (baseInsights.length === 0) {
    return [];
  }

  // 2. Collect unique IDs for batch fetching
  const adIds = [...new Set(baseInsights.map(i => i.ad_id))];
  const adsetIds = [...new Set(baseInsights.map(i => i.adset_id))];

  // 3. Batch fetch budgets (from adsets) and statuses (from ads) in parallel
  const [budgetResponse, statusResponse] = await Promise.all([
    fetch(`${BASE_URL}/?ids=${adsetIds.join(',')}&fields=daily_budget,lifetime_budget&access_token=${accessToken}`),
    fetch(`${BASE_URL}/?ids=${adIds.join(',')}&fields=status,effective_status&access_token=${accessToken}`)
  ]);

  const budgetData = await budgetResponse.json();
  const statusData = await statusResponse.json();

  // 4. Create maps for efficient merging
  const budgetMap = new Map<string, string>();
  if (budgetResponse.ok) {
    const offset = getCurrencyOffset(currency);
    Object.keys(budgetData).forEach(adsetId => {
      const adset = budgetData[adsetId];
      let budgetStr = 'N/A';
      if (adset.daily_budget) {
          budgetStr = `${(parseInt(adset.daily_budget, 10) / offset).toLocaleString('vi-VN')} / ngày`;
      } else if (adset.lifetime_budget) {
          budgetStr = `${(parseInt(adset.lifetime_budget, 10) / offset).toLocaleString('vi-VN')} / trọn đời`;
      }
      budgetMap.set(adsetId, budgetStr);
    });
  }

  const statusMap = new Map<string, Insight['status']>();
  if (statusResponse.ok) {
    Object.keys(statusData).forEach(adId => {
        const ad = statusData[adId];
        statusMap.set(adId, ad.effective_status);
    });
  }

  // 5. Merge all data together
  const finalInsights: Insight[] = baseInsights.map(insight => ({
    ...insight,
    budget: budgetMap.get(insight.adset_id) || 'N/A',
    status: statusMap.get(insight.ad_id) || 'ARCHIVED' // Default to a non-active status if fetch fails
  }));

  return finalInsights;
};

export const updateAdObjectStatus = async (
  objectId: string,
  accessToken: string,
  status: 'ACTIVE' | 'PAUSED'
): Promise<boolean> => {
  const url = `${BASE_URL}/${objectId}`;
  const params = new URLSearchParams({
    status,
    access_token: accessToken,
  });

  const response = await fetch(url, { method: 'POST', body: params });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error?.message || `Failed to update status for ${objectId}.`);
  }

  return data.success === true;
};