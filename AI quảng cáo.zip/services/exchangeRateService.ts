
// To fix the "Failed to fetch" error, which is often a CORS issue, 
// this service now uses a different, more reliable public API 
// with open CORS policies (open.er-api.com).
const API_BASE_URL = 'https://open.er-api.com/v6/latest/USD';

/**
 * Fetches the minimum budget required for an ad account's currency,
 * equivalent to 1 USD.
 * @param targetCurrency The ISO currency code (e.g., 'VND', 'USD').
 * @returns The minimum budget amount in the target currency.
 */
export const getMinBudget = async (targetCurrency: string): Promise<number> => {
    if (targetCurrency === 'USD') {
        return 1;
    }

    try {
        // This API returns all rates against the base currency (USD) in one call.
        const response = await fetch(API_BASE_URL);
        const data = await response.json();

        if (!response.ok || data.result !== 'success' || !data.rates || !data.rates[targetCurrency]) {
            console.warn(`Could not fetch exchange rate for ${targetCurrency}. Defaulting to equivalent of 1 USD.`);
            // Fallback for VND if API fails
            if (targetCurrency === 'VND') return 25000;
            return 1; 
        }
        
        // Round up to a sensible number
        return Math.ceil(data.rates[targetCurrency]);
    } catch (error) {
        console.error('Exchange rate API call failed:', error);
        // Fallback
        if (targetCurrency === 'VND') return 25000;
        return 1;
    }
};