const GRAPH_API_URL = 'https://graph.facebook.com/v20.0/search';

interface InterestResult {
  id: string;
  name: string;
  audience_size: number;
}

interface SearchResult {
  found: boolean;
  message: string;
  interests: InterestResult[];
}

/**
 * Searches for Facebook interests based on a user's keyword.
 * @param keyword The keyword to search for (e.g., "skincare", "spa").
 * @param accessToken The user's access token with advertising permissions.
 */
export async function searchFacebookInterests(keyword: string, accessToken: string): Promise<SearchResult> {
  try {
    const params = new URLSearchParams({
      type: 'adinterest',
      q: keyword,
      limit: '5', // Limit to a max of 5 results for brevity
      access_token: accessToken,
    });

    const response = await fetch(`${GRAPH_API_URL}?${params.toString()}`);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(`Lỗi API Facebook (#${data.error?.code}): ${data.error?.message}`);
    }

    if (!data.data || data.data.length === 0) {
      return {
        found: false,
        message: `❌ Không tìm thấy sở thích nào phù hợp với từ khóa "${keyword}".`,
        interests: []
      };
    }

    return {
      found: true,
      interests: data.data.map((item: any) => ({
        id: item.id,
        name: item.name,
        audience_size: item.audience_size || 0,
      })),
      message: `✅ Tìm thấy các sở thích liên quan đến "${keyword}":`
    };
  } catch (error: any) {
    console.error("Error searching for interests:", error);
    return {
      found: false,
      message: `⚠️ Lỗi khi tìm kiếm sở thích: ${error.message}. Vui lòng thử lại sau.`,
      interests: []
    };
  }
}