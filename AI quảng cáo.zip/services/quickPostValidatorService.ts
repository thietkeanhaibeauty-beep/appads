// services/quickPostValidatorService.ts

const API_VERSION = 'v20.0';
const BASE_URL = `https://graph.facebook.com/${API_VERSION}`;

interface PostDetails {
  postId: string;
  pageId: string;
}

const normalizeUrl = (url: string): string => {
  try {
    const urlObj = new URL(url);
    // remove www, m, web prefixes, query params, and trailing slash
    return `${urlObj.hostname.replace(/^(www|m|web)\./, '')}${urlObj.pathname}`.replace(/\/$/, '');
  } catch (e) {
    // Fallback for non-standard URLs
    return url
      .replace(/^(https?:\/\/)?(www|m|web)\./, '')
      .split('?')[0]
      .replace(/\/$/, '');
  }
};

// ---- Helpers (nội bộ) ----
type UrlNodeHit = { id?: string; permalink?: string; pageName?: string };
type ObjectLookupHit = { id?: string; permalink?: string; fromName?: string; objectId?: string };
type FeedScanHit = { id?: string; pageIdFromSlug?: string; permalink?: string };

const extractObjectId = (input: string): string | undefined => {
  // Gom regex cho posts/videos/reels/photo + query story_fbid/fbid/id
  const m =
    input.match(/(?:posts|videos|reels|reel|photos|story_fbid=|fbid=|id=|\/)(\d{8,})/) ||
    input.match(/([?&])(story_fbid|fbid)=(\d{8,})/);
  if (m) {
    return m[1]?.match(/^\d+$/) ? m[1] : m[3];
  }
  if (/^\d+$/.test(input)) return input;
  return undefined;
};

const getPageIdFromSlug = async (url: string, token: string): Promise<string | undefined> => {
  const slug = url.match(/facebook\.com\/([a-zA-Z0-9.-]+)/)?.[1];
  if (!slug) return undefined;
  const api = `${BASE_URL}/${slug}?fields=id&access_token=${token}`;
  const res = await fetch(api);
  const data = await res.json();
  if (!res.ok || !data?.id) return undefined;
  return data.id as string;
};

// ---- Method 1: URL node (đủ fields, KHÔNG ép phải có "_")
const method1_urlNode = async (input: string, token: string): Promise<UrlNodeHit | null> => {
  try {
    const api = `${BASE_URL}/?id=${encodeURIComponent(
      input
    )}&fields=id,og_object{id,type},permalink_url,from{name,id}&access_token=${token}`;
    const res = await fetch(api);
    const data = await res.json();
    if (!res.ok) return null;

    // data.id có thể là "pageId_postId" hoặc chỉ là số (og_object id)
    const id: string | undefined = data.id || data.og_object?.id;
    if (!id) return null;

    return { id, permalink: data.permalink_url, pageName: data.from?.name };
  } catch (e) {
    console.warn('Method 1 (URL node) error:', e);
    return null;
  }
};

// ---- Method 2: Direct Object lookup (gom regex, lấy thêm permalink_url)
const method2_objectLookup = async (
  input: string,
  token: string
): Promise<ObjectLookupHit | null> => {
  try {
    const objectId = extractObjectId(input);
    if (!objectId) return null;

    const api = `${BASE_URL}/${objectId}?fields=id,permalink_url,from{name,id}&access_token=${token}`;
    const res = await fetch(api);
    const data = await res.json();
    if (!res.ok) {
      // vẫn trả lại objectId để dùng cho các bước sau (feed/composite)
      return { objectId };
    }

    if (!data?.id) return { objectId };

    return {
      id: data.id as string, // có thể là "pageId_postId" hoặc số
      permalink: data.permalink_url,
      fromName: data.from?.name,
      objectId,
    };
  } catch (e) {
    console.warn('Method 2 (Object lookup) error:', e);
    return null;
  }
};

// ---- Method 3: Quét feed (ưu tiên so khớp theo objectId trong permalink; fallback normalize)
const method3_feedScan = async (
  input: string,
  token: string,
  objectId?: string
): Promise<FeedScanHit | null> => {
  try {
    const pageIdFromSlug = await getPageIdFromSlug(input, token);
    if (!pageIdFromSlug) return null;

    const feedApi = `${BASE_URL}/${pageIdFromSlug}/feed?fields=id,permalink_url,from{name}&limit=50&access_token=${token}`;
    const feedRes = await fetch(feedApi);
    const feedData = await feedRes.json();
    if (!feedRes.ok || !Array.isArray(feedData?.data)) return { pageIdFromSlug };

    let matched = null as any;

    // 1) So khớp bằng objectId trong permalink (ổn định nhất)
    if (objectId) {
      matched = feedData.data.find((p: any) => p?.permalink_url?.includes(objectId));
    }

    // 2) Fallback: so khớp normalize tương đối (đề phòng URL lạ format)
    if (!matched) {
      const target = normalizeUrl(input);
      matched = feedData.data.find(
        (p: any) => p.permalink_url && normalizeUrl(p.permalink_url) === target
      );
    }

    if (!matched?.id) return { pageIdFromSlug };

    return { id: matched.id as string, pageIdFromSlug, permalink: matched.permalink_url };
  } catch (e) {
    console.warn('Method 3 (Feed scan) error:', e);
    return null;
  }
};

/**
 * Validates a post ID using a multi-step fallback strategy.
 * @param input The URL or ID of the post.
 * @param pageAccessToken The access token for the page.
 * @returns A promise resolving to a validation result.
 */
export const validatePostId = async (
  input: string,
  pageAccessToken: string
): Promise<{ valid: boolean; postId?: string; pageId?: string; message: string }> => {
  const cleanInput = input?.trim();
  const token = pageAccessToken?.trim();

  if (!cleanInput || !token) {
    return { valid: false, message: '❌ URL hoặc Access Token trống.' };
  }

  try {
    // --- M1: URL node
    const m1 = await method1_urlNode(cleanInput, token);
    if (m1?.id) {
      const idStr = String(m1.id);
      if (idStr.includes('_')) {
        const [pageId, postId] = idStr.split('_');
        return {
          valid: true,
          pageId,
          postId,
          message: `✅ Hợp lệ (URL node). Post ID: ${postId} | Page ID: ${pageId}`,
        };
      }
      // If it's just a number (OG object id), it will be used as objectId later
    }

    // --- M2: Object lookup (gets both id and objectId for later use)
    const m2 = await method2_objectLookup(cleanInput, token);
    const objectId = m2?.objectId || (m1?.id && /^\d+$/.test(m1.id) ? m1.id : undefined) || (m2?.id && /^\d+$/.test(m2.id) ? m2.id : undefined);

    if (m2?.id) {
      const idStr = String(m2.id);
      if (idStr.includes('_')) {
        const [pageId, postId] = idStr.split('_');
        return {
          valid: true,
          pageId,
          postId,
          message: `✅ Hợp lệ (Object lookup). Post ID: ${postId} | Page ID: ${pageId}`,
        };
      }
    }

    // --- M3: Feed scan (using objectId if available)
    const m3 = await method3_feedScan(cleanInput, token, objectId);
    if (m3?.id) {
      const idStr = String(m3.id);
      if (idStr.includes('_')) {
        const [pageId, postId] = idStr.split('_');
        return {
          valid: true,
          pageId,
          postId,
          message: `✅ Hợp lệ (Feed match). Post ID: ${postId} | Page ID: ${pageId}`,
        };
      }
    }

    // --- Composite: if we have pageIdFromSlug (from M3) + objectId (from M2) -> combine them
    if (m3?.pageIdFromSlug && objectId) {
      return {
        valid: true,
        pageId: m3.pageIdFromSlug,
        postId: objectId,
        message: `✅ Hợp lệ (Composite). Post ID: ${objectId} | Page ID: ${m3.pageIdFromSlug}`,
      };
    }

    // Not found
    return {
      valid: false,
      message:
        '❌ Không thể xác thực bài viết. Link/ID sai, bài viết private/ẩn quyền, hoặc token không đủ quyền.',
    };
  } catch (err: any) {
    console.error('validatePostId error:', err);
    return { valid: false, message: `❌ Lỗi API: ${err?.message || 'Không xác định.'}` };
  }
};