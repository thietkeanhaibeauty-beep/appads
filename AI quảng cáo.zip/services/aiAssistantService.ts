
import { GoogleGenAI, Type } from "@google/genai";
import { CampaignObjective, Gender, Country, Interest, CampaignDraft } from '../types';
import * as facebookService from './facebookService';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("Gemini API key is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const model = 'gemini-2.5-flash';

// Helper to map a natural language objective to a Facebook CampaignObjective
const mapSimpleObjectiveToCampaignObjective = (simpleObjective: string): CampaignObjective => {
    const lowerCaseObjective = simpleObjective.toLowerCase();
    if (lowerCaseObjective.includes('message') || lowerCaseObjective.includes('tin nhắn')) {
        return 'MESSAGES';
    }
    if (lowerCaseObjective.includes('engagement') || lowerCaseObjective.includes('tương tác')) {
        return 'OUTCOME_ENGAGEMENT';
    }
    if (lowerCaseObjective.includes('traffic') || lowerCaseObjective.includes('truy cập')) {
        return 'OUTCOME_TRAFFIC';
    }
     if (lowerCaseObjective.includes('lead') || lowerCaseObjective.includes('khách hàng tiềm năng')) {
        return 'LEAD_GENERATION';
    }
    return 'OUTCOME_ENGAGEMENT'; // Sensible default
}

/**
 * Generates a structured campaign draft using Gemini AI based on natural language input.
 * It also validates location and interests using the Facebook Ads API.
 */
export const generateCampaignParameters = async (
    objective: string,
    audience: string,
    adsToken: string
): Promise<Partial<CampaignDraft>> => {

    const prompt = `
        Analyze the following user request for a Facebook ad campaign in Vietnamese. Extract the specified parameters and provide them in a JSON format.

        User Request:
        - Goal: "${objective}"
        - Target Audience: "${audience}"

        Instructions:
        1.  **Audience Analysis**: From the "Target Audience" text, determine the minimum age, maximum age, gender, primary location (country or major city), and a list of 3-5 specific keywords for searching interests.
        2.  **Gender**: If gender is not specified, use "all". If the text implies a gender (e.g., 'phụ nữ', 'chị em'), use 'female'. If it implies 'nam giới', 'anh em', use 'male'.
        3.  **Location**: Infer the location. If a Vietnamese city like 'Hà Nội' or 'TP.HCM' is mentioned, use that. Default to "Vietnam" if not specified.
        4.  **Age**: Provide a reasonable age range if not specified, e.g., 22-50.
        5.  **Interest Keywords**: Provide specific, searchable Vietnamese keywords. For example, if the audience is "people who like skincare", keywords could be "chăm sóc da", "làm đẹp", "mỹ phẩm".
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    ageMin: { type: Type.NUMBER, description: "Minimum target age." },
                    ageMax: { type: Type.NUMBER, description: "Maximum target age." },
                    gender: { type: Type.STRING, description: "Target gender ('male', 'female', or 'all')." },
                    location_query: { type: Type.STRING, description: "The primary location to search for (country or city)." },
                    interest_keywords: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "A list of 3-5 keywords for searching interests on Facebook."
                    }
                }
            }
        }
    });

    const parsedJson = JSON.parse(response.text);

    const generatedObjective = mapSimpleObjectiveToCampaignObjective(objective);

    // Fetch and validate Location using Facebook API
    let location: Country | null = null;
    if (parsedJson.location_query) {
        const locations = await facebookService.searchCountries(parsedJson.location_query, adsToken);
        if (locations.length > 0) {
            location = locations[0];
        }
    }
    if (!location) {
        location = { key: 'VN', name: 'Vietnam' }; // Fallback to Vietnam
    }

    // Fetch and validate Interests using Facebook API
    let interests: Interest[] = [];
    if (parsedJson.interest_keywords && parsedJson.interest_keywords.length > 0) {
        const interestPromises = parsedJson.interest_keywords.map((keyword: string) => 
            facebookService.searchInterests(keyword, adsToken)
        );
        const interestResults = await Promise.all(interestPromises);
        const combinedInterests = interestResults.flat();
        
        // Remove duplicates
        const uniqueInterests = Array.from(new Map(combinedInterests.map((item: Interest) => [item.id, item])).values());
        interests = uniqueInterests;
    }

    // FIX: Add the missing return statement to fulfill the function's promise.
    return {
        objective: generatedObjective,
        ageMin: String(parsedJson.ageMin),
        ageMax: String(parsedJson.ageMax),
        gender: parsedJson.gender as Gender,
        location: location,
        interests: interests,
    };
};

// NEW: Interface for the Quick Campaign parsing result
export interface QuickCampaignParseResult {
    campaignName: string;
    ageMin: number;
    ageMax: number;
    gender: 'male' | 'female' | 'all';
    dailyBudget: string;
    latitude?: number;
    longitude?: number;
    interestKeywords: string[];
    postUrl: string;
}

// NEW: Function to parse unstructured text for the Quick Creator
export const parseQuickCampaignPrompt = async (
    promptText: string
): Promise<QuickCampaignParseResult> => {
    if (!API_KEY) {
        throw new Error("Gemini API key is not configured.");
    }
    
    const prompt = `
        Phân tích đoạn văn bản sau đây từ người dùng để lấy thông tin tạo chiến dịch quảng cáo Facebook. Trả về kết quả dưới dạng JSON.

        Văn bản của người dùng:
        ---
        ${promptText}
        ---

        Hướng dẫn trích xuất:
        1.  **campaignName**: Lấy từ "Tên chiến dịch:".
        2.  **ageMin & ageMax**: Lấy từ "20 40t" hoặc "tuổi 20-40".
        3.  **gender**: Chuyển "nữ" thành "female", "nam" thành "male". Nếu không có, mặc định là "all".
        4.  **dailyBudget**: Lấy giá trị ngân sách. Giữ nguyên định dạng như "400k".
        5.  **location**: Nếu có tọa độ dạng số, số (VD: 21.39, 106.62), hãy trích xuất số thứ nhất là "latitude" và số thứ hai là "longitude". Bỏ qua các từ "kinh độ", "vĩ độ". Nếu không có tọa độ, để trống.
        6.  **interestKeywords**: Lấy danh sách sở thích, tách nhau bằng dấu phẩy.
        7.  **postUrl**: Lấy đường link bài viết Facebook.
    `;

    const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    campaignName: { type: Type.STRING, description: "Campaign name" },
                    ageMin: { type: Type.NUMBER, description: "Minimum age" },
                    ageMax: { type: Type.NUMBER, description: "Maximum age" },
                    gender: { type: Type.STRING, description: "Gender: male, female, or all" },
                    dailyBudget: { type: Type.STRING, description: "Daily budget as a string, e.g., '400k'" },
                    latitude: { type: Type.NUMBER, nullable: true, description: "Latitude of the target location" },
                    longitude: { type: Type.NUMBER, nullable: true, description: "Longitude of the target location" },
                    interestKeywords: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of interest keywords" },
                    postUrl: { type: Type.STRING, description: "URL of the Facebook post" },
                },
                required: ['campaignName', 'ageMin', 'ageMax', 'gender', 'dailyBudget', 'interestKeywords', 'postUrl']
            }
        }
    });
    
    return JSON.parse(response.text) as QuickCampaignParseResult;
};
