// services/quickCreativeFacebookService.ts
import { CampaignObjective, Interest } from '../types';

const API_VERSION = 'v20.0';
const BASE_URL = `https://graph.facebook.com/${API_VERSION}`;
const HARDCODED_PAGE_ID = '159211580792822';

// --- HELPER FUNCTIONS ---
const getCurrencyOffset = (currency: string): number => {
    const zeroDecimalCurrencies = ['VND', 'JPY', 'KRW', 'CLP', 'ISK'];
    if (zeroDecimalCurrencies.includes(currency.toUpperCase())) {
        return 1;
    }
    return 100;
};

const parseBudgetInput = (budgetInput: string): number => {
    if (typeof budgetInput !== 'string' || !budgetInput) return NaN;
    const budget = budgetInput.toLowerCase().trim().replace(/,/g, '');
    let numericValue: number;
    if (budget.endsWith('k')) numericValue = parseFloat(budget.slice(0, -1)) * 1000;
    else if (budget.endsWith('tr') || budget.endsWith('m')) numericValue = parseFloat(budget.replace(/tr|m/, '')) * 1000000;
    else numericValue = parseFloat(budget);
    return numericValue;
};

const convertBudgetForApi = (budgetInput: string | number, currency: string): number => {
    let numericValue = typeof budgetInput === 'number' ? budgetInput : parseBudgetInput(budgetInput);
    if (isNaN(numericValue)) throw new Error(`Invalid budget format: ${budgetInput}.`);
    const offset = getCurrencyOffset(currency);
    return Math.round(numericValue * offset);
};

// --- CORE API FUNCTIONS ---
const createCampaign = async (adAccountId: string, userAccessToken: string, campaignName: string, objective: CampaignObjective): Promise<string> => {
    const params = new URLSearchParams({ name: campaignName, objective, status: 'PAUSED', special_ad_categories: '[]', access_token: userAccessToken });
    const response = await fetch(`${BASE_URL}/${adAccountId}/campaigns`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Campaign: ${data.error?.message}`);
    return data.id;
};

const createAdSet = async (
    adAccountId: string,
    userAccessToken: string,
    config: {
        campaignId: string;
        name: string;
        dailyBudget: string;
        currency: string;
        targeting: any;
    }
): Promise<string> => {
    const payload: Record<string, string> = {
        name: config.name,
        campaign_id: config.campaignId,
        status: 'PAUSED',
        billing_event: 'IMPRESSIONS',
        optimization_goal: 'CONVERSATIONS',
        destination_type: 'MESSENGER',
        daily_budget: String(convertBudgetForApi(config.dailyBudget, config.currency)),
        bid_strategy: 'LOWEST_COST_WITHOUT_CAP',
        targeting: JSON.stringify(config.targeting),
        promoted_object: JSON.stringify({ page_id: HARDCODED_PAGE_ID }),
        access_token: userAccessToken,
    };
    const response = await fetch(`${BASE_URL}/${adAccountId}/adsets`, { method: 'POST', body: new URLSearchParams(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Set: ${data.error?.message}`);
    return data.id;
};


const createAdCreativeForImage = async (adAccountId: string, pageAccessToken: string, config: { name: string, message: string, imageHash: string, messageTemplateData?: any }): Promise<string> => {
    const objectStorySpec: any = {
        page_id: HARDCODED_PAGE_ID,
        link_data: {
            message: config.message,
            name: config.name,
            image_hash: config.imageHash,
            link: `https://m.me/${HARDCODED_PAGE_ID}`,
            call_to_action: { type: 'MESSAGE_PAGE', value: { app_destination: 'MESSENGER' } }
        }
    };
    if (config.messageTemplateData) {
        objectStorySpec.link_data.page_welcome_message = JSON.stringify(config.messageTemplateData.page_welcome_message);
    }
    const params = new URLSearchParams({ name: `Creative - ${config.name}`, object_story_spec: JSON.stringify(objectStorySpec), access_token: pageAccessToken });
    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Creative (ảnh): (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

const createAdCreativeForVideo = async (adAccountId: string, pageAccessToken: string, config: { title: string, message: string, videoId: string, thumbnailUrl: string, messageTemplateData?: any }): Promise<string> => {
    const objectStorySpec: any = {
        page_id: HARDCODED_PAGE_ID,
        video_data: {
            message: config.message,
            title: config.title,
            video_id: config.videoId,
            image_url: config.thumbnailUrl,
            call_to_action: { type: 'MESSAGE_PAGE', value: { app_destination: 'MESSENGER' } }
        }
    };
    if (config.messageTemplateData) {
        objectStorySpec.video_data.page_welcome_message = JSON.stringify(config.messageTemplateData.page_welcome_message);
    }
    const params = new URLSearchParams({ name: `Creative - ${config.title}`, object_story_spec: JSON.stringify(objectStorySpec), access_token: pageAccessToken });
    const response = await fetch(`${BASE_URL}/${adAccountId}/adcreatives`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad Creative (video): (#${data.error?.code}) ${data.error?.error_user_title || data.error?.message}`);
    return data.id;
};

const createAd = async (adAccountId: string, pageAccessToken: string, config: { adSetId: string, name: string, creativeId: string }): Promise<string> => {
    const params = new URLSearchParams({
        name: config.name,
        adset_id: config.adSetId,
        status: 'PAUSED',
        creative: JSON.stringify({ creative_id: config.creativeId }),
        access_token: pageAccessToken
    });
    const response = await fetch(`${BASE_URL}/${adAccountId}/ads`, { method: 'POST', body: params });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi tạo Ad: ${data.error?.message}`);
    return data.id;
};

export const uploadAdImage = async (adAccountId: string, adsToken: string, file: File): Promise<{ hash: string, url: string }> => {
    const formData = new FormData();
    formData.append('access_token', adsToken);
    formData.append('filename', file);
    const response = await fetch(`${BASE_URL}/${adAccountId}/adimages`, { method: 'POST', body: formData });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi upload ảnh: ${data.error?.message}`);
    const firstImageKey = Object.keys(data.images)[0];
    if (!data.images[firstImageKey]?.hash) throw new Error("Không thể lấy image_hash từ API.");
    return data.images[firstImageKey];
};

export const uploadAdVideo = async (adAccountId: string, adsToken: string, file: File): Promise<string> => {
    const formData = new FormData();
    formData.append('access_token', adsToken);
    formData.append('file', file);
    const response = await fetch(`https://graph-video.facebook.com/${API_VERSION}/${adAccountId}/advideos`, { method: 'POST', body: formData });
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi upload video: ${data.error?.message}`);
    if (!data.id) throw new Error("Không thể lấy video_id từ API.");
    return data.id;
};

export const getVideoThumbnails = async (videoId: string, pageAccessToken: string): Promise<string> => {
    const url = `${BASE_URL}/${videoId}/thumbnails?access_token=${pageAccessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok) throw new Error(`Lỗi lấy thumbnail: ${data.error?.message}`);
    if (!data.data?.[0]?.uri) throw new Error("Video chưa có thumbnail.");
    return data.data[0].uri;
};

interface SearchResponse<T> { data: T[]; }
export const searchInterests = async (query: string, accessToken: string): Promise<Interest[]> => {
    if (!query) return [];
    const url = `${BASE_URL}/search?type=adinterest&q=${encodeURIComponent(query)}&limit=10&access_token=${accessToken}`;
    const response = await fetch(url);
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Không thể tìm kiếm sở thích.');
    }
    const data: SearchResponse<Interest> = await response.json();
    return data.data;
}

// --- ORCHESTRATOR FUNCTION ---
export const createFullCampaignFromMedia = async (
    config: {
        adAccountId: string;
        adsToken: string;
        pageAccessToken: string;
        campaignName: string;
        dailyBudget: string;
        currency: string;
        targeting: any;
        message: string;
        headline: string;
        mediaType: 'image' | 'video';
        imageHash?: string;
        videoId?: string;
        greetingText?: string;
        iceBreakerQuestions?: string[];
    },
    addLog: (step: string, status: 'success' | 'error', message: string) => void
): Promise<{ campaignId: string; adSetId: string; adId: string }> => {
    
    // 1. Create Campaign
    addLog('Bước 1: Tạo Campaign', 'success', 'Bắt đầu...');
    const campaignId = await createCampaign(config.adAccountId, config.adsToken, config.campaignName, 'OUTCOME_ENGAGEMENT');
    addLog('Bước 1: Tạo Campaign', 'success', `Thành công! ID: ${campaignId}`);

    // 2. Create Ad Set
    addLog('Bước 2: Tạo Ad Set', 'success', 'Bắt đầu...');
    const adSetId = await createAdSet(config.adAccountId, config.adsToken, {
        campaignId,
        name: `${config.campaignName} Ad Set`,
        dailyBudget: config.dailyBudget,
        currency: config.currency,
        targeting: config.targeting,
    });
    addLog('Bước 2: Tạo Ad Set', 'success', `Thành công! ID: ${adSetId}`);

    // 3. Build Message Template (if applicable)
    let messageTemplateData: any | null = null;
    if (config.greetingText || (config.iceBreakerQuestions && config.iceBreakerQuestions.length > 0)) {
        addLog('Bước 3: Tạo Ad Creative', 'success', 'Đang xây dựng mẫu tin nhắn chào...');
        messageTemplateData = {
            page_welcome_message: {
                type: "VISUAL_EDITOR",
                version: 2,
                landing_screen_type: "welcome_message",
                media_type: 'text',
                text_format: {
                    customer_action_type: "ice_breakers",
                    message: {
                        ice_breakers: (config.iceBreakerQuestions || [])
                            .filter(q => q.trim())
                            .map(q => ({ title: q.trim(), response: q.trim() || q.trim() })),
                        quick_replies: [],
                        text: (config.greetingText || '').trim()
                    }
                },
                user_edit: false,
                surface: "visual_editor_new"
            }
        };
    }

    // 4. Create Ad Creative
    addLog('Bước 3: Tạo Ad Creative', 'success', 'Bắt đầu...');
    let creativeId: string;
    if (config.mediaType === 'image') {
        if (!config.imageHash) throw new Error("Thiếu image hash.");
        creativeId = await createAdCreativeForImage(config.adAccountId, config.pageAccessToken, {
            name: config.headline,
            message: config.message,
            imageHash: config.imageHash,
            messageTemplateData: messageTemplateData,
        });
    } else {
        if (!config.videoId) throw new Error("Thiếu video ID.");
        addLog('Bước 3: Tạo Ad Creative', 'success', 'Đang lấy thumbnail tự động...');
        const thumbnailUrl = await getVideoThumbnails(config.videoId, config.pageAccessToken);
        addLog('Bước 3: Tạo Ad Creative', 'success', 'Lấy thumbnail thành công.');
        creativeId = await createAdCreativeForVideo(config.adAccountId, config.pageAccessToken, {
            title: config.headline,
            message: config.message,
            videoId: config.videoId,
            thumbnailUrl,
            messageTemplateData: messageTemplateData,
        });
    }
    addLog('Bước 3: Tạo Ad Creative', 'success', `Thành công! Creative ID: ${creativeId}`);

    // 5. Create Ad
    addLog('Bước 4: Tạo Ad', 'success', 'Bắt đầu...');
    const adId = await createAd(config.adAccountId, config.pageAccessToken, {
        adSetId,
        name: `${config.campaignName} Ad`,
        creativeId,
    });
    addLog('Bước 4: Tạo Ad', 'success', `Thành công! Ad ID: ${adId}`);

    return { campaignId, adSetId, adId };
};