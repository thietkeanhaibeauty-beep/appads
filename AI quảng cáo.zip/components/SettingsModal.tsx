import React, { useState, useEffect } from 'react';
import { CloseIcon, CheckCircleIcon, ExclamationCircleIcon } from './Icons';
import Spinner from './Spinner';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialAdsToken: string | null;
  initialPageId: string | null;
  initialPageToken: string | null;
  onSave: (settings: { adsToken: string; pageId: string; pageToken: string }) => void;
}

type VerificationStatus = 'idle' | 'checking' | 'valid' | 'invalid';

const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  initialAdsToken,
  initialPageId,
  initialPageToken,
  onSave,
}) => {
  const [adsToken, setAdsToken] = useState(initialAdsToken || '');
  const [pageId, setPageId] = useState(initialPageId || '');
  const [pageToken, setPageToken] = useState(initialPageToken || '');

  const [adsTokenStatus, setAdsTokenStatus] = useState<VerificationStatus>('idle');
  const [pageTokenStatus, setPageTokenStatus] = useState<VerificationStatus>('idle');
  const [adsTokenError, setAdsTokenError] = useState('');
  const [pageTokenError, setPageTokenError] = useState('');

  useEffect(() => {
    if (isOpen) {
      setAdsToken(initialAdsToken || '');
      setPageId(initialPageId || '');
      setPageToken(initialPageToken || '');
      setAdsTokenStatus('idle');
      setPageTokenStatus('idle');
      setAdsTokenError('');
      setPageTokenError('');
    }
  }, [isOpen, initialAdsToken, initialPageId, initialPageToken]);

  if (!isOpen) {
    return null;
  }

  const handleCheckAdsToken = async () => {
    if (!adsToken) return;
    setAdsTokenStatus('checking');
    setAdsTokenError('');
    try {
      const response = await fetch(`https://graph.facebook.com/v23.0/me?access_token=${adsToken}`);
      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error?.message || 'Token không hợp lệ.');
      }
      setAdsTokenStatus('valid');
    } catch (err: any) {
      setAdsTokenStatus('invalid');
      setAdsTokenError(err.message);
    }
  };
  
  const handleCheckPageToken = async () => {
    if (!pageToken || !pageId) {
        setPageTokenStatus('invalid');
        setPageTokenError('Cần nhập cả Page ID và Page Token để kiểm tra.');
        return;
    }
    setPageTokenStatus('checking');
    setPageTokenError('');
    try {
      const response = await fetch(`https://graph.facebook.com/v23.0/${pageId}?fields=id,name&access_token=${pageToken}`);
      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error?.message || 'Token hoặc Page ID không hợp lệ.');
      }
      setPageTokenStatus('valid');
    } catch (err: any) {
      setPageTokenStatus('invalid');
      setPageTokenError(err.message);
    }
  };

  const handleSave = () => {
    onSave({ adsToken, pageId, pageToken });
    onClose();
  };
  
  const renderStatusIcon = (status: VerificationStatus) => {
    switch (status) {
        case 'checking': return <Spinner />;
        case 'valid': return <CheckCircleIcon className="w-5 h-5 text-green-500" />;
        case 'invalid': return <ExclamationCircleIcon className="w-5 h-5 text-red-500" />;
        default: return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-[2000] p-4" role="dialog" aria-modal="true">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg">
            <div className="flex justify-between items-center p-4 border-b dark:border-gray-600">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
                    Cài đặt
                </h3>
                <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200" aria-label="Đóng">
                    <CloseIcon className="w-6 h-6" />
                </button>
            </div>
            
            <div className="p-6 space-y-6">
                 <div>
                    <label htmlFor="adsToken" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ads Token</label>
                    <div className="mt-1 flex rounded-md shadow-sm">
                        <input
                            id="adsToken"
                            type="password"
                            value={adsToken}
                            onChange={(e) => setAdsToken(e.target.value)}
                            className="block w-full flex-1 rounded-none rounded-l-md border-gray-300 dark:bg-gray-700 dark:border-gray-600"
                        />
                         <div className="relative inline-flex items-center px-3 rounded-r-md border border-l-0 border-gray-300 bg-gray-50 dark:bg-gray-600 dark:border-gray-500">
                            {renderStatusIcon(adsTokenStatus)}
                        </div>
                        <button onClick={handleCheckAdsToken} disabled={adsTokenStatus === 'checking' || !adsToken} className="ml-2 px-3 py-2 text-xs font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:bg-gray-400">
                            Check
                        </button>
                    </div>
                     {adsTokenStatus === 'invalid' && <p className="mt-2 text-xs text-red-600 dark:text-red-400">{adsTokenError}</p>}
                </div>
                
                <div>
                    <label htmlFor="pageId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Page ID</label>
                    <input
                        id="pageId"
                        type="text"
                        value={pageId}
                        onChange={(e) => setPageId(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600"
                    />
                </div>

                 <div>
                    <label htmlFor="pageToken" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Page Token</label>
                    <div className="mt-1 flex rounded-md shadow-sm">
                        <input
                            id="pageToken"
                            type="password"
                            value={pageToken}
                            onChange={(e) => setPageToken(e.target.value)}
                            className="block w-full flex-1 rounded-none rounded-l-md border-gray-300 dark:bg-gray-700 dark:border-gray-600"
                        />
                        <div className="relative inline-flex items-center px-3 rounded-r-md border border-l-0 border-gray-300 bg-gray-50 dark:bg-gray-600 dark:border-gray-500">
                            {renderStatusIcon(pageTokenStatus)}
                        </div>
                        <button onClick={handleCheckPageToken} disabled={pageTokenStatus === 'checking' || !pageToken || !pageId} className="ml-2 px-3 py-2 text-xs font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:bg-gray-400">
                            Check
                        </button>
                    </div>
                     {pageTokenStatus === 'invalid' && <p className="mt-2 text-xs text-red-600 dark:text-red-400">{pageTokenError}</p>}
                </div>
            </div>

            <div className="flex justify-end items-center p-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-600 rounded-b-lg space-x-3">
                 <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500">
                    Hủy
                </button>
                <button onClick={handleSave} className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
                    Lưu Cài đặt
                </button>
            </div>
        </div>
    </div>
  );
};

export default SettingsModal;