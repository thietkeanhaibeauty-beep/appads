import React, { useState } from 'react';
import { AdAccount, CampaignDraft } from '../types';
import * as aiAssistantService from '../services/aiAssistantService';
import Spinner from './Spinner';
import { CheckCircleIcon, ExclamationCircleIcon, SparklesIcon } from './Icons';

interface AiCampaignCreatorProps {
    selectedAccount: AdAccount;
    adsToken: string;
    onDraftGenerated: (draft: CampaignDraft) => void;
}

const AiCampaignCreator: React.FC<AiCampaignCreatorProps> = ({ selectedAccount, adsToken, onDraftGenerated }) => {
    const [objective, setObjective] = useState('');
    const [audience, setAudience] = useState('');
    const [budget, setBudget] = useState('100000');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedDraft, setGeneratedDraft] = useState<Partial<CampaignDraft> | null>(null);

    const handleGenerate = async () => {
        if (!objective || !audience || !budget) {
            setError('Vui lòng điền đầy đủ thông tin.');
            return;
        }
        setLoading(true);
        setError(null);
        setGeneratedDraft(null);

        try {
            const draft = await aiAssistantService.generateCampaignParameters(objective, audience, adsToken);
            setGeneratedDraft(draft);
        } catch (err: any) {
            setError(err.message || 'Đã xảy ra lỗi không xác định khi liên hệ với trợ lý AI.');
        } finally {
            setLoading(false);
        }
    };

    const handleConfirm = () => {
        if (!generatedDraft) return;
        const fullDraft: CampaignDraft = {
            campaignName: objective, // Use objective as campaign name
            dailyBudget: budget,
            ...generatedDraft,
        } as CampaignDraft; // Cast because we're filling in the blanks
        onDraftGenerated(fullDraft);
    };
    
    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
           <div className="min-h-[400px] flex flex-col justify-center">
            {!generatedDraft ? (
                // Form View
                <div className="space-y-4">
                    <div>
                        <label htmlFor="ai-objective" className="block text-sm font-medium text-gray-700 dark:text-gray-300">1. Mục tiêu chính của bạn là gì?</label>
                        <input type="text" id="ai-objective" value={objective} onChange={e => setObjective(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600" placeholder="VD: Thu hút thêm tin nhắn từ khách hàng spa" />
                    </div>
                    <div>
                        <label htmlFor="ai-audience" className="block text-sm font-medium text-gray-700 dark:text-gray-300">2. Mô tả khách hàng lý tưởng của bạn</label>
                        <textarea id="ai-audience" rows={3} value={audience} onChange={e => setAudience(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600" placeholder="VD: Phụ nữ từ 25-40 tuổi sống tại Hà Nội, quan tâm đến làm đẹp, chăm sóc da."></textarea>
                    </div>
                     <div>
                        <label htmlFor="ai-budget" className="block text-sm font-medium text-gray-700 dark:text-gray-300">3. Ngân sách hàng ngày ({selectedAccount.currency})</label>
                        <input type="text" id="ai-budget" value={budget} onChange={e => setBudget(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600" placeholder="VD: 100000" />
                    </div>
                     {error && (
                        <div className="p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-md text-sm flex items-center">
                            <ExclamationCircleIcon className="w-5 h-5 mr-2"/>
                            {error}
                        </div>
                     )}
                     <div className="pt-2">
                        <button onClick={handleGenerate} disabled={loading || !objective || !audience || !budget} className="w-full inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400">
                            {loading ? <Spinner/> : <><SparklesIcon className="w-5 h-5 mr-2" /> Tạo bản nháp với AI</>}
                        </button>
                    </div>
                </div>
            ) : (
                // Confirmation View
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center"><CheckCircleIcon className="w-6 h-6 mr-2 text-green-500" /> AI đã tạo bản nháp!</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Vui lòng xem lại thông tin dưới đây. Bạn có thể chỉnh sửa chi tiết ở bước tiếp theo.</p>
                    <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg space-y-3 text-sm">
                        <p><strong>Tên chiến dịch:</strong> {objective}</p>
                        <p><strong>Mục tiêu:</strong> {generatedDraft.objective}</p>
                        <p><strong>Ngân sách:</strong> {Number(budget).toLocaleString('vi-VN')} {selectedAccount.currency} / ngày</p>
                        <p><strong>Đối tượng:</strong></p>
                        <ul className="pl-6 list-disc text-gray-700 dark:text-gray-300">
                            <li><strong>Vị trí:</strong> {generatedDraft.location?.name}</li>
                            <li><strong>Tuổi:</strong> {generatedDraft.ageMin} - {generatedDraft.ageMax}</li>
                            <li><strong>Giới tính:</strong> {generatedDraft.gender}</li>
                            <li><strong>Sở thích gợi ý:</strong> {generatedDraft.interests?.map(i => i.name).join(', ') || 'Không có'}</li>
                        </ul>
                    </div>
                     {error && (
                        <div className="p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-md text-sm">{error}</div>
                     )}
                    <div className="flex items-center justify-end space-x-3 pt-4">
                        <button onClick={() => setGeneratedDraft(null)} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500">
                            Thử lại
                        </button>
                        <button onClick={handleConfirm} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
                            Xác nhận & Tiếp tục
                        </button>
                    </div>
                </div>
            )}
            </div>
        </div>
    );
};

export default AiCampaignCreator;