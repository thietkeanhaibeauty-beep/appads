
import React from 'react';
import { FacebookIcon, MegaphoneIcon } from './Icons';

interface ModeSelectorProps {
  onSelectMode: (mode: 'page_flow' | 'ads_flow') => void;
}

const ModeSelector: React.FC<ModeSelectorProps> = ({ onSelectMode }) => {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-lg shadow-lg dark:bg-gray-800">
        <div className="text-center">
            <div className="flex justify-center items-center mb-4 text-blue-600">
                <FacebookIcon className="w-8 h-8 mr-2" />
                <MegaphoneIcon className="w-8 h-8 ml-2" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">CRM & Ads Tool</h2>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                Chọn chức năng bạn muốn sử dụng
            </p>
        </div>
        <div className="flex flex-col space-y-4">
            <button
              onClick={() => onSelectMode('page_flow')}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Quản lý Fanpage
            </button>
            <button
              onClick={() => onSelectMode('ads_flow')}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Quản lý Quảng cáo
            </button>
        </div>
      </div>
    </div>
  );
};

export default ModeSelector;