import React, { useState, useCallback, useRef, useEffect } from 'react';
import { AdAccount, CustomAudience } from '../types';
import * as facebookService from '../services/facebookService';
import { UsersIcon, UploadIcon, CheckCircleIcon, ExclamationCircleIcon, ChatBubbleLeftRightIcon, UserPlusIcon } from './Icons';
import Spinner from './Spinner';

interface AudienceCreatorProps {
  selectedAccount: AdAccount;
  adsToken: string;
  aiCommand: { action: string; payload: any } | null;
  onAiCommandProcessed: () => void;
}

type ApiLog = {
  timestamp: string;
  step: string;
  status: 'success' | 'error' | 'info';
  message: string;
};

type AudienceType = 'file' | 'page_messengers' | 'lookalike';

const INITIAL_STATE = {
    audienceType: 'file' as AudienceType,
    audienceName: '',
    description: '',
    file: null as File | null,
    phoneNumbers: [] as string[],
    retentionDays: 365,
    lookalikeSourceId: '',
    lookalikeCountry: 'VN',
    lookalikeRatio: 1,
    isLoading: false,
    error: null as string | null,
    successMessage: null as string | null,
    apiLogs: [] as ApiLog[],
    jsonPreview: ''
};


const AudienceCreator: React.FC<AudienceCreatorProps> = ({ selectedAccount, adsToken, aiCommand, onAiCommandProcessed }) => {
  const [audienceType, setAudienceType] = useState<AudienceType>('file');
  const [audienceName, setAudienceName] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [phoneNumbers, setPhoneNumbers] = useState<string[]>([]);
  const [retentionDays, setRetentionDays] = useState(365);
  
  // Lookalike state
  const [sourceAudiences, setSourceAudiences] = useState<CustomAudience[]>([]);
  const [isFetchingSources, setIsFetchingSources] = useState(false);
  const [lookalikeSourceId, setLookalikeSourceId] = useState('');
  const [lookalikeCountry, setLookalikeCountry] = useState('VN');
  const [lookalikeRatio, setLookalikeRatio] = useState(1);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [apiLogs, setApiLogs] = useState<ApiLog[]>([]);
  const [jsonPreview, setJsonPreview] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [aiTrigger, setAiTrigger] = useState(false);
  const [postCreationUpsell, setPostCreationUpsell] = useState<{ id: string; name: string } | null>(null);
  
  const HARDCODED_PAGE_ID = '159211580792822';

  const resetState = () => {
    setAudienceType(INITIAL_STATE.audienceType);
    setAudienceName(INITIAL_STATE.audienceName);
    setDescription(INITIAL_STATE.description);
    setFile(INITIAL_STATE.file);
    setPhoneNumbers(INITIAL_STATE.phoneNumbers);
    setRetentionDays(INITIAL_STATE.retentionDays);
    setLookalikeSourceId(INITIAL_STATE.lookalikeSourceId);
    setLookalikeCountry(INITIAL_STATE.lookalikeCountry);
    setLookalikeRatio(INITIAL_STATE.lookalikeRatio);
    setIsLoading(INITIAL_STATE.isLoading);
    setError(INITIAL_STATE.error);
    setSuccessMessage(INITIAL_STATE.successMessage);
    setApiLogs(INITIAL_STATE.apiLogs);
    setJsonPreview(INITIAL_STATE.jsonPreview);
    setPostCreationUpsell(null);
  };

  useEffect(() => {
    const handleReset = () => resetState();
    window.addEventListener('ai-reset-flow', handleReset);
    return () => {
        window.removeEventListener('ai-reset-flow', handleReset);
    };
  }, []);

  const addApiLog = useCallback((step: string, status: ApiLog['status'], message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setApiLogs(prev => [{ timestamp, step, status, message }, ...prev]);
  }, []);
  
  // Fetch source audiences when switching to lookalike mode
  useEffect(() => {
      if (audienceType === 'lookalike') {
          const fetchSources = async () => {
              setIsFetchingSources(true);
              setError(null);
              try {
                  const audiences = await facebookService.getCustomAudiences(selectedAccount.id, adsToken);
                  setSourceAudiences(audiences);
                  if (audiences.length > 0 && !lookalikeSourceId) {
                      setLookalikeSourceId(audiences[0].id);
                  }
              } catch (err: any) {
                  setError(err.message);
                  setSourceAudiences([]);
              } finally {
                  setIsFetchingSources(false);
              }
          };
          fetchSources();
      }
  }, [audienceType, selectedAccount.id, adsToken, lookalikeSourceId]);

  const handleCreateAudience = useCallback(async (fromAI: boolean = false) => {
    if (!audienceName.trim() || !adsToken) {
      const msg = 'Vui lòng nhập tên đối tượng.';
      setError(msg);
      addApiLog('Lỗi xác thực', 'error', msg); 
      if (fromAI) {
        window.dispatchEvent(new CustomEvent('audience-form-result', { detail: { success: false, message: msg } }));
      }
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    setPostCreationUpsell(null);
    if (!fromAI) {
      setApiLogs([]);
    }
    
    let result = { success: false, message: '', newAudienceId: '', newAudienceName: '' };

    try {
      addApiLog('Bắt đầu', 'info', `Tạo đối tượng có tên: "${audienceName}"`);
      
      if (audienceType === 'file') {
        if (phoneNumbers.length === 0) {
          throw new Error('Vui lòng tải lên một tệp chứa số điện thoại.');
        }

        const audienceId = await facebookService.createCustomAudience(
          selectedAccount.id,
          adsToken,
          audienceName,
          description
        );
        addApiLog('Tạo Container', 'success', `Tạo đối tượng thành công! ID: ${audienceId}`);
        
        addApiLog('Thêm người dùng', 'info', `Chuẩn bị thêm ${phoneNumbers.length} người dùng...`);
        const fbResult = await facebookService.addUsersToCustomAudience(
          audienceId,
          adsToken,
          phoneNumbers
        );
        addApiLog('Thêm người dùng', 'success', `Đã gửi yêu cầu thêm người dùng thành công. Số người nhận: ${fbResult.num_received_entries}.`);
        
        const finalMessage = `Hoàn tất! Đã tạo đối tượng "${audienceName}" (ID: ${audienceId}) và bắt đầu thêm ${fbResult.num_received_entries} người dùng. Facebook sẽ mất một lúc để xử lý và khớp dữ liệu.`;
        setSuccessMessage(finalMessage);
        addApiLog('Hoàn tất', 'success', finalMessage);
        result = { ...result, success: true, message: finalMessage };
        resetState();
      } else if (audienceType === 'page_messengers') { 
        const audienceId = await facebookService.createPageMessengersAudience(
          selectedAccount.id,
          adsToken,
          audienceName,
          description,
          HARDCODED_PAGE_ID,
          retentionDays
        );
        addApiLog('Tạo Đối tượng', 'success', `Tạo đối tượng thành công! ID: ${audienceId}`);

        const finalMessage = `Đã tạo đối tượng "${audienceName}" (ID: ${audienceId}). Facebook sẽ bắt đầu điền đối tượng này với những người đã nhắn tin cho Page trong ${retentionDays} ngày qua. Quá trình này có thể mất một lúc.`;
        setPostCreationUpsell({ id: audienceId, name: audienceName });
        addApiLog('Hoàn tất', 'success', finalMessage);
        result = { success: true, message: finalMessage, newAudienceId: audienceId, newAudienceName: audienceName };
      } else { // lookalike
          if (!lookalikeSourceId) {
              throw new Error("Vui lòng chọn một đối tượng nguồn.");
          }
          const audienceId = await facebookService.createLookalikeAudience(
              selectedAccount.id,
              adsToken,
              audienceName,
              description,
              lookalikeSourceId,
              lookalikeCountry,
              lookalikeRatio
          );
          addApiLog('Tạo Đối tượng tương tự', 'success', `Yêu cầu tạo đối tượng thành công! ID: ${audienceId}`);
          const finalMessage = `Đã gửi yêu cầu tạo đối tượng tương tự "${audienceName}" (ID: ${audienceId}). Facebook sẽ mất vài giờ để xử lý và tạo tệp đối tượng mới.`;
          setSuccessMessage(finalMessage);
          addApiLog('Hoàn tất', 'success', finalMessage);
          result = { ...result, success: true, message: finalMessage };
          resetState();
      }

    } catch (err: any) {
      setError(err.message);
      addApiLog('Lỗi', 'error', err.message);
      result = { ...result, success: false, message: err.message };
    } finally {
      setIsLoading(false);
      if (fromAI) {
          window.dispatchEvent(new CustomEvent('audience-form-result', { detail: result }));
      }
    }
  }, [addApiLog, audienceName, audienceType, description, phoneNumbers, retentionDays, adsToken, selectedAccount.id, lookalikeSourceId, lookalikeCountry, lookalikeRatio, sourceAudiences]);

  const handleCreateAudienceRef = useRef(handleCreateAudience);
  useEffect(() => {
    handleCreateAudienceRef.current = handleCreateAudience;
  }, [handleCreateAudience]);

  useEffect(() => {
    if (aiCommand) {
      const { action, payload } = aiCommand;

      switch (action) {
        case 'start':
          setAudienceType(payload.type);
          break;
        case 'updateField':
          if (payload.field === 'audienceName') setAudienceName(payload.value);
          else if (payload.field === 'retentionDays') setRetentionDays(payload.value);
          else if (payload.field === 'lookalikeSourceId') setLookalikeSourceId(payload.value);
          else if (payload.field === 'lookalikeCountry') setLookalikeCountry(payload.value);
          else if (payload.field === 'lookalikeRatio') setLookalikeRatio(payload.value);
          
          if (payload.field !== 'audienceName') {
              setDescription(`Tạo bởi Trợ lý AI lúc ${new Date().toLocaleString()}`);
          }
          break;
        case 'triggerCreate':
          setAiTrigger(true);
          break;
      }
      
      onAiCommandProcessed();
    }
  }, [aiCommand, onAiCommandProcessed]);

  useEffect(() => {
    if (aiTrigger) {
      setAiTrigger(false);
      handleCreateAudienceRef.current(true);
    }
  }, [aiTrigger]);
  
  useEffect(() => {
    const generatePreview = () => {
      if (!audienceName.trim()) {
        setJsonPreview('');
        return;
      }

      let payload: any;

      if (audienceType === 'file') {
        payload = {
          name: audienceName,
          description: description,
          subtype: 'CUSTOM',
          customer_file_source: 'USER_PROVIDED_ONLY',
        };
      } else if (audienceType === 'page_messengers') {
        const rule = {
            inclusions: {
                operator: "or",
                rules: [{
                    event_sources: [{ id: HARDCODED_PAGE_ID, type: "page" }],
                    retention_seconds: retentionDays * 24 * 60 * 60,
                    filter: {
                        operator: "and",
                        filters: [{
                            field: "event",
                            operator: "eq",
                            value: "page_messaged"
                        }]
                    }
                }]
            }
        };

        payload = {
            name: audienceName,
            description: description,
            rule: rule,
            prefill: true,
        };
      } else { // lookalike
          payload = {
              name: audienceName,
              description: description,
              subtype: 'LOOKALIKE',
              origin_audience_id: lookalikeSourceId,
              lookalike_spec: {
                  type: 'similarity',
                  country: lookalikeCountry.toUpperCase(),
                  ratio: lookalikeRatio / 100,
              }
          };
      }
      setJsonPreview(JSON.stringify(payload, null, 2));
    };

    generatePreview();
  }, [audienceName, description, audienceType, retentionDays, HARDCODED_PAGE_ID, lookalikeSourceId, lookalikeCountry, lookalikeRatio]);

  const handleFileChange = (selectedFile: File | null) => {
    if (!selectedFile) return;

    if (selectedFile.type !== 'text/plain' && selectedFile.type !== 'text/csv') {
      setError('Loại tệp không hợp lệ. Vui lòng chọn tệp .txt hoặc .csv.');
      return;
    }

    setFile(selectedFile);
    setError(null);
    setPhoneNumbers([]);

    addApiLog('File Upload', 'info', `Đang đọc tệp: ${selectedFile.name}`);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split(/[\r\n]+/).filter(line => line.trim() !== '');
      setPhoneNumbers(lines);
      addApiLog('File Read', 'success', `Tìm thấy ${lines.length} dòng trong tệp.`);
    };
    reader.onerror = () => {
      const readError = 'Không thể đọc tệp.';
      setError(readError);
      addApiLog('File Read', 'error', readError);
    };
    reader.readAsText(selectedFile);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDeclineUpsell = () => {
    setPostCreationUpsell(null);
    resetState();
  };

  const handleAcceptUpsell = () => {
    if (!postCreationUpsell) return;

    setAudienceType('lookalike');
    setLookalikeSourceId(postCreationUpsell.id);
    const newName = `LAL 1% - ${postCreationUpsell.name}`;
    setAudienceName(newName);
    setDescription(`Đối tượng tương tự 1% từ "${postCreationUpsell.name}"`);

    // Reset other irrelevant fields for a clean lookalike form
    setFile(null);
    setPhoneNumbers([]);
    setRetentionDays(365);
    setLookalikeCountry('VN');
    setLookalikeRatio(1);
    
    setPostCreationUpsell(null);
    setSuccessMessage(`Đã chuyển sang tạo Đối tượng tương tự. Vui lòng kiểm tra và điền các thông tin còn lại.`);
    setError(null);
    setApiLogs([]); // Start fresh logs for the new action
  };
  
  const isButtonDisabled = isLoading || !audienceName.trim() || (audienceType === 'file' && phoneNumbers.length === 0) || (audienceType === 'lookalike' && !lookalikeSourceId) || !!postCreationUpsell;

  const AudienceTypeButton: React.FC<{
    targetType: AudienceType;
    children: React.ReactNode;
    label: string;
  }> = ({ targetType, children, label }) => (
      <button
        onClick={() => setAudienceType(targetType)}
        className={`relative inline-flex items-center justify-center px-4 py-2 border text-sm font-medium focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 w-1/3 ${
          audienceType === targetType
            ? 'bg-blue-600 text-white border-blue-600'
            : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-500 hover:bg-gray-50 dark:hover:bg-gray-600'
        } first:rounded-l-md last:rounded-r-md -ml-px first:ml-0`}
      >
        {children}
        {label}
      </button>
  );

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center">
          <UsersIcon className="w-6 h-6 mr-2" />
          Tạo đối tượng tùy chỉnh
        </h3>
        
        <div className="flex rounded-md shadow-sm">
            <AudienceTypeButton targetType="file" label="Tệp SĐT">
                <UploadIcon className="w-5 h-5 mr-2" />
            </AudienceTypeButton>
            <AudienceTypeButton targetType="page_messengers" label="Người nhắn tin Page">
                <ChatBubbleLeftRightIcon className="w-5 h-5 mr-2" />
            </AudienceTypeButton>
            <AudienceTypeButton targetType="lookalike" label="Đối tượng tương tự">
                <UserPlusIcon className="w-5 h-5 mr-2" />
            </AudienceTypeButton>
        </div>

        <div>
          <label htmlFor="audienceName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tên đối tượng <span className="text-red-500">*</span></label>
          <input type="text" id="audienceName" value={audienceName} onChange={e => setAudienceName(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600" placeholder="VD: Khách hàng tiềm năng tháng 9" />
        </div>
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Mô tả (tùy chọn)</label>
          <textarea id="description" rows={2} value={description} onChange={e => setDescription(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600" placeholder="VD: Dữ liệu khách hàng từ sự kiện Zalo..."></textarea>
        </div>

        {audienceType === 'file' ? (
            <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tệp số điện thoại <span className="text-red-500">*</span></label>
                  <div 
                    className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md cursor-pointer hover:border-blue-500 dark:hover:border-blue-400"
                    onClick={() => fileInputRef.current?.click()}
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                  >
                    <div className="space-y-1 text-center">
                      <UploadIcon className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600 dark:text-gray-400">
                        <p className="pl-1">Tải lên tệp hoặc kéo thả</p>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-500">.TXT, .CSV</p>
                      <input ref={fileInputRef} id="file-upload" name="file-upload" type="file" className="sr-only" accept=".txt,.csv" onChange={(e) => handleFileChange(e.target.files ? e.target.files[0] : null)} />
                    </div>
                  </div>
                </div>

                {file && (
                    <div className="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-md text-sm">
                        <p><strong>Tệp đã chọn:</strong> {file.name}</p>
                        <p><strong>Số dòng tìm thấy:</strong> {phoneNumbers.length}</p>
                        {phoneNumbers.length > 0 && (
                            <div className="mt-2">
                                <p className="text-xs text-gray-600 dark:text-gray-400">Xem trước 5 SĐT đầu tiên:</p>
                                <ul className="text-xs list-disc list-inside font-mono text-gray-500 dark:text-gray-500">
                                    {phoneNumbers.slice(0, 5).map((p, i) => <li key={i}>{p}</li>)}
                                </ul>
                            </div>
                        )}
                    </div>
                )}
            </>
        ) : audienceType === 'page_messengers' ? (
             <div>
                <label htmlFor="retention" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Thời gian giữ lại: <span className="font-bold">{retentionDays} ngày</span>
                </label>
                <input
                    id="retention"
                    type="range"
                    min="1"
                    max="365"
                    value={retentionDays}
                    onChange={(e) => setRetentionDays(parseInt(e.target.value, 10))}
                    className="mt-2 w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Bao gồm những người đã nhắn tin cho Page trong {retentionDays} ngày qua. (Tối đa 365 ngày)
                </p>
            </div>
        ) : ( // lookalike
            <div className="space-y-4">
                <div>
                    <label htmlFor="sourceAudience" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Đối tượng nguồn <span className="text-red-500">*</span></label>
                    {isFetchingSources ? <div className="mt-1"><Spinner /></div> : (
                        <select
                            id="sourceAudience"
                            value={lookalikeSourceId}
                            onChange={(e) => setLookalikeSourceId(e.target.value)}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
                            disabled={sourceAudiences.length === 0}
                        >
                            {sourceAudiences.length === 0 ? (
                                <option>Không tìm thấy đối tượng nguồn</option>
                            ) : (
                                sourceAudiences.map(aud => <option key={aud.id} value={aud.id}>{aud.name}</option>)
                            )}
                        </select>
                    )}
                </div>
                <div>
                    <label htmlFor="lookalikeCountry" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Quốc gia</label>
                    <input type="text" id="lookalikeCountry" value={lookalikeCountry} onChange={e => setLookalikeCountry(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="VD: VN, US..." />
                </div>
                <div>
                    <label htmlFor="lookalikeRatio" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Quy mô đối tượng: <span className="font-bold">{lookalikeRatio}%</span>
                    </label>
                    <input
                        id="lookalikeRatio"
                        type="range"
                        min="1"
                        max="10"
                        step="1"
                        value={lookalikeRatio}
                        onChange={(e) => setLookalikeRatio(parseInt(e.target.value, 10))}
                        className="mt-2 w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        1% là những người giống nhất, 10% là phạm vi tiếp cận rộng hơn.
                    </p>
                </div>
            </div>
        )}
      </div>
      
      {jsonPreview && (
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            JSON Payload Preview
          </label>
          <pre className="text-xs bg-gray-900 text-white font-mono rounded-md p-3 max-h-48 overflow-y-auto">
            <code>
              {jsonPreview}
            </code>
          </pre>
        </div>
      )}

      {error && (
        <div className="p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-md text-sm flex items-center">
            <ExclamationCircleIcon className="w-5 h-5 mr-2"/>
            {error}
        </div>
      )}
       {successMessage && !postCreationUpsell && (
        <div className="p-3 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-md text-sm flex items-center">
            <CheckCircleIcon className="w-5 h-5 mr-2"/>
            {successMessage}
        </div>
      )}
      {postCreationUpsell && (
        <div className="p-4 bg-green-100 dark:bg-green-900 rounded-md space-y-3">
          <div className="flex items-center text-green-800 dark:text-green-200">
            <CheckCircleIcon className="w-5 h-5 mr-2 flex-shrink-0"/>
            <p className="text-sm font-medium">Tạo đối tượng "{postCreationUpsell.name}" thành công!</p>
          </div>
          <p className="text-sm text-gray-700 dark:text-gray-300">Bạn có muốn tạo đối tượng tương tự từ tệp vừa tạo không?</p>
          <div className="flex items-center space-x-3">
            <button onClick={handleAcceptUpsell} className="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
              Có, tạo ngay
            </button>
            <button onClick={handleDeclineUpsell} className="px-3 py-1.5 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500">
              Không, cảm ơn
            </button>
          </div>
        </div>
      )}

      <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
        <button 
          onClick={() => handleCreateAudience()}
          disabled={isButtonDisabled}
          className="w-full inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400"
        >
          {isLoading ? <Spinner /> : 'Tạo đối tượng'}
        </button>
      </div>

      {apiLogs.length > 0 && (
          <div className="space-y-3">
              <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Logs API</h4>
              <div className="bg-gray-900 text-white font-mono text-xs rounded-md p-3 max-h-40 overflow-y-auto">
                  {apiLogs.map((log, i) => (
                      <p key={i} className={`${log.status === 'error' ? 'text-red-400' : log.status === 'success' ? 'text-green-400' : 'text-gray-400'}`}>
                          <span className="text-gray-500">{log.timestamp}</span> [{log.step}]: {log.message}
                      </p>
                  ))}
              </div>
          </div>
      )}
    </div>
  );
};

export default AudienceCreator;