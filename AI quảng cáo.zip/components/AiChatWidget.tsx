import React, { useState, useEffect, useRef } from 'react';
import { AdAccount, City, CustomAudience, Gender, Interest, GeoLocationTargeting } from '../types';
import { RefreshIcon } from './Icons';
import * as facebookService from '../services/facebookService';
import * as quickAiService from '../services/quickAiService';
import { QuickCreativeParseResult } from '../services/quickAiService';
import MediaUploader from './MediaUploader';
import * as quickCreativeFacebookService from '../services/quickCreativeFacebookService';


interface AiChatWidgetProps {
  adsToken: string | null;
  pageId: string | null;
  pageAccessToken: string | null;
  selectedAdAccount: AdAccount | null;
}

interface MediaUploadResult {
    mediaType: 'image' | 'video';
    previewUrl?: string;
    imageHash?: string;
    videoId?: string;
}

interface QuickCreativeResult {
    success: boolean;
    campaignId?: string;
    adSetId?: string;
    adId?: string;
    error?: string;
}

type ConversationStep =
  | 'IDLE'
  // Audience Creation Flow
  | 'AUDIENCE_ASK_TYPE'
  | 'AUDIENCE_ASK_NAME'
  | 'AUDIENCE_ASK_RETENTION'
  | 'AWAITING_MESSENGER_AUDIENCE_CREATION'
  | 'AUDIENCE_MESSENGER_CREATED_UPSELL'
  | 'LOOKALIKE_AWAIT_SOURCE_SELECTION'
  | 'LOOKALIKE_ASK_NAME'
  | 'LOOKALIKE_ASK_COUNTRY'
  | 'LOOKALIKE_ASK_RATIO'
  | 'AWAITING_LOOKALIKE_CREATION'
  // Campaign Creation Flow
  | 'CAMPAIGN_ASK_NAME'
  | 'AWAITING_CAMPAIGN_CREATION'
  | 'CAMPAIGN_ASK_BUDGET_TYPE'
  | 'CAMPAIGN_ASK_BUDGET_AMOUNT'
  | 'CAMPAIGN_ASK_LIFETIME_DATE_RANGE'
  | 'CAMPAIGN_CONFIRM_LIFETIME_DATES'
  | 'CAMPAIGN_ASK_LIFETIME_START_TIME'
  | 'CAMPAIGN_ASK_LIFETIME_END_TIME'
  | 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_PROMPT'
  | 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_VALUE'
  | 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_CONFIRM_DAYS'
  | 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_CONFIRM_SMART'
  | 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_ADD_MORE' // NEW STEP
  | 'CAMPAIGN_ASK_AGE'
  | 'CAMPAIGN_ASK_GENDER'
  | 'CAMPAIGN_ASK_LOCATION_TYPE'
  | 'CAMPAIGN_ASK_LOCATION_COUNTRY_VALUE'
  | 'CAMPAIGN_ASK_LOCATION_CITY_VALUE'
  | 'CAMPAIGN_AWAITING_CITY_SELECTION' 
  | 'CAMPAIGN_ASK_LOCATION_CITY_RADIUS'
  | 'CAMPAIGN_ASK_LOCATION_COORDS_VALUE'
  | 'CAMPAIGN_ASK_LOCATION_COORDS_RADIUS'
  | 'CAMPAIGN_ASK_LOCATION_ADD_MORE'
  | 'CAMPAIGN_ASK_CUSTOM_AUDIENCE_PROMPT'
  | 'CAMPAIGN_AWAITING_CUSTOM_AUDIENCE_SELECTION'
  | 'CAMPAIGN_ASK_INTERESTS_PROMPT'
  | 'CAMPAIGN_ASK_INTERESTS_VALUE'
  | 'CAMPAIGN_AWAITING_INTEREST_SELECTION'
  | 'AWAITING_ADSET_CREATION'
  | 'AD_ASK_CREATIVE_TYPE'
  | 'AD_ASK_EXISTING_POST_URL'
  | 'AWAITING_POST_VALIDATION'
  | 'AD_ASK_NEW_AD_TYPE'
  | 'AD_ASK_NEW_AD_MESSAGE'
  | 'AD_ASK_NEW_AD_HEADLINE'
  | 'AD_AWAITING_MEDIA_UPLOAD'
  | 'AWAITING_CREATIVE_CREATION'
  | 'AWAITING_AD_PUBLISH'
  | 'QUICK_PROMOTE_ASK_POST_URL'
  | 'QUICK_CREATIVE_AWAIT_INPUT'
  | 'QUICK_CREATIVE_AWAIT_MEDIA_UPLOAD'
  | 'AWAITING_QUICK_CREATIVE_CREATION'
  | 'COMPLETED';


type ActionButton = {
  text: string;
  onClick: () => void;
  disabled?: boolean;
  color?: 'blue' | 'green';
};

type SelectableItem = {
    id: string;
    name: string;
    selected: boolean;
    type: 'interest' | 'custom_audience' | 'source_audience' | 'city';
};

type CampaignActionResult = {
    success: boolean;
    id?: string;
    name?: string;
    error?: string;
    message?: string;
};

type AudienceActionResult = {
    success: boolean;
    message: string;
    newAudienceId?: string;
    newAudienceName?: string;
};

interface ParsedSchedule {
    targetDays: number[];
    parsedHours: number[];
    dayText: string;
    hoursText: string;
    isVague?: 'business_hours';
    error?: string;
}

interface AudienceInfo {
    type?: 'page_messengers' | 'lookalike';
    name?: string;
    retentionDays?: number;
    sourceId?: string;
    sourceName?: string;
    newlyCreated?: { id: string, name: string };
    country?: string;
    ratio?: number;
}
interface CampaignInfo {
    name?: string;
    campaignId?: string;
    adSetName?: string;
    adSetId?: string;
    budgetType?: 'daily' | 'lifetime';
    budgetAmount?: string;
    startDateObj?: Date;
    endDateObj?: Date;
    startDate?: string;
    endDate?: string;
    tempSchedule?: ParsedSchedule;
    ageMin?: number;
    ageMax?: number;
    gender?: Gender;
    locationType?: 'country' | 'city' | 'coordinates';
    geo_locations?: GeoLocationTargeting;
    custom_audiences?: CustomAudience[];
    interests?: Interest[];
    tempCities?: { key: string, name: string }[];
    coords?: { latitude: number, longitude: number };
    postUrl?: string;
    newAdType?: 'image' | 'video';
    newAdMessage?: string;
    newAdHeadline?: string;
    quickCreativeData?: QuickCreativeParseResult;
    mediaType?: 'image' | 'video';
    imageHash?: string;
    videoId?: string;
}

let audienceInfoCollector: AudienceInfo = {};
let campaignInfoCollector: CampaignInfo = {
    geo_locations: {},
    custom_audiences: [],
    interests: []
};

const toLocalISOString = (date: Date) => {
    const tzoffset = (new Date()).getTimezoneOffset() * 60000;
    const localISOTime = (new Date(date.getTime() - tzoffset)).toISOString().slice(0, 16);
    return localISOTime;
}

const parseDateRangeVietnamese = (input: string): { start?: Date; end?: Date; error?: string } => {
    let text = input.toLowerCase()
        .replace(/\b(từ|ngày|kéo dài|áp dụng|diễn ra|chạy|làm)\b/g, '') 
        .replace(/đến|tới|qua|--|~/g, '-')
        .replace('→', '-')
        .replace(/\s+/g, ' ')
        .trim();

    const today = new Date();
    const todayStr = `${today.getDate()}/${today.getMonth() + 1}`;
    text = text.replace('hôm nay', todayStr);

    const parts = text.split('-').map(p => p.trim());
    if (parts.length !== 2) {
        return { error: "Định dạng không hợp lệ. Vui lòng nhập theo dạng 'ngày bắt đầu - ngày kết thúc', ví dụ: '6/10 - 20/10'." };
    }

    const now = new Date();
    const currentYear = now.getFullYear();
    const todayWithoutTime = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const parsePart = (part: string, referenceMonth?: number, referenceYear?: number): { day: number, month: number, year: number } | null => {
        part = part.replace(/(\d{1,2})\s*h/g, '$1').trim();

        const dayThangMonthMatch = part.match(/(\d{1,2})\s*(?:tháng)\s*(\d{1,2})(?:\s*(\d{4}))?/);
        if (dayThangMonthMatch) {
            return { 
                day: parseInt(dayThangMonthMatch[1], 10), 
                month: parseInt(dayThangMonthMatch[2], 10), 
                year: parseInt(dayThangMonthMatch[3], 10) || referenceYear || currentYear
            };
        }

        const withYearMatch = part.match(/(\d{1,2})\s*[\/.]\s*(\d{1,2})\s*[\/.]\s*(\d{4})/);
        if (withYearMatch) {
            return { day: parseInt(withYearMatch[1], 10), month: parseInt(withYearMatch[2], 10), year: parseInt(withYearMatch[3], 10) };
        }
        
        const withoutYearMatch = part.match(/(\d{1,2})\s*[\/.]\s*(\d{1,2})/);
        if (withoutYearMatch) {
            return { day: parseInt(withoutYearMatch[1], 10), month: parseInt(withoutYearMatch[2], 10), year: referenceYear || currentYear };
        }
        
        const dayOnlyMatch = part.match(/^(\d{1,2})$/);
        if (dayOnlyMatch && referenceMonth) {
            return { day: parseInt(dayOnlyMatch[1], 10), month: referenceMonth, year: referenceYear || currentYear };
        }
        
        return null;
    };

    const endPartParsed = parsePart(parts[1]);
    if (!endPartParsed) {
        return { error: "Không thể nhận dạng ngày kết thúc. Vui lòng dùng định dạng 'DD/MM' hoặc 'DD tháng MM'." };
    }

    const startPartParsed = parsePart(parts[0], endPartParsed.month, endPartParsed.year);
    if (!startPartParsed) {
        return { error: "Không thể nhận dạng ngày bắt đầu. Vui lòng dùng định dạng 'DD/MM' hoặc chỉ ngày nếu cùng tháng." };
    }

    let startDate = new Date(startPartParsed.year, startPartParsed.month - 1, startPartParsed.day);
    let endDate = new Date(endPartParsed.year, endPartParsed.month - 1, endPartParsed.day);
    
    const yearWasSpecifiedInStart = !!(parts[0].match(/\d{4}/) || (parts[0].match(/(\d{1,2})\s*(?:tháng)\s*(\d{1,2})(?:\s*(\d{4}))?/) && parts[0].match(/(\d{1,2})\s*(?:tháng)\s*(\d{1,2})(?:\s*(\d{4}))?/)?.[3]));
    const yearWasSpecifiedInEnd = !!(parts[1].match(/\d{4}/) || (parts[1].match(/(\d{1,2})\s*(?:tháng)\s*(\d{1,2})(?:\s*(\d{4}))?/) && parts[1].match(/(\d{1,2})\s*(?:tháng)\s*(\d{1,2})(?:\s*(\d{4}))?/)?.[3]));

    if (!yearWasSpecifiedInStart && startDate < todayWithoutTime) {
        startDate.setFullYear(startDate.getFullYear() + 1);
    }

    if (!yearWasSpecifiedInEnd && endDate < startDate) {
        endDate.setFullYear(startDate.getFullYear());
        if (endDate < startDate) {
           endDate.setFullYear(startDate.getFullYear() + 1);
        }
    }
    
    if (startDate < todayWithoutTime && !input.toLowerCase().includes('hôm nay')) {
        return { error: 'Ngày bắt đầu không được ở trong quá khứ.' };
    }
    if (endDate < startDate) {
        return { error: 'Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.' };
    }

    return { start: startDate, end: endDate };
};


const parseTimeVietnamese = (input: string): { hour?: number; minute?: number; error?: string } => {
    let text = input.toLowerCase().replace(/giờ/g, 'h').trim();

    // Take only the first part if it's a range, to get the start time
    const firstPart = text.split(/đến|tới|-|~/)[0].trim();

    const timeMatch = firstPart.match(/(\d{1,2})\s*[:h]\s*(\d{2})|(\d{1,2})\s*h\b|(\d{1,2})/);
    let hour: number | null = null;
    let minute: number = 0;
    
    if (timeMatch) {
        if (timeMatch[1] !== undefined) {
            hour = parseInt(timeMatch[1], 10);
            minute = parseInt(timeMatch[2], 10);
        } else if (timeMatch[3] !== undefined) {
            hour = parseInt(timeMatch[3], 10);
        } else if (timeMatch[4] !== undefined) {
            hour = parseInt(timeMatch[4], 10);
        }
    }

    if (hour === null) {
        return { error: "Không thể nhận dạng giờ. Vui lòng dùng định dạng '9h', '15:30'." };
    }

    if (hour < 12 && (firstPart.includes('tối') || firstPart.includes('chiều') || firstPart.includes('ch'))) {
        hour += 12;
    }
     if (hour === 12 && firstPart.includes('đêm')) {
        hour = 0;
    }

    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        return { error: `Giờ hoặc phút không hợp lệ (${hour}:${minute}).` };
    }

    return { hour, minute };
};

const parseScheduleVietnamese = (input: string): ParsedSchedule => {
    let text = input.toLowerCase().trim();
    const result: ParsedSchedule = { targetDays: [], parsedHours: [], dayText: '', hoursText: '' };

    if (text.includes('giờ hành chính')) {
        result.isVague = 'business_hours';
        text = text.replace(/giờ hành chính/g, '').trim(); 
    }

    const dayMap: { [key: string]: { days: number[]; text: string } } = {
        'hàng ngày': { days: [0, 1, 2, 3, 4, 5, 6], text: 'Hàng ngày' }, 'mỗi ngày': { days: [0, 1, 2, 3, 4, 5, 6], text: 'Hàng ngày' },
        'cuối tuần': { days: [6, 0], text: 'Cuối tuần' },
        'trong tuần': { days: [1, 2, 3, 4, 5], text: 'Ngày trong tuần' }, 'ngày thường': { days: [1, 2, 3, 4, 5], text: 'Ngày trong tuần' },
        'thứ hai': { days: [1], text: 'Thứ Hai' }, 'thứ 2': { days: [1], text: 'Thứ Hai' }, 't2': { days: [1], text: 'Thứ Hai' },
        'thứ ba': { days: [2], text: 'Thứ Ba' }, 'thứ 3': { days: [2], text: 'Thứ Ba' }, 't3': { days: [2], text: 'Thứ Ba' },
        'thứ tư': { days: [3], text: 'Thứ Tư' }, 'thứ 4': { days: [3], text: 'Thứ Tư' }, 't4': { days: [3], text: 'Thứ Tư' },
        'thứ năm': { days: [4], text: 'Thứ Năm' }, 'thứ 5': { days: [4], text: 'Thứ Năm' }, 't5': { days: [4], text: 'Thứ Năm' },
        'thứ sáu': { days: [5], text: 'Thứ Sáu' }, 'thứ 6': { days: [5], text: 'Thứ Sáu' }, 't6': { days: [5], text: 'Thứ Sáu' },
        'thứ bảy': { days: [6], text: 'Thứ Bảy' }, 'thứ 7': { days: [6], text: 'Thứ Bảy' }, 't7': { days: [6], text: 'Thứ Bảy' },
        'chủ nhật': { days: [0], text: 'Chủ Nhật' }, 'cn': { days: [0], text: 'Chủ Nhật' },
    };

    const dayKeys = Object.keys(dayMap).sort((a, b) => b.length - a.length);
    for (const key of dayKeys) {
        if (text.includes(key)) {
            const currentDays = new Set([...result.targetDays, ...dayMap[key].days]);
            result.targetDays = Array.from(currentDays);
            const currentDayTexts = new Set(result.dayText ? result.dayText.split(', ') : []);
            currentDayTexts.add(dayMap[key].text);
            result.dayText = Array.from(currentDayTexts).join(', ');
            text = text.replace(new RegExp(key, 'g'), '').trim();
        }
    }
    
    if (result.isVague && !text) return result;

    text = text.replace(/\b(từ|lúc|bắt đầu|chạy)\b/g, '').replace(/đến|tới/g, '-').trim();
    const timeRanges = text.split(/và|,/).map(s => s.trim()).filter(Boolean);
    const allHours = new Set<number>();
    
    const parseSingleTime = (timeStr: string): number | null => {
        const cleaned = timeStr.trim().replace('giờ', 'h');
        const hourMatch = cleaned.match(/(\d{1,2})/);
        if (!hourMatch) return null;
        let hour = parseInt(hourMatch[1], 10);
        if (hour === 12 && (cleaned.includes('trưa'))) return 12;
        if (hour === 12 && (cleaned.includes('đêm'))) return 0;
        if (hour < 12 && (cleaned.includes('tối') || cleaned.includes('chiều') || cleaned.includes('ch'))) hour += 12;
        if (hour === 24) hour = 0;
        return (hour >= 0 && hour < 24) ? hour : null;
    };
    
    if (text === 'cả ngày' || text === '24/24') {
        result.parsedHours = Array.from({ length: 24 }, (_, i) => i);
        result.hoursText = 'Cả ngày (0h-23h)';
    } else if (timeRanges.length > 0) {
        for (const range of timeRanges) {
            const parts = range.split('-').map(p => p.trim());
            if (parts.length === 2) {
                const start = parseSingleTime(parts[0]);
                const end = parseSingleTime(parts[1]);
                if (start !== null && end !== null) {
                    if (start <= end) { // Same day range e.g., 8h-17h
                        for (let i = start; i < end; i++) allHours.add(i);
                    } else { // Overnight range e.g., 22h-2h
                        for (let i = start; i < 24; i++) allHours.add(i);
                        for (let i = 0; i < end; i++) allHours.add(i);
                    }
                } else {
                     return { ...result, error: `Khung giờ "${range}" không hợp lệ.` };
                }
            } else {
                 return { ...result, error: `Định dạng giờ "${range}" không hợp lệ. Vui lòng dùng dạng "A-B".` };
            }
        }
        result.parsedHours = [...allHours].sort((a,b) => a-b);
        result.hoursText = text;
    }
    
    if (input.match(/\d{1,2}\/\d{1,2}/)) {
      result.error = "Lịch chạy chỉ có thể áp dụng cho các ngày trong tuần (VD: 'Thứ Hai', 'cuối tuần') chứ không thể áp dụng cho một khoảng ngày cụ thể...";
    }
    
    if (result.parsedHours.length === 0 && result.targetDays.length === 0 && !result.isVague && !result.error) {
        result.error = "Không thể nhận dạng được ngày hoặc giờ từ câu lệnh của bạn.";
    }

    return result;
};


const AiChatWidget: React.FC<AiChatWidgetProps> = ({ adsToken, pageId, pageAccessToken, selectedAdAccount }) => {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [currentStep, setCurrentStep] = useState<ConversationStep>('IDLE');
  const [actionButtons, setActionButtons] = useState<ActionButton[]>([]);
  const [selectableItems, setSelectableItems] = useState<SelectableItem[]>([]);
  const [showUploader, setShowUploader] = useState(false);


  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isAiTyping]);

  const addMessage = (message: any) => {
    setMessages(prev => [...prev, message]);
  };
  
  const startQuickPromotePostFlow = () => {
    setActionButtons([]);
    addMessage({ sender: 'user', text: "Tạo Bài Viết sẵn nhanh" });
    addMessage({ sender: 'ai', text: "OK anh. Để quảng cáo nhanh bài viết, vui lòng dán link bài viết vào đây." });
    setCurrentStep('QUICK_PROMOTE_ASK_POST_URL');
  };

  const startQuickCreativeFlow = () => {
    setActionButtons([]);
    addMessage({ sender: 'user', text: "Tạo QC tin nhắn mới" });
    addMessage({ sender: 'ai', text: "OK anh. Để tạo nhanh quảng cáo media mới (ảnh/video), vui lòng dán toàn bộ thông tin chiến dịch (content, target,...) vào đây." });
    setCurrentStep('QUICK_CREATIVE_AWAIT_INPUT');
  };


  const resetConversation = () => {
    setCurrentStep('IDLE');
    setMessages([{ sender: 'ai', text: 'Chào anh, em là Trợ lý AI. Anh muốn làm gì ạ?' }]);
    setActionButtons([
        { text: 'Tạo qc cơ bản', onClick: startCampaignFlow },
        { text: 'Tạo Bài Viết sẵn nhanh', onClick: startQuickPromotePostFlow },
        { text: 'Tạo QC tin nhắn mới', onClick: startQuickCreativeFlow },
        { text: 'Tạo tệp đối tượng', onClick: startAudienceFlow },
    ]);
    audienceInfoCollector = {};
    campaignInfoCollector = {
        geo_locations: {},
        custom_audiences: [],
        interests: []
    };
    setSelectableItems([]);
    window.dispatchEvent(new CustomEvent('ai-reset-flow'));
  };
  
  const startCampaignFlow = () => {
      setActionButtons([]);
      addMessage({ sender: 'user', text: "Tạo qc cơ bản" });
      addMessage({ sender: 'ai', text: "OK anh. Em sẽ giúp anh tạo chiến dịch quảng cáo. Trước tiên, tên của chiến dịch này là gì ạ?" });
      setCurrentStep('CAMPAIGN_ASK_NAME');
  };
  
  const startAudienceFlow = () => {
      setActionButtons([]);
      addMessage({ sender: 'user', text: "Tạo tệp đối tượng" });
      addMessage({ sender: 'ai', text: 'OK anh. Anh muốn tạo đối tượng từ **Người nhắn tin** cho Page hay **Đối tượng tương tự** ạ?' });
      setActionButtons([
          { text: 'Người nhắn tin', onClick: handleSelectMessengerAudience },
          { text: 'Đối tượng tương tự', onClick: handleSelectLookalikeAudience },
      ]);
      setCurrentStep('AUDIENCE_ASK_TYPE');
  };

  const handleSelectMessengerAudience = () => {
      setActionButtons([]);
      addMessage({ sender: 'user', text: 'Người nhắn tin Page' });
      audienceInfoCollector = { type: 'page_messengers' };

      window.dispatchEvent(new CustomEvent('ai-control-audience', { 
          detail: { action: 'start', payload: { type: 'page_messengers' } } 
      }));
      
      addMessage({ sender: 'ai', text: 'OK, em đã chuyển sang mục tạo đối tượng từ **Người nhắn tin Page**.\n\nTên đối tượng anh muốn đặt là gì?' });
      setCurrentStep('AUDIENCE_ASK_NAME');
  };
  
  const handleSelectLookalikeAudience = async () => {
      setActionButtons([]);
      addMessage({ sender: 'user', text: 'Đối tượng tương tự' });
      audienceInfoCollector = { type: 'lookalike' };

      window.dispatchEvent(new CustomEvent('ai-control-audience', { 
          detail: { action: 'start', payload: { type: 'lookalike' } } 
      }));
      
      setIsAiTyping(true);
      
      try {
        if (!selectedAdAccount?.id || !adsToken) {
            throw new Error("Thông tin tài khoản quảng cáo không có sẵn.");
        }
        const sources = await facebookService.getCustomAudiences(selectedAdAccount.id, adsToken);
        
        if (sources.length === 0) {
            addMessage({ sender: 'ai', text: 'Không tìm thấy đối tượng nguồn nào. Vui lòng tạo một đối tượng tùy chỉnh trước.' });
            setCurrentStep('COMPLETED');
        } else {
             addMessage({ 
                sender: 'ai', 
                text: 'OK, em đã chuyển sang mục tạo **Đối tượng tương tự**.\n\nVui lòng chọn một Đối tượng nguồn từ danh sách bên dưới:',
            });
            setSelectableItems(sources.map(s => ({...s, selected: false, type: 'source_audience'})));
            setCurrentStep('LOOKALIKE_AWAIT_SOURCE_SELECTION');
        }

      } catch (err: any) {
          addMessage({ sender: 'ai', text: `❌ Lỗi khi tải đối tượng nguồn: ${err.message}` });
          setCurrentStep('COMPLETED');
      } finally {
          setIsAiTyping(false);
      }
  };

  const handleSelectSourceAudience = (audience: CustomAudience) => {
      setSelectableItems([]);

      addMessage({ sender: 'user', text: `Chọn nguồn: ${audience.name}` });
      
      audienceInfoCollector.sourceId = audience.id;
      audienceInfoCollector.sourceName = audience.name;

      window.dispatchEvent(new CustomEvent('ai-control-audience', { 
          detail: { action: 'updateField', payload: { field: 'lookalikeSourceId', value: audience.id } } 
      }));

      addMessage({ sender: 'ai', text: 'Đã chọn nguồn. Bây giờ, tên của đối tượng tương tự này là gì ạ?' });
      setCurrentStep('LOOKALIKE_ASK_NAME');
  }

  const handleUpsellAccept = () => {
    setActionButtons([]);
    addMessage({ sender: 'user', text: 'Có, tạo luôn' });
    
    audienceInfoCollector.type = 'lookalike';
    audienceInfoCollector.sourceId = audienceInfoCollector.newlyCreated!.id;

    // Command the UI to switch
    window.dispatchEvent(new CustomEvent('ai-control-audience', { 
        detail: { action: 'start', payload: { type: 'lookalike' } } 
    }));
    window.dispatchEvent(new CustomEvent('ai-control-audience', { 
        detail: { action: 'updateField', payload: { field: 'lookalikeSourceId', value: audienceInfoCollector.sourceId } } 
    }));

    addMessage({ sender: 'ai', text: `OK. Em đã chọn nguồn là "${audienceInfoCollector.newlyCreated!.name}".\n\nTên cho đối tượng tương tự mới này là gì ạ?` });
    setCurrentStep('LOOKALIKE_ASK_NAME');
  };

  const handleUpsellDecline = () => {
      setActionButtons([]);
      addMessage({ sender: 'user', text: 'Không, cảm ơn' });
      addMessage({ sender: 'ai', text: `OK anh.` });
      setActionButtons([{ text: 'Tạo đối tượng khác', onClick: startAudienceFlow }]);
      setCurrentStep('COMPLETED');
  };
    
    const proceedToCreateAdSet = () => {
        setSelectableItems([]);
        setActionButtons([]);
        addMessage({ sender: 'ai', text: "OK. Mọi thông tin đã đủ. Em bắt đầu tạo nhóm quảng cáo nhé..." });
        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
            detail: { action: 'triggerCreateAdSet' }
        }));
        setCurrentStep('AWAITING_ADSET_CREATION');
    };

    const handleSelectDailyBudget = () => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: 'Hàng ngày' });
        campaignInfoCollector.budgetType = 'daily';
        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
            detail: { action: 'updateField', payload: { field: 'budgetType', value: 'daily' } }
        }));
        addMessage({ sender: 'ai', text: 'OK. Ngân sách hàng ngày anh muốn đặt là bao nhiêu?' });
        setCurrentStep('CAMPAIGN_ASK_BUDGET_AMOUNT');
    };

    const handleSelectLifetimeBudget = () => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: 'Trọn đời' });
        campaignInfoCollector.budgetType = 'lifetime';
        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
            detail: { action: 'updateField', payload: { field: 'budgetType', value: 'lifetime' } }
        }));
        addMessage({ sender: 'ai', text: 'OK. Ngân sách trọn đời anh muốn đặt là bao nhiêu?' });
        setCurrentStep('CAMPAIGN_ASK_BUDGET_AMOUNT');
    };
    
    const handleConfirmDates = () => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: 'Xác nhận' });
        
        if (campaignInfoCollector.startDateObj && campaignInfoCollector.endDateObj) {
            const startDateString = toLocalISOString(campaignInfoCollector.startDateObj);
            const endDateString = toLocalISOString(campaignInfoCollector.endDateObj);

            campaignInfoCollector.startDate = startDateString;
            campaignInfoCollector.endDate = endDateString;

            window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                detail: { action: 'updateField', payload: { field: 'startDate', value: startDateString } }
            }));
            window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                detail: { action: 'updateField', payload: { field: 'endDate', value: endDateString } }
            }));
        }
        
        addMessage({ sender: 'ai', text: "OK. Bây giờ vui lòng nhập giờ bắt đầu (VD: '9:00', '15h', '8h sáng')." });
        setCurrentStep('CAMPAIGN_ASK_LIFETIME_START_TIME');
    };
    
    const handleEditDates = () => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: 'Sửa lại' });
        addMessage({ sender: 'ai', text: "OK. Vui lòng nhập lại khoảng ngày chạy (VD: '6/10 - 20/10')." });
        setCurrentStep('CAMPAIGN_ASK_LIFETIME_DATE_RANGE');
    };

    const handleSelectGender = (gender: Gender, label: string) => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: label });
        campaignInfoCollector.gender = gender;
        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
            detail: { action: 'updateField', payload: { field: 'gender', value: gender } }
        }));
        addMessage({ sender: 'ai', text: 'OK. Anh muốn nhắm mục tiêu theo **Quốc gia**, **Thành phố**, hay **Tọa độ**?' });
        setActionButtons([
            { text: 'Quốc gia', onClick: () => handleSelectLocationType('country', 'Quốc gia') },
            { text: 'Thành phố', onClick: () => handleSelectLocationType('city', 'Thành phố') },
            { text: 'Tọa độ', onClick: () => handleSelectLocationType('coordinates', 'Tọa độ') },
        ]);
        setCurrentStep('CAMPAIGN_ASK_LOCATION_TYPE');
    };

    const handleSelectLocationType = (type: 'country' | 'city' | 'coordinates', label: string) => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: label });
        campaignInfoCollector.locationType = type;

        switch(type) {
            case 'country':
                addMessage({ sender: 'ai', text: `OK. Vui lòng nhập tên quốc gia anh muốn nhắm đến (VD: Vietnam).` });
                setCurrentStep('CAMPAIGN_ASK_LOCATION_COUNTRY_VALUE');
                break;
            case 'city':
                addMessage({ sender: 'ai', text: `OK. Vui lòng nhập tên thành phố anh muốn nhắm đến (VD: Hà Nội).` });
                setCurrentStep('CAMPAIGN_ASK_LOCATION_CITY_VALUE');
                break;
            case 'coordinates':
                 addMessage({ sender: 'ai', text: `OK. Vui lòng nhập vĩ độ, kinh độ của vị trí (VD: 21.0285, 105.8542).` });
                 setCurrentStep('CAMPAIGN_ASK_LOCATION_COORDS_VALUE');
                break;
        }
    };

    const handleConfirmCities = () => {
        const selectedCities = selectableItems.filter(item => item.type === 'city' && item.selected);
        if (selectedCities.length === 0) {
            addMessage({ sender: 'ai', text: 'Vui lòng chọn ít nhất một thành phố.' });
            return;
        }

        campaignInfoCollector.tempCities = selectedCities.map(c => ({ key: c.id, name: c.name }));
        setSelectableItems([]);

        addMessage({ sender: 'user', text: `Xác nhận: ${selectedCities.map(c => c.name).join(', ')}` });
        addMessage({ sender: 'ai', text: `OK. Bán kính anh muốn đặt cho các vị trí này là bao nhiêu km? (Tối thiểu 17km)` });
        setCurrentStep('CAMPAIGN_ASK_LOCATION_CITY_RADIUS');
    };
    
    const handleStartInterestFlow = () => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: "Thêm sở thích" });
        addMessage({ sender: 'ai', text: "OK. Vui lòng nhập các sở thích anh muốn nhắm đến, cách nhau bởi dấu phẩy (VD: spa, làm đẹp, mỹ phẩm)." });
        setCurrentStep('CAMPAIGN_ASK_INTERESTS_VALUE');
    };
    
    const handleSkipInterests = () => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: "Bỏ qua sở thích" });
        campaignInfoCollector.interests = [];
        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
            detail: { action: 'updateField', payload: { field: 'interests', value: [] } }
        }));
        proceedToCreateAdSet();
    };

    const handleConfirmInterests = () => {
        const selected = selectableItems.filter(i => i.selected && i.type === 'interest');

        if (selected.length > 0) {
            const newInterests = selected.map(i => ({id: i.id, name: i.name}));
            campaignInfoCollector.interests = [...(campaignInfoCollector.interests || []), ...newInterests];
            window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'interests', value: campaignInfoCollector.interests } } }));
            addMessage({ sender: 'user', text: `Xác nhận: ${newInterests.map(i => i.name).join(', ')}`});
        } else {
            addMessage({ sender: 'user', text: "Hoàn tất chọn sở thích" });
        }
        
        setSelectableItems([]);
        setActionButtons([]);

        addMessage({ sender: 'ai', text: 'OK. Anh có muốn tìm và thêm sở thích khác không?' });
        setActionButtons([
            { text: 'Thêm sở thích khác', onClick: handleAddMoreInterests },
            { text: 'Tiếp tục', onClick: proceedToCreateAdSet },
        ]);
        setCurrentStep('CAMPAIGN_ASK_INTERESTS_PROMPT');
    };

    const handleAddMoreInterests = () => {
        const selected = selectableItems.filter(i => i.selected);
         if (selected.length > 0) {
            campaignInfoCollector.interests = [...(campaignInfoCollector.interests ?? []), ...selected.map(i => ({id: i.id, name: i.name}))];
            window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'interests', value: campaignInfoCollector.interests } } }));
            addMessage({ sender: 'user', text: `Thêm: ${selected.map(i=>i.name).join(', ')} và tìm tiếp...`});
        } else {
            addMessage({ sender: 'user', text: "Thêm sở thích khác"});
        }
        setSelectableItems([]);
        setActionButtons([]);
        addMessage({ sender: 'ai', text: "OK. Vui lòng nhập các sở thích anh muốn nhắm đến, cách nhau bởi dấu phẩy (VD: spa, làm đẹp, mỹ phẩm)." });
        setCurrentStep('CAMPAIGN_ASK_INTERESTS_VALUE');
    };

    const handleSelectableItemClick = (id: string) => {
      setSelectableItems(prev =>
        prev.map((item: SelectableItem) =>
          item.id === id ? { ...item, selected: !item.selected } : item
        )
      );
    };
    
    const handleSelectNewAdType = (type: 'image' | 'video') => {
        setActionButtons([]);
        addMessage({ sender: 'user', text: type === 'image' ? 'Ảnh' : 'Video' });
        campaignInfoCollector.newAdType = type;
        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
            detail: { action: 'updateField', payload: { field: 'newAdType', value: type } }
        }));
        addMessage({ sender: 'ai', text: 'OK. Nội dung chính của quảng cáo là gì?' });
        setCurrentStep('AD_ASK_NEW_AD_MESSAGE');
    };

    const addApiLogToChat = (step: string, status: 'success' | 'error', message: string) => {
        const icon = status === 'success' ? '✅' : '❌';
        addMessage({ sender: 'ai', text: `${icon} **${step}**: ${message}` });
    };

    const handleMediaUploadSuccessForAI = async (
        result: 
            | { type: 'image', value: { hash: string, url: string } } 
            | { type: 'video', value: string }
            | { type: 'greeting_image', value: any } // These are not expected here but satisfy the type
            | { type: 'greeting_video', value: any }
    ) => {
        setShowUploader(false);
        
        if (result.type !== 'image' && result.type !== 'video') return;

        addMessage({ sender: 'ai', text: `✅ Đã nhận ${result.type}.`});

        if (result.type === 'image') {
            campaignInfoCollector.mediaType = 'image';
            campaignInfoCollector.imageHash = result.value.hash;
        } else {
            campaignInfoCollector.mediaType = 'video';
            campaignInfoCollector.videoId = result.value;
        }
        
        setCurrentStep('AWAITING_QUICK_CREATIVE_CREATION');
        setIsAiTyping(true);
        addMessage({ sender: 'ai', text: 'OK. Mọi thông tin đã sẵn sàng. Em bắt đầu tạo toàn bộ chiến dịch cho anh nhé.' });

        const dataToUse = campaignInfoCollector.quickCreativeData!;
        const validatedInterests = campaignInfoCollector.interests || [];

        try {
            const targeting: any = {
                age_min: dataToUse.ageMin,
                age_max: dataToUse.ageMax,
                geo_locations: {},
                targeting_automation: { advantage_audience: 0 },
            };
            if (dataToUse.gender !== 'all') {
                targeting.genders = [dataToUse.gender === 'male' ? 1 : 2];
            }
            if (dataToUse.latitude && dataToUse.longitude) {
                targeting.geo_locations.custom_locations = [{ 
                    latitude: dataToUse.latitude, 
                    longitude: dataToUse.longitude, 
                    radius: 10,
                    distance_unit: 'kilometer' 
                }];
            } else {
                targeting.geo_locations.countries = ['VN'];
            }
            if (validatedInterests.length > 0) {
                targeting.flexible_spec = [{ interests: validatedInterests.map(i => ({ id: i.id, name: i.name })) }];
            }
            
            const creationResult = await quickCreativeFacebookService.createFullCampaignFromMedia({
                adAccountId: selectedAdAccount!.id,
                adsToken: adsToken!,
                pageAccessToken: pageAccessToken!,
                campaignName: dataToUse.campaignName,
                dailyBudget: dataToUse.dailyBudget,
                currency: selectedAdAccount!.currency!,
                message: dataToUse.adContent,
                headline: dataToUse.adHeadline,
                mediaType: campaignInfoCollector.mediaType!,
                imageHash: campaignInfoCollector.imageHash,
                videoId: campaignInfoCollector.videoId,
                targeting: targeting,
                greetingText: dataToUse.greetingText,
                iceBreakerQuestions: dataToUse.iceBreakerQuestions,
            }, addApiLogToChat);

            addMessage({ sender: 'ai', text: `✅ Hoàn tất! Chiến dịch đã được tạo thành công.`});
            addMessage({ sender: 'ai', text: `**Campaign ID**: ${creationResult.campaignId}\n**Ad Set ID**: ${creationResult.adSetId}\n**Ad ID**: ${creationResult.adId}` });
            setActionButtons([{ text: 'Bắt đầu lại', onClick: resetConversation }]);
            setCurrentStep('COMPLETED');

        } catch(err: any) {
            addMessage({ sender: 'ai', text: `❌ Lỗi nghiêm trọng: ${err.message}`});
            setActionButtons([{ text: 'Bắt đầu lại', onClick: resetConversation }]);
            setCurrentStep('COMPLETED');
        } finally {
            setIsAiTyping(false);
        }
    };


  useEffect(() => {
    resetConversation();
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  useEffect(() => {
    const handleAudienceFormResult = (e: Event) => {
        if (currentStep !== 'AWAITING_MESSENGER_AUDIENCE_CREATION' && currentStep !== 'AWAITING_LOOKALIKE_CREATION') return;

        const detail = (e as CustomEvent<AudienceActionResult>).detail;
        if (!detail) return;

        const { success, message, newAudienceId, newAudienceName } = detail;
        setIsAiTyping(false);
        
        if (success) {
            if (newAudienceId && newAudienceName) { // Messenger audience created, offer upsell
                audienceInfoCollector.newlyCreated = { id: newAudienceId, name: newAudienceName };
                addMessage({ sender: 'ai', text: `✅ Tạo đối tượng thành công! Anh có muốn tạo luôn đối tượng tương tự từ tệp này không ạ?` });
                setActionButtons([
                    { text: 'Có, tạo luôn', onClick: handleUpsellAccept },
                    { text: 'Không, cảm ơn', onClick: handleUpsellDecline }
                ]);
                setCurrentStep('AUDIENCE_MESSENGER_CREATED_UPSELL');
            } else { // Lookalike or File audience created, just finish
                addMessage({ sender: 'ai', text: `✅ Hoàn tất! ${message}` });
                setActionButtons([{ text: 'Tạo đối tượng khác', onClick: startAudienceFlow }]);
                setCurrentStep('COMPLETED');
            }
        } else {
            addMessage({ sender: 'ai', text: `❌ Lỗi: ${message}\n\nVui lòng thử lại. Tên đối tượng là gì ạ?` });
            setCurrentStep(audienceInfoCollector.type === 'lookalike' ? 'LOOKALIKE_ASK_NAME' : 'AUDIENCE_ASK_NAME');
        }
    };
    
    const handleCampaignFormResult = (e: Event) => {
        // FIX: Cast the event to the specific CustomEvent type with a generic for `detail` to correctly infer its properties.
        // This resolves the 'unknown' type error when accessing properties like `.id` and `.name` on the `result` object.
        const detail = (e as CustomEvent).detail as { action: string; result: CampaignActionResult };

        if (!detail) {
            return;
        }
        
        const { action, result } = detail;
        setIsAiTyping(false);

        if (action === 'campaignCreated') {
            if (currentStep !== 'AWAITING_CAMPAIGN_CREATION') return;
            if (result.success && result.id && result.name) {
                campaignInfoCollector.campaignId = result.id;
                campaignInfoCollector.name = result.name;
                
                const adSetName = campaignInfoCollector.name;
                campaignInfoCollector.adSetName = adSetName;
                window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                    detail: { action: 'updateField', payload: { field: 'adSetName', value: adSetName } }
                }));

                addMessage({ sender: 'ai', text: `✅ Tạo chiến dịch thành công! (ID: ${result.id}).\n\nBây giờ em sẽ giúp anh thiết lập nhóm quảng cáo. Em đã tự động lấy tên nhóm là "${adSetName}".\n\nOK. Anh muốn chạy ngân sách **Hàng ngày** hay **Trọn đời**?` });
                setActionButtons([
                   { text: 'Hàng ngày', onClick: handleSelectDailyBudget },
                   { text: 'Trọn đời', onClick: handleSelectLifetimeBudget },
                ]);
                setCurrentStep('CAMPAIGN_ASK_BUDGET_TYPE');

            } else {
                addMessage({ sender: 'ai', text: `❌ Lỗi: ${result.error || 'Không thể tạo chiến dịch.'}\n\nVui lòng thử lại. Tên chiến dịch là gì ạ?` });
                setCurrentStep('CAMPAIGN_ASK_NAME');
            }
        } else if (action === 'adSetCreated') {
            if (currentStep !== 'AWAITING_ADSET_CREATION') return;
            if (result.success && result.id) {
                campaignInfoCollector.adSetId = result.id;
                addMessage({ sender: 'ai', text: `✅ Tạo nhóm quảng cáo thành công! (ID: ${result.id}).\n\nTiếp theo, anh muốn dùng **Bài viết có sẵn** hay **Tạo quảng cáo mới**?` });
                setActionButtons([
                    { text: 'Bài viết có sẵn', onClick: () => {
                        setActionButtons([]);
                        addMessage({ sender: 'user', text: "Bài viết có sẵn" });
                        window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'creativeSource', value: 'existing' } } }));
                        addMessage({ sender: 'ai', text: "OK. Vui lòng dán link bài viết vào đây." });
                        setCurrentStep('AD_ASK_EXISTING_POST_URL');
                    } },
                    { text: 'Tạo mới', onClick: () => {
                        setActionButtons([]);
                        addMessage({ sender: 'user', text: "Tạo quảng cáo mới" });
                        window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'creativeSource', value: 'new' } } }));
                        addMessage({ sender: 'ai', text: 'OK. Anh muốn tạo quảng cáo Ảnh hay Video?'});
                        setActionButtons([
                            { text: 'Ảnh', onClick: () => handleSelectNewAdType('image') },
                            { text: 'Video', onClick: () => handleSelectNewAdType('video') }
                        ]);
                        setCurrentStep('AD_ASK_NEW_AD_TYPE');
                    } }
                ]);
                setCurrentStep('AD_ASK_CREATIVE_TYPE');
            } else {
                addMessage({ sender: 'ai', text: `❌ Lỗi: ${result.error || 'Không thể tạo nhóm quảng cáo.'}\n\nVui lòng thử lại từ bước nhập ngân sách.` });
                setCurrentStep('CAMPAIGN_ASK_BUDGET_TYPE');
            }
        } else if (action === 'postValidated') {
            if (currentStep !== 'AWAITING_POST_VALIDATION') return;
            if (result.success && result.message) {
                addMessage({ sender: 'ai', text: `✅ ${result.message}` });
                addMessage({ sender: 'ai', text: "Mọi thứ đã sẵn sàng. Anh có muốn đăng quảng cáo ngay bây giờ không?" });
                setActionButtons([
                    { text: 'Đăng quảng cáo', onClick: () => {
                        setActionButtons([]);
                        addMessage({ sender: 'user', text: 'Đăng quảng cáo' });
                        addMessage({ sender: 'ai', text: 'OK. Đang đăng quảng cáo...' });
                        window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'triggerPublishAd' } }));
                        setCurrentStep('AWAITING_AD_PUBLISH');
                    } }
                ]);
            } else {
                addMessage({ sender: 'ai', text: `❌ Lỗi: ${result.message || 'Không thể xác thực bài viết.'}\n\nVui lòng nhập lại một link khác.` });
                setCurrentStep('AD_ASK_EXISTING_POST_URL');
            }
        } else if (action === 'creativeCreated') {
            if (currentStep !== 'AWAITING_CREATIVE_CREATION') return;
            if (result.success && result.id) {
                addMessage({ sender: 'ai', text: `✅ Tạo creative thành công! (ID: ${result.id})`});
                addMessage({ sender: 'ai', text: 'Bây giờ anh có muốn đăng quảng cáo không?' });
                setActionButtons([
                    { text: 'Đăng quảng cáo', onClick: () => {
                        setActionButtons([]);
                        addMessage({ sender: 'user', text: 'Đăng quảng cáo' });
                        addMessage({ sender: 'ai', text: 'OK. Đang đăng quảng cáo...' });
                        window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'triggerPublishAd' } }));
                        setCurrentStep('AWAITING_AD_PUBLISH');
                    } }
                ]);
            } else {
                addMessage({ sender: 'ai', text: `❌ Lỗi tạo creative: ${result.error}. Vui lòng thử lại.` });
                setCurrentStep('AD_ASK_NEW_AD_TYPE'); // Go back to start of new ad flow
            }
        } else if (action === 'adPublished') {
            if (currentStep !== 'AWAITING_AD_PUBLISH') return;
            if (result.success && result.id) {
                addMessage({ sender: 'ai', text: `✅ Đăng quảng cáo thành công! (Ad ID: ${result.id})` });
                addMessage({ sender: 'ai', text: `Chiến dịch đã hoàn tất và đang ở trạng thái Dừng. Anh có thể xem lại trong Ads Manager.` });
                setActionButtons([
                    { text: 'Bắt đầu lại', onClick: resetConversation }
                ]);
                setCurrentStep('COMPLETED');
            } else {
                addMessage({ sender: 'ai', text: `❌ Lỗi đăng quảng cáo: ${result.error}.` });
                setCurrentStep('COMPLETED'); // End flow on error
            }
        }
    };

    window.addEventListener('audience-form-result', handleAudienceFormResult);
    window.addEventListener('campaign-form-result', handleCampaignFormResult);

    return () => {
      window.removeEventListener('audience-form-result', handleAudienceFormResult);
      window.removeEventListener('campaign-form-result', handleCampaignFormResult);
    };
  }, [currentStep]);
  
  const handleSend = async () => {
    if (!input.trim() || isAiTyping) return;
    const userInput = input.trim();
    addMessage({ sender: 'user', text: userInput });
    setInput('');
    setIsAiTyping(true);

    setTimeout(async () => {
        if (currentStep === 'IDLE') {
            const lowerInput = userInput.toLowerCase();
            if (lowerInput.includes('chiến dịch')) {
                startCampaignFlow();
            } else if (lowerInput.includes('đối tượng')) {
                startAudienceFlow();
            } else {
                addMessage({ sender: 'ai', text: "Em chưa hiểu ý anh. Vui lòng chọn một trong các nút bên dưới." });
            }
            setIsAiTyping(false);
            return;
        }

        switch(currentStep) {
             case 'QUICK_PROMOTE_ASK_POST_URL': {
                const postUrl = userInput;
                window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                    detail: {
                        action: 'startQuickPromote',
                        payload: { postUrl }
                    }
                }));
                addMessage({ sender: 'ai', text: "OK. Em đã chuyển sang form tạo quảng cáo và điền sẵn link cho anh. Vui lòng kiểm tra và hoàn tất ở bên trái nhé." });
                setCurrentStep('COMPLETED');
                setActionButtons([{ text: 'Bắt đầu lại', onClick: resetConversation }]);
                break;
            }
             case 'QUICK_CREATIVE_AWAIT_INPUT': {
                const rawInput = userInput;
                addMessage({ sender: 'ai', text: "OK. Em đang phân tích thông tin anh cung cấp..." });
                try {
                    const parsedData = await quickAiService.parseQuickCreativePrompt(rawInput);
                    campaignInfoCollector.quickCreativeData = parsedData;

                    addMessage({ sender: 'ai', text: "Đang xác thực sở thích..." });
                    const interestPromises = parsedData.interestKeywords.map(keyword => quickCreativeFacebookService.searchInterests(keyword, adsToken!));
                    const interestResults: Interest[][] = await Promise.all(interestPromises);
                    const flatInterests: Interest[] = interestResults.flat();
                    const uniqueInterests: Interest[] = Array.from(new Map(flatInterests.map((item: Interest) => [item.id, item])).values());
                    campaignInfoCollector.interests = uniqueInterests;
            
                    // Format a message to report back to the user
                    const report = `OK, em đã phân tích xong. Anh xem lại nhé:\n- **Tên CD**: ${parsedData.campaignName}\n- **Ngân sách**: ${parsedData.dailyBudget}\n- **Đối tượng**: ${parsedData.ageMin}-${parsedData.ageMax}, ${parsedData.gender}\n- **Sở thích**: ${uniqueInterests.map(i => i.name).join(', ') || '(không có)'}\n- **Tiêu đề**: ${parsedData.adHeadline}\n- **Câu chào**: ${parsedData.greetingText || '(không có)'}\n- **Câu hỏi**: ${parsedData.iceBreakerQuestions?.join(' | ') || '(không có)'}`;
                    addMessage({ sender: 'ai', text: report.trim() });
                    addMessage({ sender: 'ai', text: "Bây giờ, vui lòng upload media cho quảng cáo." });
                    
                    setActionButtons([
                        { text: 'Tải lên Ảnh / Video', onClick: () => {
                            setActionButtons([]);
                            addMessage({ sender: 'user', text: 'Tải lên Ảnh / Video' });
                            setShowUploader(true);
                            setCurrentStep('QUICK_CREATIVE_AWAIT_MEDIA_UPLOAD');
                        } }
                    ]);
                    
                } catch (err: any) {
                    addMessage({ sender: 'ai', text: `❌ Lỗi phân tích: ${err.message}. Vui lòng kiểm tra lại nội dung và thử lại.`});
                    // Stay in the same step
                }
                break;
            }
            case 'CAMPAIGN_ASK_NAME':
                campaignInfoCollector.name = userInput;
                addMessage({ sender: 'ai', text: `OK. Em sẽ bắt đầu tạo chiến dịch "${userInput}". Anh đợi chút nhé...`});
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'triggerCreateCampaign', payload: { name: userInput } } }));
                setCurrentStep('AWAITING_CAMPAIGN_CREATION');
                return;
            
            case 'CAMPAIGN_ASK_BUDGET_AMOUNT': {
                const budgetValue = facebookService.parseBudgetInput(userInput);
                const MIN_BUDGET = 26000;
                if (isNaN(budgetValue) || budgetValue < MIN_BUDGET) {
                    addMessage({ sender: 'ai', text: `Ngân sách không hợp lệ. Vui lòng nhập một số, có thể dùng 'k' cho nghìn hoặc 'tr' cho triệu (VD: 50k, 1tr). Ngân sách tối thiểu là ${MIN_BUDGET.toLocaleString('vi-VN')}đ.` });
                    break;
                }
                
                const budgetStringValue = String(budgetValue);
                campaignInfoCollector.budgetAmount = budgetStringValue;
                const budgetField = campaignInfoCollector.budgetType === 'daily' ? 'dailyBudget' : 'lifetimeBudget';
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: budgetField, value: budgetStringValue } } }));
                
                if (campaignInfoCollector.budgetType === 'lifetime') {
                    const timezone = selectedAdAccount?.timezone_name || 'múi giờ của tài khoản';
                    addMessage({ sender: 'ai', text: `OK, đã nhận ngân sách. Vui lòng nhập khoảng ngày chạy (theo múi giờ ${timezone}), ví dụ: 'hôm nay - 15/10'` });
                    setCurrentStep('CAMPAIGN_ASK_LIFETIME_DATE_RANGE');
                } else {
                    addMessage({ sender: 'ai', text: "OK, đã nhận ngân sách. Tiếp theo, độ tuổi mục tiêu của anh là bao nhiêu? (VD: 20-40)" });
                    setCurrentStep('CAMPAIGN_ASK_AGE');
                }
                break;
            }

            case 'CAMPAIGN_ASK_LIFETIME_DATE_RANGE': {
                const { start, end, error } = parseDateRangeVietnamese(userInput);
                if (error) {
                    addMessage({ sender: 'ai', text: `${error} Vui lòng thử lại.` });
                    break;
                }
                if (start && end) {
                    campaignInfoCollector.startDateObj = start;
                    campaignInfoCollector.endDateObj = end;
                    addMessage({ sender: 'ai', text: `OK, em hiểu là anh muốn chạy từ **${start.toLocaleDateString('vi-VN')}** đến **${end.toLocaleDateString('vi-VN')}**, đúng không ạ?` });
                    setActionButtons([
                        { text: 'Xác nhận', onClick: handleConfirmDates },
                        { text: 'Sửa lại', onClick: handleEditDates },
                    ]);
                    setCurrentStep('CAMPAIGN_CONFIRM_LIFETIME_DATES');
                }
                break;
            }

            case 'CAMPAIGN_ASK_LIFETIME_START_TIME': {
                const { hour, minute, error } = parseTimeVietnamese(userInput);
                if (error) {
                    addMessage({ sender: 'ai', text: `${error} Vui lòng thử lại.` });
                    break;
                }
            
                if (hour !== undefined && minute !== undefined) {
                    const startDate = new Date(campaignInfoCollector.startDateObj!);
                    startDate.setHours(hour, minute, 0, 0); // Reset seconds/ms
            
                    const twentyMinutesFromNow = new Date(Date.now() + 20 * 60 * 1000);
                    
                    if (startDate < twentyMinutesFromNow) {
                        const isToday = campaignInfoCollector.startDateObj?.toDateString() === new Date().toDateString();
                        
                        if (isToday) {
                            // Suggest the earliest possible time
                            const suggestedDate = new Date(Date.now() + 21 * 60 * 1000);
                            const suggestedHour = suggestedDate.getHours();
                            const suggestedMinute = suggestedDate.getMinutes();
            
                            const acceptSuggestion = () => {
                                setActionButtons([]);
                                addMessage({ sender: 'user', text: 'Đồng ý' });
            
                                const newStartDate = new Date(campaignInfoCollector.startDateObj!);
                                newStartDate.setHours(suggestedHour, suggestedMinute);
                                const isoString = toLocalISOString(newStartDate);
                                
                                campaignInfoCollector.startDate = isoString;
                                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'startDate', value: isoString } } }));
                                
                                addMessage({ sender: 'ai', text: `OK, đã cập nhật giờ bắt đầu là ${suggestedHour}:${String(suggestedMinute).padStart(2,'0')}. Giờ kết thúc là mấy giờ ạ?` });
                                setCurrentStep('CAMPAIGN_ASK_LIFETIME_END_TIME');
                            };
                            
                            const chooseAgain = () => {
                                setActionButtons([]);
                                addMessage({ sender: 'user', text: 'Chọn lại giờ khác' });
                                addMessage({ sender: 'ai', text: "OK. Vui lòng nhập lại giờ bắt đầu." });
                                // Stay in the same step
                            };
            
                            addMessage({ sender: 'ai', text: `Giờ bắt đầu (${hour}:${String(minute).padStart(2, '0')}) anh chọn đã qua trong ngày hôm nay. Em đặt giờ bắt đầu là **${suggestedHour}:${String(suggestedMinute).padStart(2, '0')}** (sớm nhất có thể) được không ạ?` });
                            setActionButtons([
                                { text: 'Đồng ý', onClick: acceptSuggestion },
                                { text: 'Chọn lại giờ khác', onClick: chooseAgain },
                            ]);
            
                        } else {
                            // The selected date is in the future, but the time is somehow in the past (edge case).
                            addMessage({ sender: 'ai', text: `Thời gian bắt đầu phải ở trong tương lai (ít nhất 20 phút kể từ bây giờ). Vui lòng chọn giờ khác.` });
                        }
                        break; // Stop further execution in this case
                    }
            
                    // If time is valid, proceed
                    const isoString = toLocalISOString(startDate);
                    campaignInfoCollector.startDate = isoString;
                    window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'startDate', value: isoString } } }));
            
                    addMessage({ sender: 'ai', text: `OK, giờ bắt đầu là ${hour}:${String(minute).padStart(2, '0')}. Giờ kết thúc là mấy giờ ạ?` });
                    setCurrentStep('CAMPAIGN_ASK_LIFETIME_END_TIME');
                }
                break;
            }

            case 'CAMPAIGN_ASK_LIFETIME_END_TIME': {
                const { hour, minute, error } = parseTimeVietnamese(userInput);
                if (error) {
                    addMessage({ sender: 'ai', text: `${error} Vui lòng thử lại.` });
                    break;
                }
                if (hour !== undefined && minute !== undefined) {
                    const endDate = new Date(campaignInfoCollector.endDateObj!);
                    endDate.setHours(hour, minute);
                    
                    const startDate = new Date(campaignInfoCollector.startDate!);
                     if (endDate <= startDate) {
                         addMessage({ sender: 'ai', text: `Thời gian kết thúc phải sau thời gian bắt đầu (${startDate.toLocaleString()}).` });
                         break;
                    }

                    const isoString = toLocalISOString(endDate);
                    campaignInfoCollector.endDate = isoString;
                    window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'endDate', value: isoString } } }));
                    
                    addMessage({ sender: 'ai', text: "OK. Anh có muốn chạy quảng cáo theo lịch trình (chỉ chạy vào một số giờ nhất định trong ngày) không?" });
                    
                    const askForScheduleInput = () => {
                        setActionButtons([]);
                        addMessage({ sender: 'user', text: 'Có, đặt lịch' });
                        window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'isScheduled', value: true } } }));
                        addMessage({ sender: 'ai', text: "OK. Vui lòng nhập khung giờ và ngày anh muốn chạy (VD: 'hàng ngày 9h-17h', 'cuối tuần 8h sáng - 10h tối')." });
                        setCurrentStep('CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_VALUE');
                    };

                    const skipScheduling = () => {
                        setActionButtons([]);
                        addMessage({sender: 'user', text: 'Không, chạy liên tục'});
                        window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'isScheduled', value: false } } }));
                        addMessage({ sender: 'ai', text: `OK, đã hiểu. Quảng cáo sẽ chạy 24/7 trong suốt thời gian diễn ra chiến dịch.` });
                        addMessage({ sender: 'ai', text: "Tiếp theo, độ tuổi mục tiêu của anh là bao nhiêu? (VD: 20-40)" });
                        setCurrentStep('CAMPAIGN_ASK_AGE');
                    };

                    setActionButtons([
                        { text: 'Có, đặt lịch', onClick: askForScheduleInput },
                        { text: 'Không, chạy liên tục', onClick: skipScheduling }
                    ]);
                    setCurrentStep('CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_PROMPT');
                }
                break;
            }
            case 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_VALUE': {
                const schedule = parseScheduleVietnamese(userInput);
                campaignInfoCollector.tempSchedule = schedule;

                if (schedule.error) {
                    addMessage({ sender: 'ai', text: `❌ ${schedule.error} Vui lòng thử lại.` });
                    break;
                }

                if (schedule.isVague === 'business_hours') {
                    addMessage({ sender: 'ai', text: "Dạ, để chính xác nhất, anh/chị có thể cho em biết 'giờ hành chính' cụ thể là từ mấy giờ đến mấy giờ không ạ? Ví dụ: 8h-12h và 13h30-17h30." });
                    break;
                }

                if (schedule.targetDays.length === 0 && schedule.parsedHours.length > 0) {
                    addMessage({ sender: 'ai', text: `OK, em hiểu khung giờ là **${schedule.hoursText}**. Anh muốn áp dụng cho:` });
                    // This logic would need more handlers to be complete, for now we ask the user to be more specific.
                    addMessage({ sender: 'ai', text: `Vui lòng nhập lại bao gồm cả ngày (VD: hàng ngày ${schedule.hoursText})`});
                    break;
                }
                
                if (schedule.targetDays.length > 0 && schedule.parsedHours.length > 0) {
                    const applySchedule = (applySmartly: boolean) => {
                        const schedulePayload: string[] = [];
                        const now = new Date();
                        const currentDay = now.getDay();
                        const currentHour = now.getHours();

                        const isOvernight = /([1-2]\d)h?\s*-\s*([0-9])h?/.test(schedule.hoursText);
                        const dayHours = isOvernight ? schedule.parsedHours.filter(h => h >= 12) : schedule.parsedHours;
                        const nightHours = isOvernight ? schedule.parsedHours.filter(h => h < 12) : [];
                
                        for (const day of schedule.targetDays) {
                            let hoursToApply = dayHours;
                            if (applySmartly && day === currentDay) {
                                hoursToApply = hoursToApply.filter(h => h >= currentHour);
                            }
                            for (const hour of hoursToApply) {
                                schedulePayload.push(`${day}-${hour}`);
                            }
                
                            if (nightHours.length > 0) {
                                const nextDay = (day + 1) % 7;
                                let hoursToApplyNextDay = nightHours;
                                if (applySmartly && nextDay === currentDay) {
                                    hoursToApplyNextDay = hoursToApplyNextDay.filter(h => h >= currentHour);
                                }
                                for (const hour of hoursToApplyNextDay) {
                                    schedulePayload.push(`${nextDay}-${hour}`);
                                }
                            }
                        }

                        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                            detail: { action: 'updateField', payload: { field: 'adSchedule', value: schedulePayload } }
                        }));
                        
                        addMessage({ sender: 'ai', text: `✅ OK, đã đặt lịch chạy cho **${schedule.dayText}** vào các khung giờ **${schedule.hoursText}**.` });
                        
                        setActionButtons([
                            { text: "Thêm lịch khác", onClick: () => { 
                                addMessage({ sender: 'user', text: "Thêm lịch khác"});
                                setActionButtons([]);
                                addMessage({ sender: 'ai', text: "OK. Vui lòng nhập khung giờ và ngày tiếp theo." });
                                setCurrentStep('CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_VALUE');
                             } },
                            { text: "Không, tiếp tục", onClick: () => {
                                addMessage({ sender: 'user', text: "Không, tiếp tục"});
                                setActionButtons([]);
                                addMessage({ sender: 'ai', text: "Tiếp theo, độ tuổi mục tiêu của anh là bao nhiêu? (VD: 20-40)" });
                                setCurrentStep('CAMPAIGN_ASK_AGE');
                            } }
                        ]);
                        setCurrentStep('CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_ADD_MORE');
                    };

                    const now = new Date();
                    const currentDay = now.getDay();
                    const currentHour = now.getHours();
                    let suggestion = '';
                    if (schedule.targetDays.includes(currentDay)) {
                        const pastHours = schedule.parsedHours.filter(h => h < currentHour);
                        if (pastHours.length > 0 && pastHours.length < schedule.parsedHours.length) {
                             suggestion = `Một phần khung giờ hôm nay đã qua. Hôm nay sẽ bắt đầu chạy từ ${currentHour}h. Các ngày sau vẫn chạy đủ. Anh đồng ý chứ?`;
                        }
                    }

                    if (suggestion) {
                        addMessage({ sender: 'ai', text: suggestion });
                        setActionButtons([
                            { text: 'Đồng ý', onClick: () => { addMessage({sender: 'user', text: 'Đồng ý'}); setActionButtons([]); applySchedule(true); } },
                            { text: 'Không, chạy đủ', onClick: () => { addMessage({sender: 'user', text: 'Không, chạy đủ'}); setActionButtons([]); applySchedule(false); } },
                        ]);
                        setCurrentStep('CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_CONFIRM_SMART');
                    } else {
                        applySchedule(false);
                    }
                } else {
                     addMessage({ sender: 'ai', text: "Vui lòng nhập cả ngày và giờ (VD: 'thứ 2 9h-17h')." });
                }
                break;
            }

            case 'CAMPAIGN_ASK_AGE': {
                const numbers = userInput.match(/\d+/g);
                if (!numbers || numbers.length !== 2) {
                    addMessage({ sender: 'ai', text: "Định dạng tuổi không hợp lệ. Vui lòng nhập tuổi nhỏ nhất và tuổi lớn nhất, ví dụ: 22 50." });
                    break;
                }
                
                const ageMin = parseInt(numbers[0], 10);
                const ageMax = parseInt(numbers[1], 10);
                const finalAgeMin = Math.min(ageMin, ageMax);
                const finalAgeMax = Math.max(ageMin, ageMax);

                if (finalAgeMin < 18 || finalAgeMax > 65) {
                     addMessage({ sender: 'ai', text: "Độ tuổi không hợp lệ. Vui lòng chọn độ tuổi từ 18 đến 65." });
                     break;
                }

                campaignInfoCollector.ageMin = finalAgeMin;
                campaignInfoCollector.ageMax = finalAgeMax;
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'ageMin', value: finalAgeMin } } }));
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'ageMax', value: finalAgeMax } } }));

                addMessage({ sender: 'ai', text: 'OK. Giới tính của đối tượng là gì?' });
                setActionButtons([
                    { text: 'Tất cả', onClick: () => handleSelectGender('all', 'Tất cả') },
                    { text: 'Nam', onClick: () => handleSelectGender('male', 'Nam') },
                    { text: 'Nữ', onClick: () => handleSelectGender('female', 'Nữ') },
                ]);
                setCurrentStep('CAMPAIGN_ASK_GENDER');
                break;
            }

            case 'CAMPAIGN_ASK_LOCATION_COUNTRY_VALUE':
                try {
                    const results = await facebookService.searchCountries(userInput, adsToken!);
                    if (results.length === 0) {
                         addMessage({ sender: 'ai', text: `Không tìm thấy quốc gia "${userInput}". Vui lòng thử lại.` });
                    } else {
                        const country = results[0];
                        const currentCountries = campaignInfoCollector.geo_locations?.countries || [];
                        campaignInfoCollector.geo_locations = { ...campaignInfoCollector.geo_locations, countries: [...currentCountries, country.key] };

                        window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                            detail: { action: 'updateField', payload: { field: 'geo_locations', value: campaignInfoCollector.geo_locations } }
                        }));
                        
                        addMessage({ sender: 'ai', text: `OK, đã thêm **${country.name}**. Anh có muốn thêm vị trí khác không?` });
                        setActionButtons([
                            { text: 'Thêm vị trí khác', onClick: () => { setActionButtons([]); setCurrentStep('CAMPAIGN_ASK_LOCATION_TYPE'); addMessage({ sender: 'ai', text: 'OK. Anh muốn nhắm mục tiêu theo **Quốc gia**, **Thành phố**, hay **Tọa độ**?' }); setActionButtons([ { text: 'Quốc gia', onClick: () => handleSelectLocationType('country', 'Quốc gia') }, { text: 'Thành phố', onClick: () => handleSelectLocationType('city', 'Thành phố') }, { text: 'Tọa độ', onClick: () => handleSelectLocationType('coordinates', 'Tọa độ') }, ]); } },
                            { text: 'Tiếp tục', onClick: () => { setActionButtons([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn nhắm mục tiêu đối tượng tùy chỉnh không?` }); setCurrentStep('CAMPAIGN_ASK_CUSTOM_AUDIENCE_PROMPT'); setActionButtons([{text: "Chọn đối tượng", onClick: async () => { setActionButtons([]); setIsAiTyping(true); const audiences = await facebookService.getCustomAudiences(selectedAdAccount!.id, adsToken!); setSelectableItems(audiences.map((a: CustomAudience) => ({...a, selected: false, type: 'custom_audience'}))); addMessage({ sender: 'ai', text: "Vui lòng chọn đối tượng từ danh sách:"}); setIsAiTyping(false); setCurrentStep('CAMPAIGN_AWAITING_CUSTOM_AUDIENCE_SELECTION'); }}, {text: "Bỏ qua", onClick: () => { setActionButtons([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn thêm sở thích không?` }); setCurrentStep('CAMPAIGN_ASK_INTERESTS_PROMPT'); setActionButtons([ { text: 'Thêm sở thích', onClick: handleStartInterestFlow }, { text: 'Bỏ qua & Tiếp tục', onClick: handleSkipInterests }, ]); }} ]); } },
                        ]);
                        setCurrentStep('CAMPAIGN_ASK_LOCATION_ADD_MORE');
                    }
                } catch (err: any) {
                    addMessage({ sender: 'ai', text: `Lỗi khi tìm vị trí: ${err.message}` });
                }
                break;

            case 'CAMPAIGN_ASK_LOCATION_CITY_VALUE':
                 try {
                    const results = await facebookService.searchCities(userInput, adsToken!);
                    if (results.length === 0) {
                         addMessage({ sender: 'ai', text: `Không tìm thấy thành phố "${userInput}". Vui lòng thử lại.` });
                    } else {
                        addMessage({ sender: 'ai', text: `Em đã tìm thấy các vị trí sau. Anh có thể chọn một hoặc nhiều.` });
                        setSelectableItems(results.map((c: City) => ({
                            id: c.key, 
                            name: `${c.name}${c.region ? `, ${c.region}` : ''}`,
                            selected: false, 
                            type: 'city'
                        })));
                        setCurrentStep('CAMPAIGN_AWAITING_CITY_SELECTION');
                    }
                } catch (err: any) {
                    addMessage({ sender: 'ai', text: `Lỗi khi tìm thành phố: ${err.message}` });
                }
                break;

            case 'CAMPAIGN_ASK_LOCATION_CITY_RADIUS': {
                const radius = parseInt(userInput.match(/\d+/)?.[0] || '17', 10);
                if (isNaN(radius) || radius < 17) {
                    addMessage({ sender: 'ai', text: "Bán kính không hợp lệ. Vui lòng nhập một số lớn hơn hoặc bằng 17." });
                    break;
                }
                
                const citiesToAdd = campaignInfoCollector.tempCities;
                if (!citiesToAdd || citiesToAdd.length === 0) {
                    addMessage({ sender: 'ai', text: 'Đã có lỗi xảy ra. Vui lòng chọn lại loại vị trí.' });
                    setCurrentStep('CAMPAIGN_ASK_LOCATION_TYPE');
                    break;
                }
                const currentCities = campaignInfoCollector.geo_locations?.cities || [];
                const newCities = citiesToAdd.map((city: { key: string }) => ({ key: city.key, radius: radius, distance_unit: 'kilometer' as const }));

                campaignInfoCollector.geo_locations = { ...campaignInfoCollector.geo_locations, cities: [...currentCities, ...newCities] };
                campaignInfoCollector.tempCities = [];

                window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                    detail: { action: 'updateField', payload: { field: 'geo_locations', value: campaignInfoCollector.geo_locations } }
                }));

                const cityNames = citiesToAdd.map((c: { name: string }) => c.name).join(', ');
                addMessage({ sender: 'ai', text: `OK, đã thêm **${cityNames} +${radius}km**. Anh có muốn thêm vị trí khác không?` });
                setActionButtons([
                    { text: 'Thêm vị trí khác', onClick: () => { setActionButtons([]); setCurrentStep('CAMPAIGN_ASK_LOCATION_TYPE'); addMessage({ sender: 'ai', text: 'OK. Anh muốn nhắm mục tiêu theo **Quốc gia**, **Thành phố**, hay **Tọa độ**?' }); setActionButtons([ { text: 'Quốc gia', onClick: () => handleSelectLocationType('country', 'Quốc gia') }, { text: 'Thành phố', onClick: () => handleSelectLocationType('city', 'Thành phố') }, { text: 'Tọa độ', onClick: () => handleSelectLocationType('coordinates', 'Tọa độ') }, ]); } },
                    { text: 'Tiếp tục', onClick: () => { setActionButtons([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn nhắm mục tiêu đối tượng tùy chỉnh không?` }); setCurrentStep('CAMPAIGN_ASK_CUSTOM_AUDIENCE_PROMPT'); setActionButtons([{text: "Chọn đối tượng", onClick: async () => { setActionButtons([]); setIsAiTyping(true); const audiences = await facebookService.getCustomAudiences(selectedAdAccount!.id, adsToken!); setSelectableItems(audiences.map((a: CustomAudience) => ({...a, selected: false, type: 'custom_audience'}))); addMessage({ sender: 'ai', text: "Vui lòng chọn đối tượng từ danh sách:"}); setIsAiTyping(false); setCurrentStep('CAMPAIGN_AWAITING_CUSTOM_AUDIENCE_SELECTION'); }}, {text: "Bỏ qua", onClick: () => { setActionButtons([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn thêm sở thích không?` }); setCurrentStep('CAMPAIGN_ASK_INTERESTS_PROMPT'); setActionButtons([ { text: 'Thêm sở thích', onClick: handleStartInterestFlow }, { text: 'Bỏ qua & Tiếp tục', onClick: handleSkipInterests }, ]); }} ]); } },
                ]);
                setCurrentStep('CAMPAIGN_ASK_LOCATION_ADD_MORE');
                break;
            }

            case 'CAMPAIGN_ASK_LOCATION_COORDS_VALUE': {
                const parts = userInput.split(',').map(s => s.trim());
                if (parts.length !== 2 || isNaN(parseFloat(parts[0])) || isNaN(parseFloat(parts[1]))) {
                    addMessage({ sender: 'ai', text: "Định dạng tọa độ không hợp lệ. Vui lòng nhập lại theo dạng: 'vĩ độ, kinh độ'." });
                    break;
                }
                campaignInfoCollector.coords = { latitude: parseFloat(parts[0]), longitude: parseFloat(parts[1]) };
                addMessage({ sender: 'ai', text: `OK, đã nhận tọa độ. Bán kính anh muốn đặt là bao nhiêu km? (Tối thiểu 1km)` });
                setCurrentStep('CAMPAIGN_ASK_LOCATION_COORDS_RADIUS');
                break;
            }

            case 'CAMPAIGN_ASK_LOCATION_COORDS_RADIUS': {
                const radius = parseInt(userInput.match(/\d+/)?.[0] || '1', 10);
                 if (isNaN(radius) || radius < 1) {
                    addMessage({ sender: 'ai', text: "Bán kính không hợp lệ. Vui lòng nhập một số lớn hơn hoặc bằng 1." });
                    break;
                }
                const coords = campaignInfoCollector.coords!;
                const currentCoords = campaignInfoCollector.geo_locations?.custom_locations || [];
                campaignInfoCollector.geo_locations = { ...campaignInfoCollector.geo_locations, custom_locations: [...currentCoords, { ...coords, radius: radius, distance_unit: 'kilometer' }]};

                window.dispatchEvent(new CustomEvent('ai-control-campaign', {
                    detail: { action: 'updateField', payload: { field: 'geo_locations', value: campaignInfoCollector.geo_locations } }
                }));
                addMessage({ sender: 'ai', text: `OK, đã thêm vị trí tọa độ +${radius}km. Anh có muốn thêm vị trí khác không?` });
                setActionButtons([
                    { text: 'Thêm vị trí khác', onClick: () => { setActionButtons([]); setCurrentStep('CAMPAIGN_ASK_LOCATION_TYPE'); addMessage({ sender: 'ai', text: 'OK. Anh muốn nhắm mục tiêu theo **Quốc gia**, **Thành phố**, hay **Tọa độ**?' }); setActionButtons([ { text: 'Quốc gia', onClick: () => handleSelectLocationType('country', 'Quốc gia') }, { text: 'Thành phố', onClick: () => handleSelectLocationType('city', 'Thành phố') }, { text: 'Tọa độ', onClick: () => handleSelectLocationType('coordinates', 'Tọa độ') }, ]); } },
                    { text: 'Tiếp tục', onClick: () => { setActionButtons([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn nhắm mục tiêu đối tượng tùy chỉnh không?` }); setCurrentStep('CAMPAIGN_ASK_CUSTOM_AUDIENCE_PROMPT'); setActionButtons([{text: "Chọn đối tượng", onClick: async () => { setActionButtons([]); setIsAiTyping(true); const audiences = await facebookService.getCustomAudiences(selectedAdAccount!.id, adsToken!); setSelectableItems(audiences.map((a: CustomAudience) => ({...a, selected: false, type: 'custom_audience'}))); addMessage({ sender: 'ai', text: "Vui lòng chọn đối tượng từ danh sách:"}); setIsAiTyping(false); setCurrentStep('CAMPAIGN_AWAITING_CUSTOM_AUDIENCE_SELECTION'); }}, {text: "Bỏ qua", onClick: () => { setActionButtons([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn thêm sở thích không?` }); setCurrentStep('CAMPAIGN_ASK_INTERESTS_PROMPT'); setActionButtons([ { text: 'Thêm sở thích', onClick: handleStartInterestFlow }, { text: 'Bỏ qua & Tiếp tục', onClick: handleSkipInterests }, ]); }} ]); } },
                ]);
                setCurrentStep('CAMPAIGN_ASK_LOCATION_ADD_MORE');
                break;
            }
            
            case 'CAMPAIGN_ASK_INTERESTS_VALUE': {
                const keywords = userInput.split(',').map(k => k.trim()).filter(Boolean);
                if (keywords.length === 0) {
                     addMessage({ sender: 'ai', text: "Vui lòng nhập ít nhất một từ khóa sở thích." });
                     break;
                }
                addMessage({ sender: 'ai', text: `Đang tìm kiếm sở thích cho: ${keywords.join(', ')}...` });
                const interestPromises = keywords.map(keyword => facebookService.searchInterests(keyword, adsToken!));
                const results = await Promise.all(interestPromises);
                const allInterests = results.flat();
                const uniqueInterests = Array.from(new Map(allInterests.map((item: Interest) => [item.id, item])).values());

                if (uniqueInterests.length === 0) {
                    addMessage({ sender: 'ai', text: `Không tìm thấy sở thích nào. Vui lòng thử lại với các từ khóa khác.` });
                    setCurrentStep('CAMPAIGN_ASK_INTERESTS_VALUE');
                } else {
                    addMessage({ sender: 'ai', text: `Em đã tìm thấy các sở thích sau. Anh có thể chọn một hoặc nhiều. (Khuyến nghị 3-5 sở thích)` });
                    setSelectableItems(uniqueInterests.map(i => ({id: i.id, name: i.name, selected: false, type: 'interest'})));
                    setActionButtons([
                        { text: "Xác nhận & Thêm tiếp", onClick: handleAddMoreInterests, color: 'green' },
                        { text: "Xác nhận & Hoàn tất", onClick: handleConfirmInterests, color: 'green' }
                    ]);
                    setCurrentStep('CAMPAIGN_AWAITING_INTEREST_SELECTION');
                }
                break;
            }

            case 'AD_ASK_EXISTING_POST_URL': {
                campaignInfoCollector.postUrl = userInput;
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'postUrl', value: userInput } } }));
                addMessage({ sender: 'ai', text: "OK. Em đang kiểm tra link bài viết..." });
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'triggerValidatePost', payload: { url: userInput } } }));
                setCurrentStep('AWAITING_POST_VALIDATION');
                return;
            }
            
            case 'AD_ASK_NEW_AD_MESSAGE':
                campaignInfoCollector.newAdMessage = userInput;
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateNewAdField', payload: { field: 'message', value: userInput } } }));
                addMessage({ sender: 'ai', text: 'Đã nhận nội dung. Tiếp theo, tiêu đề quảng cáo là gì?' });
                setCurrentStep('AD_ASK_NEW_AD_HEADLINE');
                break;

            case 'AD_ASK_NEW_AD_HEADLINE':
                campaignInfoCollector.newAdHeadline = userInput;
                const headlineField = campaignInfoCollector.newAdType === 'image' ? 'name' : 'title';
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateNewAdField', payload: { field: headlineField, value: userInput } } }));
                addMessage({ sender: 'ai', text: 'OK. Bây giờ, vui lòng upload file media ở form bên trái nhé.' });
                window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'openUploader' } }));
                setCurrentStep('AD_AWAITING_MEDIA_UPLOAD');
                return; // AI is waiting for an event

            // --- AUDIENCE FLOW ---
            case 'AUDIENCE_ASK_NAME':
                audienceInfoCollector.name = userInput;
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'updateField', payload: { field: 'audienceName', value: userInput } } }));
                addMessage({ sender: 'ai', text: `OK. Thời gian giữ lại (số ngày) mà anh muốn là bao nhiêu? (Tối đa 365 ngày)` });
                setCurrentStep('AUDIENCE_ASK_RETENTION');
                break;

            case 'AUDIENCE_ASK_RETENTION': {
                const days = parseInt(userInput.match(/\d+/)?.[0] || '365', 10);
                if (isNaN(days) || days < 1 || days > 365) {
                    addMessage({ sender: 'ai', text: "Số ngày không hợp lệ. Vui lòng nhập một số từ 1 đến 365." });
                    break;
                }
                audienceInfoCollector.retentionDays = days;
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'updateField', payload: { field: 'retentionDays', value: days } } }));
                addMessage({ sender: 'ai', text: `OK. Em sẽ tạo đối tượng "${audienceInfoCollector.name}" với thời gian giữ lại là ${days} ngày. Anh đợi chút nhé...`});
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'triggerCreate' } }));
                setCurrentStep('AWAITING_MESSENGER_AUDIENCE_CREATION');
                return;
            }

            case 'LOOKALIKE_ASK_NAME':
                audienceInfoCollector.name = userInput;
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'updateField', payload: { field: 'audienceName', value: userInput } } }));
                addMessage({ sender: 'ai', text: `OK. Anh muốn nhắm mục tiêu quốc gia nào? (VD: VN, US, ...)` });
                setCurrentStep('LOOKALIKE_ASK_COUNTRY');
                break;

            case 'LOOKALIKE_ASK_COUNTRY':
                audienceInfoCollector.country = userInput.toUpperCase();
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'updateField', payload: { field: 'lookalikeCountry', value: userInput.toUpperCase() } } }));
                addMessage({ sender: 'ai', text: `OK. Quy mô đối tượng mà anh muốn là bao nhiêu (từ 1% đến 10%)?` });
                setCurrentStep('LOOKALIKE_ASK_RATIO');
                break;
            
            case 'LOOKALIKE_ASK_RATIO': {
                const ratio = parseInt(userInput.match(/\d+/)?.[0] || '1', 10);
                if (isNaN(ratio) || ratio < 1 || ratio > 10) {
                    addMessage({ sender: 'ai', text: "Quy mô không hợp lệ. Vui lòng nhập một số từ 1 đến 10." });
                    break;
                }
                audienceInfoCollector.ratio = ratio;
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'updateField', payload: { field: 'lookalikeRatio', value: ratio } } }));
                addMessage({ sender: 'ai', text: `OK. Em sẽ tạo đối tượng tương tự "${audienceInfoCollector.name}" ở quốc gia ${audienceInfoCollector.country} với quy mô ${ratio}%. Anh đợi chút nhé...`});
                window.dispatchEvent(new CustomEvent('ai-control-audience', { detail: { action: 'triggerCreate' } }));
                setCurrentStep('AWAITING_LOOKALIKE_CREATION');
                return;
            }
                
            default:
                addMessage({ sender: 'ai', text: 'Em chưa hiểu ý anh. Anh có thể nói rõ hơn được không ạ?' });
                break;
        }
        setIsAiTyping(false);
    }, 500);
  };

  const getInputPlaceholder = () => {
      if (isAiTyping) return "AI đang trả lời...";
      if (actionButtons.length > 0 
        || currentStep.startsWith('AWAITING_')
        || currentStep === 'QUICK_CREATIVE_AWAIT_MEDIA_UPLOAD'
        || currentStep === 'AUDIENCE_MESSENGER_CREATED_UPSELL'
        || currentStep === 'CAMPAIGN_CONFIRM_LIFETIME_DATES'
        || currentStep === 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_PROMPT'
        || currentStep === 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_CONFIRM_SMART'
        || currentStep === 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_ADD_MORE'
        || currentStep === 'CAMPAIGN_ASK_INTERESTS_PROMPT'
        || currentStep === 'CAMPAIGN_ASK_LOCATION_ADD_MORE'
        || currentStep === 'AD_ASK_CREATIVE_TYPE'
      ) {
          return "Vui lòng chọn một tùy chọn...";
      }
      return "Nhập tin nhắn...";
  }
  
  const isInputDisabled = () => {
      return isAiTyping 
        || actionButtons.length > 0 
        || currentStep.startsWith('AWAITING_')
        || currentStep === 'QUICK_CREATIVE_AWAIT_MEDIA_UPLOAD'
        || currentStep === 'AUDIENCE_MESSENGER_CREATED_UPSELL'
        || currentStep === 'CAMPAIGN_CONFIRM_LIFETIME_DATES'
        || currentStep === 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_PROMPT'
        || currentStep === 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_CONFIRM_SMART'
        || currentStep === 'CAMPAIGN_ASK_LIFETIME_AD_SCHEDULE_ADD_MORE'
        || currentStep === 'CAMPAIGN_ASK_INTERESTS_PROMPT'
        || currentStep === 'CAMPAIGN_ASK_LOCATION_ADD_MORE'
        || currentStep === 'AD_ASK_CREATIVE_TYPE'
  }

    const getSelectableItemClasses = (item: SelectableItem) => {
        if (item.type === 'interest') {
            return `px-3 py-1.5 text-xs font-semibold rounded-full transition-colors ${
                item.selected
                ? 'bg-green-600 text-white'
                : 'bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900 dark:text-green-200 dark:hover:bg-green-800'
            }`;
        }
        // Default for cities, audiences etc.
        return `w-full text-left p-2 text-sm rounded-md transition-colors ${
            item.selected
            ? 'bg-blue-600 text-white ring-2 ring-blue-400'
            : 'bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/50'
        }`;
    };

  return (
    <div className="w-full h-full bg-white dark:bg-gray-800 flex flex-col overflow-hidden font-sans">
        <div className="bg-indigo-600 text-white p-3 font-bold flex justify-between items-center flex-shrink-0">
            <span>Trợ lý AI ✨</span>
            {currentStep !== 'IDLE' && (
                <button 
                    onClick={resetConversation}
                    className="p-1 text-indigo-200 hover:text-white"
                    title="Reset và bắt đầu lại"
                >
                    <RefreshIcon className="w-5 h-5" />
                </button>
            )}
        </div>

        <div className="flex-1 p-3 overflow-y-auto bg-gray-50 dark:bg-gray-900/50">
        {messages.map((msg, i) => (
            <div key={i} className="mb-3 clear-both">
                <div className={`p-3 rounded-2xl max-w-[85%] ${
                    msg.sender === 'user'
                    ? 'bg-blue-600 text-white float-right rounded-br-none'
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 float-left rounded-bl-none'
                }`}
                >
                {msg.text.split('\n').map((line: string, index: number) => (
                    <span key={index} className="block whitespace-pre-wrap text-sm" dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>') }}></span>
                ))}
                </div>
            </div>
        ))}
        {isAiTyping && (
            <div className="mb-3 clear-both">
                <div className="p-3 rounded-2xl max-w-[85%] bg-gray-200 dark:bg-gray-700 float-left rounded-bl-none flex items-center space-x-1">
                    <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce delay-0"></span>
                    <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce delay-150"></span>
                    <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce delay-300"></span>
                </div>
            </div>
        )}
        {selectableItems.length > 0 && (
            <div className={`clear-both mt-2 ${
                selectableItems[0]?.type === 'interest' 
                ? 'flex flex-wrap gap-2' 
                : 'space-y-2'
            }`}>
                 <div className="max-h-48 overflow-y-auto space-y-2 pr-2 w-full">
                    {selectableItems.map((item: SelectableItem) => (
                        <button
                            key={item.id}
                            onClick={() => {
                                if (item.type === 'source_audience') {
                                    handleSelectSourceAudience(item as CustomAudience);
                                } else {
                                    handleSelectableItemClick(item.id)
                                }
                            }}
                            className={getSelectableItemClasses(item)}
                        >
                            {item.name}
                        </button>
                    ))}
                 </div>
                 {selectableItems[0]?.type === 'custom_audience' && (
                     <div className="flex justify-start gap-2 pt-2">
                        <button onClick={() => { const selected = selectableItems.filter((i): i is SelectableItem & { type: 'custom_audience' } => i.selected && i.type === 'custom_audience'); campaignInfoCollector.custom_audiences = selected.map(i => ({id: i.id, name: i.name})); window.dispatchEvent(new CustomEvent('ai-control-campaign', { detail: { action: 'updateField', payload: { field: 'custom_audiences', value: campaignInfoCollector.custom_audiences } } })); setSelectableItems([]); addMessage({ sender: 'ai', text: `OK. Anh có muốn thêm sở thích không?` }); setCurrentStep('CAMPAIGN_ASK_INTERESTS_PROMPT'); setActionButtons([ { text: 'Thêm sở thích', onClick: handleStartInterestFlow }, { text: 'Bỏ qua & Tiếp tục', onClick: handleSkipInterests }, ]); }} className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg shadow-md hover:bg-blue-700">Xác nhận</button>
                     </div>
                 )}
            </div>
        )}
        {currentStep === 'CAMPAIGN_AWAITING_CITY_SELECTION' && (
            <div className="clear-both flex justify-start flex-wrap gap-2 mt-2">
                <button
                    onClick={handleConfirmCities}
                    className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75"
                >
                    Xác nhận vị trí
                </button>
            </div>
        )}
        {actionButtons.length > 0 && (
            <div className="clear-both flex justify-start flex-wrap gap-2 mt-2">
                {actionButtons.map((btn, i) => {
                    const colorClasses = btn.color === 'green'
                        ? 'bg-green-600 hover:bg-green-700 focus:ring-green-500'
                        : 'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500';
                    return (
                        <button key={i} onClick={btn.onClick} disabled={btn.disabled} className={`px-4 py-2 text-sm font-semibold text-white rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-opacity-75 disabled:bg-gray-400 ${colorClasses}`}>
                            {btn.text}
                        </button>
                    );
                })}
            </div>
        )}
        <div ref={messagesEndRef} />
        </div>
        
        {showUploader && (
            <MediaUploader 
                uploadContext="ad"
                adAccountId={selectedAdAccount!.id}
                adsToken={adsToken!}
                onUploadSuccess={handleMediaUploadSuccessForAI}
                onClose={() => setShowUploader(false)}
            />
        )}

        <div className="p-2 border-t border-gray-200 dark:border-gray-700 flex items-center">
        <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            className="flex-1 border-none p-2 bg-transparent dark:text-white focus:outline-none"
            placeholder={getInputPlaceholder()}
            disabled={isInputDisabled()}
        />
        <button 
            onClick={handleSend}
            disabled={isInputDisabled() || !input.trim()}
            className="bg-blue-600 text-white rounded-full w-10 h-10 flex items-center justify-center disabled:bg-blue-400 dark:disabled:bg-blue-800 flex-shrink-0"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
        </button>
        </div>
    </div>
  );
};

export default AiChatWidget;
