
import React, { useState } from 'react';
import { MegaphoneIcon } from './Icons';

interface AdsLoginProps {
  onLogin: (token: string) => void;
}

const AdsLogin: React.FC<AdsLoginProps> = ({ onLogin }) => {
  const [adsToken, setAdsToken] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adsToken.trim()) return;
    onLogin(adsToken);
  };

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-lg shadow-lg dark:bg-gray-800">
        <div className="text-center">
          <div className="flex justify-center items-center mb-4">
             <MegaphoneIcon className="w-12 h-12 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Quản lý Quảng cáo</h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            Đăng nhập bằng Ads User Access Token
          </p>
        </div>
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="adsToken" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              User Access Token
            </label>
            <div className="mt-1">
              <input
                id="adsToken"
                name="adsToken"
                type="password"
                required
                value={adsToken}
                onChange={(e) => setAdsToken(e.target.value)}
                className="w-full px-3 py-2 text-gray-900 bg-gray-50 border border-gray-300 rounded-md shadow-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-green-500 focus:border-green-500"
                placeholder="Dán token của bạn vào đây"
              />
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
              Token cần có quyền `ads_read`. Thông tin được lưu an toàn trên trình duyệt.
            </p>
          </div>
          <div>
            <button
              type="submit"
              disabled={!adsToken.trim()}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-green-400 disabled:cursor-not-allowed"
            >
              Tải danh sách tài khoản
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdsLogin;