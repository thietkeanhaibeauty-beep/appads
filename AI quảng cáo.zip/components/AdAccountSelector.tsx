
import React, { useState, useEffect, useMemo } from 'react';
import * as facebookService from '../services/facebookService';
import { AdAccount } from '../types';
import Spinner from './Spinner';
import { LogoutIcon, ExclamationCircleIcon, MegaphoneIcon, SearchIcon } from './Icons';

interface AdAccountSelectorProps {
  adsAccessToken: string;
  onAccountSelect: (account: AdAccount) => void;
  onLogout: () => void;
}

const AdAccountSelector: React.FC<AdAccountSelectorProps> = ({ adsAccessToken, onAccountSelect, onLogout }) => {
  const [accounts, setAccounts] = useState<AdAccount[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchAccounts = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const fetchedAccounts = await facebookService.getAdAccounts(adsAccessToken);
        setAccounts(fetchedAccounts);
      } catch (err: any) {
        setError(err.message || 'Đã xảy ra lỗi không xác định.');
        if (err.message.includes('token')) {
          onLogout();
        }
      } finally {
        setIsLoading(false);
      }
    };
    fetchAccounts();
  }, [adsAccessToken, onLogout]);
  
  const { activeAccounts, disabledAccounts } = useMemo(() => {
    const filtered = accounts.filter(acc => 
      acc.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    return {
      activeAccounts: filtered.filter(acc => acc.account_status === 1),
      disabledAccounts: filtered.filter(acc => acc.account_status !== 1),
    };
  }, [accounts, searchTerm]);

  const AccountCard: React.FC<{ account: AdAccount }> = ({ account }) => (
    <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow ring-1 ring-gray-200 dark:ring-gray-700">
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-gray-900 truncate dark:text-white">{account.name}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{account.business_name || 'Tài khoản cá nhân'}</p>
        </div>
        {account.account_status === 1 && (
           <button
            onClick={() => onAccountSelect(account)}
            className="ml-4 px-3 py-1.5 text-xs font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            Chọn
          </button>
        )}
      </div>
      <p className="text-xs font-mono text-gray-400 dark:text-gray-500 mt-2">{account.id}</p>
    </div>
  );

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-64">
          <Spinner />
          <p className="mt-4 text-gray-600 dark:text-gray-400">Đang tải tài khoản quảng cáo...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="p-4 my-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-900 dark:text-red-300 flex items-center">
          <ExclamationCircleIcon className="w-5 h-5 mr-3 flex-shrink-0" />
          <div>
            <span className="font-medium">Tải thất bại!</span> {error}
          </div>
        </div>
      );
    }

    return (
      <>
        <div className="relative mb-6">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3">
            <SearchIcon className="w-5 h-5 text-gray-400" />
          </span>
          <input
            type="text"
            placeholder="Tìm theo tên tài khoản..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full py-2 pl-10 pr-4 text-gray-900 bg-gray-50 border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-green-500 focus:border-green-500"
          />
        </div>

        {accounts.length === 0 && !isLoading ? (
          <p className="text-center text-gray-500 dark:text-gray-400 py-10">Không tìm thấy tài khoản quảng cáo nào.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Active Accounts Column */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-green-600 dark:text-green-400">Hoạt động ({activeAccounts.length})</h3>
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {activeAccounts.length > 0 ? (
                  activeAccounts.map(acc => <AccountCard key={acc.id} account={acc} />)
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 italic">Không có tài khoản hoạt động nào.</p>
                )}
              </div>
            </div>

            {/* Disabled Accounts Column */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-red-600 dark:text-red-400">Vô hiệu hóa ({disabledAccounts.length})</h3>
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {disabledAccounts.length > 0 ? (
                  disabledAccounts.map(acc => <AccountCard key={acc.id} account={acc} />)
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 italic">Không có tài khoản vô hiệu hóa nào.</p>
                )}
              </div>
            </div>
          </div>
        )}
      </>
    );
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
      <div className="w-full max-w-5xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
                <MegaphoneIcon className="w-6 h-6 mr-3 text-green-500" />
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Chọn tài khoản quảng cáo</h2>
            </div>
          <button onClick={onLogout} title="Đăng xuất" className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-400">
            <LogoutIcon className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6">
            {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default AdAccountSelector;