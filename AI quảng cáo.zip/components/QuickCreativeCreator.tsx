import React, { useState, useCallback, useEffect } from 'react';
import { AdAccount, Interest } from '../types';
import * as quickCreativeFacebookService from '../services/quickCreativeFacebookService';
import * as quickAiService from '../services/quickAiService';
import { PhotoIcon, CheckCircleIcon, ExclamationCircleIcon, UploadIcon, PencilIcon } from './Icons';
import Spinner from './Spinner';
import MediaUploader from './MediaUploader';

interface QuickCreativeCreatorProps {
    selectedAccount: AdAccount;
    adsToken: string;
    pageAccessToken: string | null;
}

type Status = 'input' | 'parsing' | 'confirming' | 'creating' | 'completed' | 'error';

interface EnrichedData extends quickAiService.QuickCreativeParseResult {
    validatedInterests: Interest[];
}

const QuickCreativeCreator: React.FC<QuickCreativeCreatorProps> = ({ selectedAccount, adsToken, pageAccessToken }) => {
    const [status, setStatus] = useState<Status>('input');
    const [rawInput, setRawInput] = useState('');
    const [enrichedData, setEnrichedData] = useState<EnrichedData | null>(null);

    const [mediaType, setMediaType] = useState<'image' | 'video' | null>(null);
    const [imageHash, setImageHash] = useState<string | null>(null);
    const [videoId, setVideoId] = useState<string | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    
    const [error, setError] = useState<string | null>(null);
    const [apiLogs, setApiLogs] = useState<{ step: string, status: 'success' | 'error', message: string }[]>([]);
    const [createdIds, setCreatedIds] = useState({ campaignId: '', adSetId: '', adId: '' });

    const [showUploader, setShowUploader] = useState(false);

    const resetState = useCallback(() => {
        setStatus('input');
        setError(null);
        setApiLogs([]);
        setCreatedIds({ campaignId: '', adSetId: '', adId: '' });
        setRawInput('');
        setEnrichedData(null);
        setMediaType(null);
        setImageHash(null);
        setVideoId(null);
        setPreviewUrl(null);
    }, []);

    const addApiLog = useCallback((step: string, status: 'success' | 'error', message: string) => {
        setApiLogs(prev => [...prev, { step, status, message }]);
    }, []);
    
    const handleCreate = useCallback(async () => {
        const dataToUse = enrichedData;
        const finalMediaType = mediaType;
        const finalImageHash = imageHash;
        const finalVideoId = videoId;
    
        if (!pageAccessToken || !dataToUse || !finalMediaType) {
            const errorMsg = "Thiếu thông tin cần thiết (dữ liệu, media, hoặc token).";
            setError(errorMsg);
            setStatus('error');
            return;
        }
        setStatus('creating');
        setError(null);
    
        try {
            const interestPromises = dataToUse.interestKeywords.map((keyword: string) => quickCreativeFacebookService.searchInterests(keyword, adsToken));
            const interestResults: Interest[][] = await Promise.all(interestPromises);
            const flatInterests: Interest[] = interestResults.flat();
            const validatedInterests: Interest[] = Array.from(new Map(flatInterests.map((item: Interest) => [item.id, item])).values());
            
            const targeting: any = {
                age_min: dataToUse.ageMin,
                age_max: dataToUse.ageMax,
                geo_locations: {},
                targeting_automation: { advantage_audience: 0 },
            };
            if (dataToUse.gender !== 'all') {
                targeting.genders = [dataToUse.gender === 'male' ? 1 : 2];
            }
            if (dataToUse.latitude && dataToUse.longitude) {
                targeting.geo_locations.custom_locations = [{ 
                    latitude: dataToUse.latitude, 
                    longitude: dataToUse.longitude, 
                    radius: 10,
                    distance_unit: 'kilometer' 
                }];
            } else {
                targeting.geo_locations.countries = ['VN'];
            }
            if (validatedInterests.length > 0) {
                targeting.flexible_spec = [{ interests: validatedInterests.map(i => ({ id: i.id, name: i.name })) }];
            }

            const result = await quickCreativeFacebookService.createFullCampaignFromMedia({
                adAccountId: selectedAccount.id,
                adsToken,
                pageAccessToken,
                campaignName: dataToUse.campaignName,
                dailyBudget: dataToUse.dailyBudget,
                currency: selectedAccount.currency!,
                message: dataToUse.adContent,
                headline: dataToUse.adHeadline,
                mediaType: finalMediaType,
                imageHash: finalImageHash || undefined,
                videoId: finalVideoId || undefined,
                targeting: targeting,
                greetingText: dataToUse.greetingText,
                iceBreakerQuestions: dataToUse.iceBreakerQuestions,
            }, addApiLog);
            
            setCreatedIds(result);
            setStatus('completed');

        } catch (err: any) {
            setError(err.message);
            addApiLog('Lỗi nghiêm trọng', 'error', err.message);
            setStatus('error');
        }
    }, [enrichedData, mediaType, imageHash, videoId, adsToken, pageAccessToken, selectedAccount, addApiLog]);

    const handleParse = async () => {
        if (!rawInput.trim() || !mediaType) return;
        setStatus('parsing');
        setError(null);
        setApiLogs([]);
        setEnrichedData(null);

        try {
            const parsedData = await quickAiService.parseQuickCreativePrompt(rawInput);
            
            // Validation for ice breakers
            const iceBreakerQuestions = parsedData.iceBreakerQuestions || [];
            if (iceBreakerQuestions.length > 4) {
                throw new Error(`Chỉ được phép có tối đa 4 câu hỏi thường gặp. Bạn đã cung cấp ${iceBreakerQuestions.length} câu.`);
            }
            const longQuestion = iceBreakerQuestions.find(q => q.length > 80);
            if (longQuestion) {
                 throw new Error(`Câu hỏi "${longQuestion}" quá dài (hơn 80 ký tự). Vui lòng rút ngắn lại.`);
            }

            const interestPromises = parsedData.interestKeywords.map(keyword => quickCreativeFacebookService.searchInterests(keyword, adsToken));
            const interestResults: Interest[][] = await Promise.all(interestPromises);
            const flatInterests: Interest[] = interestResults.flat();
            const uniqueInterests: Interest[] = Array.from(new Map(flatInterests.map((item: Interest) => [item.id, item])).values());
            
            setEnrichedData({
                ...parsedData,
                validatedInterests: uniqueInterests,
            });
            setStatus('confirming');

        } catch (err: any) {
            setError(err.message || "Lỗi không xác định khi phân tích dữ liệu.");
            setStatus('error');
        }
    };

    const handleMediaUploadSuccess = (
        result: 
        | { type: 'image', value: {hash: string, url: string} } 
        | { type: 'video', value: string }
        | { type: 'greeting_image', value: any } // Added to satisfy the type from MediaUploader, not used here.
        | { type: 'greeting_video', value: any } // Added to satisfy the type from MediaUploader, not used here.
    ) => {
        if (result.type === 'image') {
            setMediaType('image');
            setImageHash(result.value.hash);
            setVideoId(null);
            setPreviewUrl(result.value.url);
        } else if (result.type === 'video') {
            setMediaType('video');
            setImageHash(null);
            setVideoId(result.value);
            setPreviewUrl(null); 
        }
        setShowUploader(false);
    };
    
    const handleEditField = (field: keyof EnrichedData, label: string) => {
        if (!enrichedData) return;

        const currentValue = enrichedData[field];
        let displayValue: string;
        
        if (Array.isArray(currentValue)) {
            if (field === 'validatedInterests') {
                 displayValue = (currentValue as Interest[]).map(i => i.name).join(', ');
            } else {
                 displayValue = (currentValue as string[]).join('\n');
            }
        } else {
            displayValue = String(currentValue ?? '');
        }
        
        const isTextArea = ['adContent', 'iceBreakerQuestions'].includes(field);
        const newValue = isTextArea
            ? prompt(`Chỉnh sửa ${label} (mỗi câu hỏi một dòng):`, displayValue)
            : prompt(`Chỉnh sửa ${label}:`, displayValue);


        if (newValue !== null) {
            let updatedValue: any = newValue;
            if (field === 'ageMin' || field === 'ageMax' || field === 'latitude' || field === 'longitude') {
                updatedValue = parseFloat(newValue) || 0;
            } else if (field === 'interestKeywords' || field === 'iceBreakerQuestions') {
                updatedValue = newValue.split('\n').map(s => s.trim()).filter(Boolean);
            }
            
            setEnrichedData(prev => prev ? { ...prev, [field]: updatedValue } : null);
        }
    };

    const isBusy = status === 'parsing' || status === 'creating';
    const isInputReady = rawInput.trim() && mediaType;

    const renderInputView = () => (
        <>
            {!mediaType ? (
                <button onClick={() => setShowUploader(true)} className="w-full py-6 px-4 border-2 border-dashed rounded-lg border-gray-300 dark:border-gray-500 text-sm font-medium text-gray-600 dark:text-gray-400 hover:border-blue-500 flex flex-col items-center justify-center">
                    <UploadIcon className="w-8 h-8 mb-2" />
                    Bấm để Upload Ảnh / Video
                </button>
            ) : (
                <div className="p-3 rounded-md bg-gray-100 dark:bg-gray-700 flex justify-between items-center">
                    <div className="flex items-center min-w-0">
                        {previewUrl && <img src={previewUrl} alt="preview" className="w-10 h-10 object-cover rounded-md mr-3" />}
                        <div>
                            <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                                {mediaType === 'image' ? 'Ảnh đã tải lên' : 'Video đã tải lên'}
                            </p>
                            <p className="text-xs font-mono text-gray-500 dark:text-gray-400 truncate">
                                {imageHash || videoId}
                            </p>
                        </div>
                    </div>
                    <button type="button" onClick={() => setMediaType(null)} className="text-sm font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 flex-shrink-0 ml-2">
                        Thay đổi
                    </button>
                </div>
            )}

            <textarea 
                value={rawInput}
                onChange={e => setRawInput(e.target.value)}
                rows={12}
                className="w-full p-2 border rounded-md font-mono text-sm bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                placeholder={`Dán toàn bộ thông tin chiến dịch vào đây...\n\nVí dụ:\nTên chiến dịch: Anh Tuấn\n20-40t\nNữ\n400k\nMẫu chào hỏi: Chào {{full_name}}, em có thể giúp gì cho anh/chị ạ?\nCâu hỏi 1...\nCâu hỏi 2...`}
                disabled={isBusy}
            />
            <button onClick={handleParse} disabled={isBusy || !isInputReady} className="w-full inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400">
                {isBusy ? <Spinner /> : 'Phân tích với AI'}
            </button>
        </>
    );

    const renderConfirmationView = () => {
        if (!enrichedData) return null;
        
        const renderField = (label: string, field: keyof EnrichedData, displayValue: React.ReactNode) => (
            <li className="flex justify-between items-start py-2 border-b dark:border-gray-700">
                <div className="flex-1 min-w-0">
                    <span className="font-semibold">{label}:</span>
                    <div className="text-gray-700 dark:text-gray-300 pl-2 pr-2 break-words whitespace-pre-wrap">{displayValue}</div>
                </div>
                <button onClick={() => handleEditField(field, label)} className="p-1 text-gray-400 hover:text-blue-500 flex-shrink-0">
                    <PencilIcon className="w-4 h-4" />
                </button>
            </li>
        );
        
        return (
             <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg space-y-3">
                <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Vui lòng xác nhận thông tin:</h4>
                <ul className="text-sm space-y-1">
                    {renderField("Tên chiến dịch", "campaignName", enrichedData.campaignName)}
                    {renderField("Ngân sách hàng ngày", "dailyBudget", enrichedData.dailyBudget)}
                    {renderField("Độ tuổi", "ageMin", `${enrichedData.ageMin} - ${enrichedData.ageMax}`)}
                    {renderField("Giới tính", "gender", enrichedData.gender)}
                    {renderField("Vị trí", "latitude", enrichedData.latitude && enrichedData.longitude ? `Lat: ${enrichedData.latitude}, Lon: ${enrichedData.longitude} (+10km)` : 'Mặc định: Việt Nam')}
                    {renderField("Sở thích", "interestKeywords", enrichedData.validatedInterests.length > 0 ? enrichedData.validatedInterests.map(i => i.name).join(', ') : '(Không có)')}
                    {renderField("Tiêu đề", "adHeadline", enrichedData.adHeadline)}
                    {renderField("Nội dung", "adContent", <p className="max-h-24 overflow-y-auto">{enrichedData.adContent}</p>)}
                    {enrichedData.greetingText && renderField("Câu chào", "greetingText", enrichedData.greetingText)}
                    {enrichedData.iceBreakerQuestions && enrichedData.iceBreakerQuestions.length > 0 && renderField("Câu hỏi", "iceBreakerQuestions", 
                        <ul className="list-disc pl-5">
                            {enrichedData.iceBreakerQuestions.map((q, i) => <li key={i}>{q}</li>)}
                        </ul>
                    )}
                </ul>
                <div className="flex items-center space-x-2 pt-2">
                     <button onClick={() => handleCreate()} disabled={isBusy} className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-gray-400">
                        {isBusy ? <Spinner/> : 'Xác nhận & Tạo'}
                    </button>
                    <button onClick={() => setStatus('input')} disabled={isBusy} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500 disabled:opacity-50">
                        Sửa lại
                    </button>
                </div>
            </div>
        );
    };

    const renderCompletedView = () => (
        <div className="text-center">
            <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Hoàn tất!</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300">Chiến dịch media mới đã được tạo thành công ở trạng thái Dừng (Paused).</p>
            <div className="mt-4 text-left space-y-2 text-sm font-mono bg-gray-100 dark:bg-gray-900 p-4 rounded-md">
                <p>Campaign ID: <span className="font-bold text-blue-600 dark:text-blue-400">{createdIds.campaignId}</span></p>
                <p>Ad Set ID:   <span className="font-bold text-blue-600 dark:text-blue-400">{createdIds.adSetId}</span></p>
                <p>Ad ID:       <span className="font-bold text-blue-600 dark:text-blue-400">{createdIds.adId}</span></p>
            </div>
            <button onClick={resetState} className="mt-6 px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
                Tạo chiến dịch nhanh khác
            </button>
        </div>
    );

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                <PhotoIcon className="w-6 h-6 mr-2" />
                Tạo nhanh QC Media mới (AI Phân tích)
            </h3>

            {status === 'input' && renderInputView()}
            {(status === 'parsing' || status === 'creating') && <div className="flex justify-center py-10"><Spinner /></div>}
            {status === 'confirming' && renderConfirmationView()}
            {status === 'completed' && renderCompletedView()}
            
            {apiLogs.length > 0 && (
                <div className="space-y-2 pt-4">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Tiến trình thực thi:</h4>
                    <div className="bg-gray-900 text-white font-mono text-xs rounded-md p-3 max-h-48 overflow-y-auto">
                        {apiLogs.map((log, i) => (
                            <p key={i} className={log.status === 'error' ? 'text-red-400' : 'text-green-400'}>{log.step}: {log.message}</p>
                        ))}
                    </div>
                </div>
            )}

            {status === 'error' && error && (
                <div className="p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-md text-sm">
                    <div className="flex items-center">
                        <ExclamationCircleIcon className="w-5 h-5 mr-2"/>
                        <p className="font-semibold">Đã xảy ra lỗi:</p>
                    </div>
                    <p className="mt-1 ml-7">{error}</p>
                    <button onClick={resetState} className="mt-2 ml-7 text-sm font-medium text-blue-700 dark:text-blue-300 hover:underline">
                        Thử lại
                    </button>
                </div>
            )}
            
            {showUploader && (
                <MediaUploader 
                    uploadContext="ad"
                    adAccountId={selectedAccount.id}
                    adsToken={adsToken}
                    onUploadSuccess={handleMediaUploadSuccess}
                    onClose={() => setShowUploader(false)}
                />
            )}
        </div>
    );
};

export default QuickCreativeCreator;