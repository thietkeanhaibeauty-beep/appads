
import React, { useState } from 'react';
import * as facebookService from '../services/facebookService';
import { CloseIcon } from './Icons';
import Spinner from './Spinner';

interface MediaUploaderProps {
    uploadContext: 'ad' | 'template';
    onUploadSuccess: (
        result: 
            | { type: 'image', value: { hash: string, url: string } } 
            | { type: 'video', value: string }
            | { type: 'greeting_image', value: { attachment_id: string, message: string } }
            | { type: 'greeting_video', value: { attachment_id: string, message: string } }
    ) => void;
    onClose: () => void;
    // For 'ad' context
    adAccountId?: string;
    adsToken?: string;
    // For 'template' context
    pageId?: string;
    pageAccessToken?: string;
    // General
    accept?: string;
}

type UploadMethod = 'file' | 'url';
type UploadStatus = 'idle' | 'uploading' | 'error' | 'fetching';

const MediaUploader: React.FC<MediaUploaderProps> = ({ 
    uploadContext, 
    onUploadSuccess, 
    onClose, 
    adAccountId, 
    adsToken, 
    pageId, 
    pageAccessToken, 
    accept = "image/*,video/*" 
}) => {
    const [uploadMethod, setUploadMethod] = useState<UploadMethod>('file');
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [mediaUrl, setMediaUrl] = useState('');
    const [status, setStatus] = useState<UploadStatus>('idle');
    const [error, setError] = useState<string | null>(null);
    const [templateMessage, setTemplateMessage] = useState('');
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const getFileNameFromUrl = (url: string): string => {
        try {
            const path = new URL(url).pathname;
            const filename = path.substring(path.lastIndexOf('/') + 1);
            return filename || 'media-from-url';
        } catch (e) {
            return 'media-from-url';
        }
    };
    
    const handleUpload = async () => {
        setStatus('uploading');
        setError(null);

        let fileToUpload: File | null = null;
        
        try {
            // Step 1: Get the file, either from local selection or by fetching a URL.
            if (uploadMethod === 'file') {
                if (!selectedFile) throw new Error("Vui lòng chọn một file.");
                fileToUpload = selectedFile;
            } else { // 'url'
                if (!mediaUrl) throw new Error("Vui lòng nhập link media.");
                setStatus('fetching');
                const response = await fetch(mediaUrl);
                if (!response.ok) {
                    throw new Error(`Không thể tải file từ link (status: ${response.status}). Vui lòng kiểm tra link CORS.`);
                }
                const blob = await response.blob();
                const filename = getFileNameFromUrl(mediaUrl);
                fileToUpload = new File([blob], filename, { type: blob.type });
                setStatus('uploading');
            }

            if (!fileToUpload) throw new Error("Không có file để tải lên.");

            // Step 2: Determine file type and call the appropriate service function based on context.
            const fileType = fileToUpload.type.split('/')[0];
            
            if (uploadContext === 'ad') {
                if (!adAccountId || !adsToken) throw new Error("Ad Account ID và Ads Token là bắt buộc cho ad upload.");
                if (fileType === 'image') {
                    const imageResult = await facebookService.uploadAdImage(adAccountId, adsToken, fileToUpload);
                    onUploadSuccess({ type: 'image', value: imageResult });
                } else if (fileType === 'video') {
                    const videoId = await facebookService.uploadAdVideo(adAccountId, adsToken, fileToUpload);
                    onUploadSuccess({ type: 'video', value: videoId });
                } else {
                    throw new Error(`Loại file không được hỗ trợ cho quảng cáo: ${fileToUpload.type}. Vui lòng chọn ảnh hoặc video.`);
                }
            } else { // 'template' context
                if (!pageId || !pageAccessToken) throw new Error("Page ID và Page Access Token là bắt buộc cho template upload.");
                if (fileType === 'image') {
                    const greetingImageResult = await facebookService.uploadGreetingImage(pageId, pageAccessToken, fileToUpload);
                    onUploadSuccess({ type: 'greeting_image', value: { ...greetingImageResult, message: templateMessage } });
                } else if (fileType === 'video') {
                    const greetingVideoResult = await facebookService.uploadGreetingVideo(pageId, pageAccessToken, fileToUpload);
                    onUploadSuccess({ type: 'greeting_video', value: { ...greetingVideoResult, message: templateMessage } });
                } else {
                     throw new Error(`Loại file không được hỗ trợ cho tin nhắn chào: ${fileToUpload.type}. Vui lòng chọn ảnh hoặc video.`);
                }
            }

        } catch (err: any) {
            setError(err.message);
            setStatus('error');
        }
    };
    
    const isUploading = status === 'uploading' || status === 'fetching';
    const uploadButtonDisabled = isUploading 
        || (uploadMethod === 'file' && !selectedFile) 
        || (uploadMethod === 'url' && !mediaUrl)
        || (uploadContext === 'template' && !templateMessage.trim());

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4" role="dialog" aria-modal="true">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg">
                <div className="flex justify-between items-center p-4 border-b dark:border-gray-600">
                    <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
                        {uploadContext === 'ad' ? 'Upload Media cho Bài viết' : 'Upload Media cho Template Messenger'}
                    </h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200" aria-label="Đóng">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                
                <div className="p-6 space-y-4">
                     {uploadContext === 'template' && (
                        <div className="mb-4">
                            <label htmlFor="template-message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Nội dung tin nhắn chào <span className="text-red-500">*</span>
                            </label>
                            <textarea
                                id="template-message"
                                rows={3}
                                value={templateMessage}
                                onChange={(e) => setTemplateMessage(e.target.value)}
                                className="w-full px-3 py-2 text-gray-900 bg-gray-50 border border-gray-300 rounded-md shadow-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                placeholder="Nội dung sẽ hiển thị cùng với ảnh/video trong tin nhắn chào..."
                            />
                        </div>
                    )}

                    <div className="flex rounded-md shadow-sm">
                        <button onClick={() => setUploadMethod('file')} className={`w-1/2 py-2 px-4 text-sm font-medium rounded-l-md border ${uploadMethod === 'file' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-500 hover:bg-gray-50'}`}>
                            Từ máy tính
                        </button>
                        <button onClick={() => setUploadMethod('url')} className={`w-1/2 py-2 px-4 text-sm font-medium rounded-r-md border -ml-px ${uploadMethod === 'url' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-500 hover:bg-gray-50'}`}>
                            Từ link URL
                        </button>
                    </div>

                    {uploadMethod === 'file' ? (
                        <div>
                            <label htmlFor="file-upload" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Chọn file Ảnh hoặc Video</label>
                            <input id="file-upload" type="file" accept={accept} onChange={handleFileChange} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-gray-700 dark:file:text-gray-200 dark:hover:file:bg-gray-600"/>
                            {selectedFile && <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">Đã chọn: {selectedFile.name} ({Math.round(selectedFile.size / 1024)} KB)</p>}
                        </div>
                    ) : (
                        <div>
                            <label htmlFor="media-url" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Link media</label>
                            <input id="media-url" type="url" value={mediaUrl} onChange={(e) => setMediaUrl(e.target.value)} placeholder="https://example.com/image.jpg" className="w-full px-3 py-2 text-gray-900 bg-gray-50 border border-gray-300 rounded-md shadow-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-blue-500 focus:border-blue-500"/>
                        </div>
                    )}
                    
                    {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}

                </div>

                <div className="flex justify-end items-center p-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-600 rounded-b-lg">
                    {isUploading && (
                        <div className="flex items-center mr-4">
                            <Spinner />
                            <span className="text-sm text-gray-600 dark:text-gray-300 ml-2">{status === 'fetching' ? 'Đang tải file từ link...' : 'Đang upload lên Facebook...'}</span>
                        </div>
                    )}
                    <button onClick={handleUpload} disabled={uploadButtonDisabled} className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400">
                        Tải lên
                    </button>
                </div>
            </div>
        </div>
    );
};

export default MediaUploader;