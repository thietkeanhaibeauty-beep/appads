
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AdAccount, CampaignObjective, Gender, Page, PostValidationResult, Interest, Country, MessageTemplate, IceBreaker, GreetingType, IceBreakerType, CampaignDraft, GeoLocationTargeting, AdScheduleItem, CustomAudience } from '../types';
import useLocalStorage from '../hooks/useLocalStorage';
import * as facebookService from '../services/facebookService';
import * as aiPostValidatorService from '../services/aiPostValidatorService';
import * as exchangeRateService from '../services/exchangeRateService';
import Spinner from './Spinner';
import { CheckCircleIcon, ExclamationCircleIcon, ArrowLeftIcon, ArrowRightIcon, BeakerIcon, PlayIcon, InfoCircleIcon, PlusIcon, CloseIcon } from './Icons';
import InterestsSelector from './InterestsSelector';
import LocationSelector from './LocationSelector';
import MediaUploader from './MediaUploader';
import AdScheduler from './AdScheduler';

interface PromotePostFormProps {
  selectedAccount: AdAccount;
  adsToken: string;
  initialData?: CampaignDraft | null;
  aiCommand?: { action: string; payload: any };
  onAiCommandProcessed?: () => void;
}

const objectiveMap: { [key in CampaignObjective]: { label: string; optimizationGoal: string } } = {
  'OUTCOME_TRAFFIC': { label: 'Lưu lượng truy cập', optimizationGoal: 'IMPRESSIONS' },
  'MESSAGES': { label: 'Tin nhắn', optimizationGoal: 'CONVERSATIONS' },
  'OUTCOME_ENGAGEMENT': { label: 'Lượt tương tác', optimizationGoal: 'POST_ENGAGEMENT' },
  'LEAD_GENERATION': { label: 'Khách hàng tiềm năng', optimizationGoal: 'LEAD_GENERATION' },
};

type CtaType = 'MESSAGE_PAGE' | 'LEARN_MORE' | 'SHOP_NOW';
type ThumbnailSource = 'auto' | 'manual';
type BudgetType = 'daily' | 'lifetime';

// Helper to convert the Set of 'day-hour' strings into the API format
const convertScheduleSetToApiFormat = (scheduleSet: Set<string>): AdScheduleItem[] => {
    if (scheduleSet.size === 0) return [];
    
    const apiSchedule: AdScheduleItem[] = [];
    const dayGroups: { [day: number]: number[] } = {};

    // Group hours by day
    scheduleSet.forEach(item => {
        const [dayStr, hourStr] = item.split('-');
        const day = parseInt(dayStr, 10);
        const hour = parseInt(hourStr, 10);
        if (!dayGroups[day]) {
            dayGroups[day] = [];
        }
        dayGroups[day].push(hour);
    });

    // For each day, find contiguous blocks
    for (const day in dayGroups) {
        const hours = dayGroups[day].sort((a, b) => a - b);
        if (hours.length > 0) {
            let startHour = hours[0];
            let endHour = hours[0];

            for (let i = 1; i < hours.length; i++) {
                if (hours[i] === endHour + 1) {
                    endHour = hours[i]; // Extend the block
                } else {
                    // Block ended, push it and start a new one
                    apiSchedule.push({
                        day: parseInt(day, 10),
                        start_minute: startHour * 60,
                        end_minute: (endHour + 1) * 60,
                    });
                    startHour = hours[i];
                    endHour = hours[i];
                }
            }
            // Push the last block
            apiSchedule.push({
                day: parseInt(day, 10),
                start_minute: startHour * 60,
                end_minute: (endHour + 1) * 60,
            });
        }
    }
    return apiSchedule;
};


const PromotePostForm: React.FC<PromotePostFormProps> = ({ selectedAccount, adsToken, initialData, aiCommand, onAiCommandProcessed }) => {
  const [currentStep, setCurrentStep] = useState(1);
  
  // Form State
  const [campaignData, setCampaignData] = useState({ name: '', objective: 'OUTCOME_ENGAGEMENT' as CampaignObjective });
  const [adSetData, setAdSetData] = useState({ 
      name: '', 
      dailyBudget: '50000',
      lifetimeBudget: '1500000',
      ageMin: '22', 
      ageMax: '50', 
      gender: 'all' as Gender, 
      geo_locations: { countries: ['VN'] } as GeoLocationTargeting,
  });
  const [budgetType, setBudgetType] = useState<BudgetType>('daily');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isScheduled, setIsScheduled] = useState(false);
  const [adSchedule, setAdSchedule] = useState<Set<string>>(new Set());
  const [interests, setInterests] = useState<Interest[]>([]);
  const [customAudiences, setCustomAudiences] = useState<CustomAudience[]>([]);
  const [minBudget, setMinBudget] = useState<number>(0);


  // API Result State
  const [campaignId, setCampaignId] = useState<string | null>(null);
  const [adSetId, setAdSetId] = useState<string | null>(null);
  const [creativeId, setCreativeId] = useState<string | null>(null);
  const [adId, setAdId] = useState<string | null>(null);
  
  // Ad Creation State
  const [adData, setAdData] = useState({ name: '', postUrl: '' });
  const [targetPage, setTargetPage] = useState<Page | null>(null);
  const [postValidation, setPostValidation] = useState<PostValidationResult>({ status: 'idle', message: null });
  const [objectStoryId, setObjectStoryId] = useState<string | null>(null);
  
  // New Creative State
  const [creativeSource, setCreativeSource] = useState<'existing' | 'new'>('existing');
  const [newAdType, setNewAdType] = useState<'image' | 'video'>('image');
  const [ctaType, setCtaType] = useState<CtaType>('MESSAGE_PAGE');
  const [newAdContent, setNewAdContent] = useState({
    message: '',
    name: '', // for image ad title/headline
    imageHash: '',
    title: '', // for video ad title
    videoId: '',
    ctaLink: ''
  });
  const [thumbnailSource, setThumbnailSource] = useState<ThumbnailSource>('auto');
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);

  // Message Template State
  const [templates, setTemplates] = useLocalStorage<MessageTemplate[]>('fb_ad_message_templates', []);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [greetingType, setGreetingType] = useState<GreetingType>('text_only');
  const [greetingText, setGreetingText] = useState<string>('Xin chào {{full_name}}, bạn cần tư vấn về dịch vụ nào?');
  const [greetingMediaId, setGreetingMediaId] = useState<string | null>(null);
  const [iceBreakerType, setIceBreakerType] = useState<IceBreakerType>('custom');
  const [iceBreakers, setIceBreakers] = useState<IceBreaker[]>([{ question: 'Tôi muốn được tư vấn', payload: 'WANTS_ADVICE' }, { question: 'Xem bảng giá', payload: 'VIEW_PRICING' }]);
  const [showGreetingMediaUploader, setShowGreetingMediaUploader] = useState(false);
  const [uploaderMediaType, setUploaderMediaType] = useState<'image' | 'video'>('image');
  const greetingTextRef = useRef<HTMLTextAreaElement>(null);
  const [messageTemplateTab, setMessageTemplateTab] = useState<'new' | 'saved'>('new');
  const [creationMode, setCreationMode] = useState<'start_conversation' | 'automated_chat' | 'json'>('start_conversation');
  const [customJson, setCustomJson] = useState<string>('');
  
  // UI State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showUploader, setShowUploader] = useState(false);
  const [showThumbnailUploader, setShowThumbnailUploader] = useState(false);
  const [apiLogs, setApiLogs] = useState<{ timestamp: string; step: string; status: 'success' | 'error'; message: string }[]>([]);
  const aiUploadInProgress = useRef(false);

  const HARDCODED_PAGE_ID = '159211580792822';
  
  const addApiLog = (step: string, status: 'success' | 'error', message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setApiLogs(prev => [{ timestamp, step, status, message }, ...prev]);
  };
    
  const resetUploadedMedia = () => {
      setNewAdContent(prev => ({ ...prev, imageHash: '', videoId: '' }));
      setSuccessMessage(null);
      setCreativeId(null);
      setThumbnailSource('auto');
      setThumbnailUrl(null);
  };

  const resetWizard = useCallback(() => {
    setCurrentStep(1);
    setCampaignId(null);
    setAdSetId(null);
    setCreativeId(null);
    setAdId(null);
    setError(null);
    setSuccessMessage(null);
    setPostValidation({ status: 'idle', message: null });
    setObjectStoryId(null);
    setApiLogs([]);

    // Reset form states
    setCampaignData({ name: '', objective: 'OUTCOME_ENGAGEMENT' });
    setAdSetData({ 
        name: '', 
        dailyBudget: '50000',
        lifetimeBudget: '1500000',
        ageMin: '22', 
        ageMax: '50', 
        gender: 'all', 
        geo_locations: { countries: ['VN'] },
    });
    setBudgetType('daily');
    setStartDate('');
    setEndDate('');
    setIsScheduled(false);
    setAdSchedule(new Set());
    setInterests([]);
    setCustomAudiences([]);
    setAdData({ name: '', postUrl: '' });
    setCreativeSource('existing');
    
    // Reset new creative states
    setNewAdType('image');
    setCtaType('MESSAGE_PAGE');
    setNewAdContent({
        message: '',
        name: '',
        imageHash: '',
        title: '',
        videoId: '',
        ctaLink: ''
    });
    setThumbnailSource('auto');
    setThumbnailUrl(null);
    
    // Reset message template states
    setSelectedTemplate('');
    setGreetingType('text_only');
    setGreetingText('Xin chào {{full_name}}, bạn cần tư vấn về dịch vụ nào?');
    setGreetingMediaId(null);
    setIceBreakerType('custom');
    setIceBreakers([{ question: 'Tôi muốn được tư vấn', payload: 'WANTS_ADVICE' }, { question: 'Xem bảng giá', payload: 'VIEW_PRICING' }]);
    setMessageTemplateTab('new');
    setCreationMode('start_conversation');
    setCustomJson('');
}, []);


  const triggerCreateCampaign = async (name?: string): Promise<{success: boolean; id?: string; name?: string; error?: string}> => {
    const finalName = name || campaignData.name; // Use provided name, fallback to state
    
    if (!finalName) {
        const errorMsg = "Tên chiến dịch không được để trống.";
        setError(errorMsg);
        return { success: false, error: errorMsg };
    }

    setLoading(true); setError(null); setSuccessMessage(null);
    try {
      const newCampaignId = await facebookService.createCampaign(selectedAccount.id, adsToken, finalName, campaignData.objective);
      setCampaignId(newCampaignId);
      setSuccessMessage(`Tạo chiến dịch thành công! ID: ${newCampaignId}`);
      return { success: true, id: newCampaignId, name: finalName };
    } catch (err: any) { 
      setError(err.message); 
      return { success: false, error: err.message };
    } 
    finally { setLoading(false); }
  };

  const triggerCreateAdSet = useCallback(async (): Promise<{success: boolean; id?: string; error?: string}> => {
    if (!adSetData.geo_locations || (Object.keys(adSetData.geo_locations).length === 0) || Object.values(adSetData.geo_locations).every(v => !v || (Array.isArray(v) && v.length === 0))) {
        const errorMsg = "Vui lòng chọn một vị trí.";
        setError(errorMsg);
        return { success: false, error: errorMsg };
    }

    // --- NEW, ROBUST BUDGET VALIDATION ---
    const budgetInput = budgetType === 'daily' ? adSetData.dailyBudget : adSetData.lifetimeBudget;
    const budgetValue = facebookService.parseBudgetInput(budgetInput);

    if (isNaN(budgetValue)) {
        const errorMsg = "Không thể xác thực ngân sách. Vui lòng nhập một số hợp lệ (VD: 50000, 50k, 1tr).";
        setError(errorMsg);
        return { success: false, error: errorMsg };
    }
    
    if (minBudget > 0 && budgetValue < minBudget) {
        const errorMsg = `Ngân sách tối thiểu là ${minBudget.toLocaleString('vi-VN')} ${selectedAccount.currency}.`;
        setError(errorMsg);
        return { success: false, error: errorMsg };
    }
    
    // Time validation for lifetime budget
    if (budgetType === 'lifetime') {
        if (!startDate || !endDate) {
            const errorMsg = "Vui lòng chọn ngày bắt đầu và kết thúc.";
            setError(errorMsg);
            return { success: false, error: errorMsg };
        }
        const startDateObj = new Date(startDate);
        const endDateObj = new Date(endDate);
        const thirtyMinutesFromNow = new Date(Date.now() + 30 * 60 * 1000);

        if (startDateObj < thirtyMinutesFromNow) {
            const errorMsg = `Giờ bắt đầu (${startDateObj.toLocaleString()}) quá gần. Vui lòng chọn một thời điểm trong tương lai (khuyến nghị cách 30 phút) để đảm bảo chiến dịch được tạo.`;
            setError(errorMsg);
            return { success: false, error: errorMsg };
        }

        if (endDateObj <= startDateObj) {
            const errorMsg = "Ngày kết thúc phải sau ngày bắt đầu.";
            setError(errorMsg);
            return { success: false, error: errorMsg };
        }
    }

    setLoading(true); setError(null); setSuccessMessage(null);
    try {
      const targeting: any = {
        age_min: parseInt(adSetData.ageMin, 10),
        age_max: parseInt(adSetData.ageMax, 10),
        geo_locations: adSetData.geo_locations,
        targeting_automation: { advantage_audience: 0 },
      };
      if (adSetData.gender !== 'all') {
        targeting.genders = [adSetData.gender === 'male' ? 1 : 2];
      }
      if (interests.length > 0) {
        targeting.flexible_spec = [{ interests: interests.map(i => ({ id: i.id, name: i.name })) }];
      }
      if (customAudiences.length > 0) {
        targeting.custom_audiences = customAudiences.map(ca => ({ id: ca.id }));
      }
      
        let adSchedulePayload: AdScheduleItem[] | undefined = undefined;
        if (budgetType === 'lifetime' && isScheduled) {
             if (adSchedule.size === 0) {
                 throw new Error("Bạn đã bật lịch trình nhưng chưa chọn khung giờ nào.");
            }
            adSchedulePayload = convertScheduleSetToApiFormat(adSchedule);
        }

        const adSetName = adSetData.name || `${campaignData.name} Ad Set`;
        const adSetConfig: Parameters<typeof facebookService.createAdSet>[2] = {
            campaignId: campaignId!, 
            name: adSetName, 
            currency: selectedAccount.currency!, 
            targeting: targeting, 
            optimizationGoal: 'CONVERSATIONS', 
            billingEvent: 'IMPRESSIONS', 
            promotedObject: { page_id: HARDCODED_PAGE_ID }, 
        };

        if (budgetType === 'daily') {
            adSetConfig.dailyBudget = adSetData.dailyBudget;
        } else {
            adSetConfig.lifetimeBudget = adSetData.lifetimeBudget;
            adSetConfig.startTime = new Date(startDate).toISOString();
            adSetConfig.endTime = new Date(endDate).toISOString();
            adSetConfig.adSchedule = adSchedulePayload;
        }
      
      const newAdSetId = await facebookService.createAdSet(selectedAccount.id, adsToken, adSetConfig);
      setAdSetId(newAdSetId);
      setSuccessMessage(`Tạo nhóm quảng cáo thành công! Tên: ${adSetName}, ID: ${newAdSetId}`);
      return { success: true, id: newAdSetId };
    } catch (err: any) { 
        setError(err.message);
        return { success: false, error: err.message };
    } 
    finally { setLoading(false); }
  }, [adSetData, budgetType, startDate, endDate, interests, customAudiences, selectedAccount, adsToken, campaignId, campaignData.name, isScheduled, adSchedule, minBudget]);

  const triggerValidatePost = useCallback(async (url?: string): Promise<{success: boolean; message: string}> => {
    const input = (url || adData.postUrl).trim();
    if (!input || !targetPage?.access_token) {
        const msg = "Vui lòng nhập link hoặc ID bài viết. Đảm bảo thông tin trang đã được tải.";
        setPostValidation({ status: 'error', message: msg });
        return { success: false, message: msg };
    }

    setLoading(true);
    setPostValidation({ status: 'loading', message: null });
    setObjectStoryId(null);

    try {
        const result = await aiPostValidatorService.validatePostId(input, targetPage.access_token);
        
        if (!result.valid || !result.pageId || !result.postId) {
            throw new Error(result.message || "Không thể xác thực bài viết.");
        }
        
        if (result.pageId !== HARDCODED_PAGE_ID) {
            throw new Error(`Bài viết này thuộc về một trang khác (Page ID: ${result.pageId}), không phải trang đang được cấu hình (Page ID: ${HARDCODED_PAGE_ID}).`);
        }
        
        const constructedObjectStoryId = `${result.pageId}_${result.postId}`;
        setObjectStoryId(constructedObjectStoryId);
        setPostValidation({ status: 'success', message: result.message });
        return { success: true, message: result.message };

    } catch (err: any) {
        setPostValidation({ status: 'error', message: err.message });
        return { success: false, message: err.message };
    } finally {
        setLoading(false);
    }
  }, [adData.postUrl, targetPage, HARDCODED_PAGE_ID]);

  // --- AI CONTROL ---
  useEffect(() => {
    // FIX: Add a type for the event detail to avoid `unknown` type errors.
    const handleAiCommand = async () => {
        if (!aiCommand || !onAiCommandProcessed) return;

        const { action, payload } = aiCommand;

        switch (action) {
            case 'startQuickPromote': {
                resetWizard();

                const defaultCampaignName = `QC Nhanh - ${new Date().toLocaleDateString('vi-VN')} ${new Date().toLocaleTimeString('vi-VN')}`;
                const defaultAdSetName = `${defaultCampaignName} - Ad Set`;

                setCampaignData({ name: defaultCampaignName, objective: 'OUTCOME_ENGAGEMENT' });
                setAdSetData(prev => ({
                    ...prev,
                    name: defaultAdSetName,
                    geo_locations: { countries: ['VN'] },
                }));
                setAdData(prev => ({ ...prev, postUrl: payload.postUrl, name: `${defaultCampaignName} - Ad` }));
                setCreativeSource('existing');
                setInterests([]);
                setCustomAudiences([]);

                try {
                    const newCampaignId = await facebookService.createCampaign(
                        selectedAccount.id, 
                        adsToken, 
                        defaultCampaignName, 
                        'OUTCOME_ENGAGEMENT'
                    );
                    setCampaignId(newCampaignId); 
                    
                    const targeting = {
                        age_min: 22,
                        age_max: 50,
                        geo_locations: { countries: ['VN'] },
                        targeting_automation: { advantage_audience: 0 },
                    };
                    const newAdSetId = await facebookService.createAdSet(
                        selectedAccount.id,
                        adsToken,
                        {
                            campaignId: newCampaignId,
                            name: defaultAdSetName,
                            dailyBudget: '50000',
                            currency: selectedAccount.currency!,
                            targeting: targeting,
                            optimizationGoal: 'CONVERSATIONS',
                            promotedObject: { page_id: HARDCODED_PAGE_ID },
                        }
                    );
                    setAdSetId(newAdSetId);
                    
                    setCurrentStep(3);
                    triggerValidatePost(payload.postUrl);

                } catch (err: any) {
                    setError(`Lỗi tạo nhanh: ${err.message}`);
                    setCurrentStep(1); 
                }
                
                break;
            }
            case 'triggerCreateCampaign': {
                const campaignName = payload?.name;
                if (campaignName) {
                    setCampaignData(prev => ({ ...prev, name: campaignName }));
                }
                setTimeout(async () => {
                    const result = await triggerCreateCampaign(campaignName);
                    window.dispatchEvent(new CustomEvent('campaign-form-result', { detail: { action: 'campaignCreated', result } }));
                    if (result.success) setCurrentStep(2);
                }, 100);
                break;
            }
            case 'updateField': {
                if (payload.field === 'adSetName') setAdSetData(prev => ({ ...prev, name: payload.value }));
                else if (payload.field === 'budgetType') setBudgetType(payload.value);
                else if (payload.field === 'dailyBudget') setAdSetData(prev => ({ ...prev, dailyBudget: payload.value }));
                else if (payload.field === 'lifetimeBudget') setAdSetData(prev => ({ ...prev, lifetimeBudget: payload.value }));
                else if (payload.field === 'ageMin') setAdSetData(prev => ({...prev, ageMin: String(payload.value) }));
                else if (payload.field === 'ageMax') setAdSetData(prev => ({...prev, ageMax: String(payload.value) }));
                else if (payload.field === 'gender') setAdSetData(prev => ({...prev, gender: payload.value }));
                else if (payload.field === 'geo_locations') setAdSetData(prev => ({...prev, geo_locations: payload.value }));
                else if (payload.field === 'interests') setInterests(payload.value);
                else if (payload.field === 'custom_audiences') setCustomAudiences(payload.value);
                else if (payload.field === 'startDate') setStartDate(payload.value);
                else if (payload.field === 'endDate') setEndDate(payload.value);
                else if (payload.field === 'isScheduled') setIsScheduled(payload.value);
                else if (payload.field === 'adSchedule') {
                    setAdSchedule(prev => new Set([...prev, ...payload.value]));
                }
                else if (payload.field === 'postUrl') setAdData(prev => ({ ...prev, postUrl: payload.value }));
                else if (payload.field === 'creativeSource') setCreativeSource(payload.value);
                else if (payload.field === 'newAdType') setNewAdType(payload.value);
                break;
            }
            case 'updateNewAdField': {
                setNewAdContent(prev => ({ ...prev, [payload.field]: payload.value }));
                break;
            }
            case 'openUploader': {
                setShowUploader(true);
                aiUploadInProgress.current = true;
                break;
            }
            case 'triggerCreateAdSet': {
                const result = await triggerCreateAdSet();
                window.dispatchEvent(new CustomEvent('campaign-form-result', { detail: { action: 'adSetCreated', result } }));
                if (result.success) setCurrentStep(3);
                break;
            }
            case 'triggerValidatePost': {
                const result = await triggerValidatePost(payload.url);
                window.dispatchEvent(new CustomEvent('campaign-form-result', { detail: { action: 'postValidated', result } }));
                break;
            }
            case 'triggerCreateDraftCreative': {
                const result = await handleCreateDraftCreative();
                window.dispatchEvent(new CustomEvent('campaign-form-result', { detail: { action: 'creativeCreated', result } }));
                break;
            }
            case 'triggerPublishAd': {
                const result = await triggerPublishAd();
                window.dispatchEvent(new CustomEvent('campaign-form-result', { detail: { action: 'adPublished', result } }));
                break;
            }
        }
        
        onAiCommandProcessed();
    };
    
    handleAiCommand();
    
  }, [aiCommand, onAiCommandProcessed, triggerCreateAdSet, triggerValidatePost, resetWizard, selectedAccount.id, selectedAccount.currency, adsToken]);


  useEffect(() => {
    const handleReset = () => {
        resetWizard();
    };
    window.addEventListener('ai-reset-flow', handleReset);
    return () => {
        window.removeEventListener('ai-reset-flow', handleReset);
    };
  }, [resetWizard]);

  useEffect(() => {
    if (initialData) {
      setCampaignData({
        name: initialData.campaignName,
        objective: initialData.objective,
      });
      setAdSetData(prev => ({
        ...prev,
        name: `${initialData.campaignName} Ad Set`,
        dailyBudget: initialData.dailyBudget,
        ageMin: initialData.ageMin,
        ageMax: initialData.ageMax,
        gender: initialData.gender,
        geo_locations: { countries: [initialData.location.key] },
      }));
      setInterests(initialData.interests);
      setSuccessMessage("Đã tải bản nháp từ AI! Vui lòng xem lại và tạo chiến dịch.");
    }
  }, [initialData]);

  // Fetch page details on mount for Step 3
  useEffect(() => {
    const fetchPageDetails = async () => {
      try {
        const managedPages = await facebookService.getManagedPages(adsToken);
        const foundPage = managedPages.find(p => p.id === HARDCODED_PAGE_ID);
        if (foundPage) {
          setTargetPage(foundPage);
        } else {
          // This error will be shown in Step 3 if needed
          console.error(`Không tìm thấy hoặc không có quyền truy cập trang với ID: ${HARDCODED_PAGE_ID}`);
        }
      } catch (err: any) {
        console.error(err.message);
      }
    };
    fetchPageDetails();
  }, [adsToken]);

  useEffect(() => {
    const fetchMinBudget = async () => {
        if (selectedAccount.currency) {
            try {
                const min = await exchangeRateService.getMinBudget(selectedAccount.currency);
                setMinBudget(min);
            } catch (err) {
                console.error("Could not fetch min budget", err);
                setMinBudget(selectedAccount.currency === 'VND' ? 25000 : 1);
            }
        }
    };
    fetchMinBudget();
  }, [selectedAccount.currency]);

    useEffect(() => {
        if (budgetType === 'lifetime') {
            const now = new Date();
            // Default start time is 30 minutes in the future to prevent race conditions
            const startTime = new Date(now.getTime() + 30 * 60 * 1000);
            const endTime = new Date(startTime);
            endTime.setMonth(endTime.getMonth() + 1);
            
            const toLocalISOString = (date: Date) => {
                const tzoffset = (new Date()).getTimezoneOffset() * 60000;
                const localISOTime = (new Date(date.getTime() - tzoffset)).toISOString().slice(0, 16);
                return localISOTime;
            }
            
            if (!startDate) setStartDate(toLocalISOString(startTime));
            if (!endDate) setEndDate(toLocalISOString(endTime));
        }
  }, [budgetType, startDate, endDate]);

    
    const buildStartConversationPayload = (): any | null => {
        // This function now only handles TEXT_ONLY greetings
        if (greetingType !== 'text_only' || (!greetingText.trim() && (iceBreakerType !== 'custom' || !iceBreakers.some(ib => ib.question.trim())))) {
            return null;
        }

        return {
            type: "VISUAL_EDITOR",
            version: 2,
            landing_screen_type: "welcome_message",
            media_type: 'text',
            text_format: {
                customer_action_type: "ice_breakers",
                message: {
                    ice_breakers: (iceBreakerType === 'custom')
                        ? iceBreakers
                            .filter(ib => ib.question.trim())
                            .map(ib => ({
                                title: ib.question.trim(),
                                response: ib.payload?.trim() || ib.question.trim()
                            }))
                        : [],
                    quick_replies: [],
                    text: greetingText.trim()
                }
            },
            user_edit: false,
            surface: "visual_editor_new"
        };
    };

    const getMessageTemplatePayload = (): any | null => {
        if (ctaType !== 'MESSAGE_PAGE') {
            return null;
        }

        if (creationMode === 'json') {
            if (!customJson.trim()) return null;
            try {
                const parsedJson = JSON.parse(customJson);
                return { page_welcome_message: parsedJson };
            } catch (e) {
                const jsonError = new Error("JSON ở Thiết lập nâng cao không hợp lệ. Vui lòng kiểm tra lại cú pháp.");
                setError(jsonError.message);
                throw jsonError;
            }
        }
        
        if (creationMode === 'start_conversation') {
            const isMediaGreeting = (greetingType === 'text_image' || greetingType === 'text_video');
            const hasMedia = isMediaGreeting && greetingMediaId;
            const hasText = greetingText.trim() !== '';
            const hasIceBreakers = iceBreakerType === 'custom' && iceBreakers.some(ib => ib.question.trim());

            if (!hasMedia && !hasText && !hasIceBreakers) return null;

            if (hasMedia) {
                const mediaType = greetingType === 'text_image' ? 'image' : 'video';
                
                const payload = {
                    greeting_text: greetingText.trim(),
                    media: {
                        type: mediaType,
                        attachment_id: greetingMediaId,
                    },
                    ctas: hasIceBreakers 
                        ? iceBreakers
                            .filter(ib => ib.question.trim())
                            .map(ib => ({
                                type: 'QUICK_REPLY',
                                title: ib.question.trim(),
                                payload: ib.payload?.trim() || ib.question.trim()
                            }))
                        : []
                };
                return { page_welcome_message: payload };
            } else {
                // For text_only, use the VISUAL_EDITOR payload.
                const payload = buildStartConversationPayload();
                return payload ? { page_welcome_message: payload } : null;
            }
        }

        return null;
    };
  
    const handleCreateDraftCreative = async (): Promise<{success: boolean; id?: string; error?: string}> => {
        if (!targetPage) {
            const errorMsg = "Thông tin trang chưa được tải.";
            setError(errorMsg);
            return { success: false, error: errorMsg };
        }
        setLoading(true);
        setError(null);
        try {
            if (ctaType === 'MESSAGE_PAGE' && creationMode === 'start_conversation') {
                if (greetingType === 'text_image' && !greetingMediaId) {
                    throw new Error("Bạn đã chọn lời chào có ảnh, vui lòng upload ảnh cho tin nhắn chào.");
                }
                if (greetingType === 'text_video' && !greetingMediaId) {
                    throw new Error("Bạn đã chọn lời chào có video, vui lòng upload video cho tin nhắn chào.");
                }
            }

            let newCreativeId: string;
            
            const messageTemplateData = getMessageTemplatePayload();

            if (newAdType === 'image') {
                if (!newAdContent.message || !newAdContent.name || !newAdContent.imageHash) {
                    throw new Error("Vui lòng điền đủ: Nội dung, Tiêu đề, và upload ảnh.");
                }
                const creativeConfig = {
                    pageId: HARDCODED_PAGE_ID,
                    ...newAdContent,
                    ctaType: ctaType,
                    messageTemplateData, // Pass the payload
                };
                newCreativeId = await facebookService.createAdCreativeForImage(
                    selectedAccount.id,
                    targetPage.access_token,
                    creativeConfig
                );
            } else { // video
                if (!newAdContent.message || !newAdContent.title || !newAdContent.videoId) {
                    throw new Error("Vui lòng điền đủ: Nội dung, Tiêu đề video, và upload video.");
                }
                
                let finalThumbnailUrl = thumbnailUrl;
                if (thumbnailSource === 'auto') {
                    addApiLog('Thumbnail', 'success', 'Đang lấy thumbnail tự động...');
                    finalThumbnailUrl = await facebookService.getVideoThumbnails(newAdContent.videoId, targetPage.access_token);
                    addApiLog('Thumbnail', 'success', `Sử dụng thumbnail tự động: ${finalThumbnailUrl.substring(0, 40)}...`);
                } else {
                    addApiLog('Thumbnail', 'success', `Sử dụng thumbnail thủ công: ${finalThumbnailUrl?.substring(0, 40)}...`);
                }
                
                if (!finalThumbnailUrl) {
                    throw new Error("Bắt buộc phải có thumbnail cho quảng cáo video. Vui lòng chọn lại.");
                }

                const creativeConfig = {
                    pageId: HARDCODED_PAGE_ID,
                    ...newAdContent,
                    ctaType: ctaType,
                    thumbnailUrl: finalThumbnailUrl,
                    messageTemplateData, // Pass the payload
                };
                newCreativeId = await facebookService.createAdCreativeForVideo(
                    selectedAccount.id,
                    targetPage.access_token,
                    creativeConfig
                );
            }
            setCreativeId(newCreativeId);
            addApiLog('Tạo Creative', 'success', `Tạo thành công Creative ID: ${newCreativeId}`);
            return { success: true, id: newCreativeId };
        } catch (err: any) {
            setError(err.message);
            addApiLog('Tạo Creative', 'error', err.message);
            return { success: false, error: err.message };
        } finally {
            setLoading(false);
        }
    };
    
    const triggerPublishAd = async (): Promise<{success: boolean; id?: string; error?: string}> => {
        setLoading(true);
        setError(null);
        try {
            let finalCreativeId = creativeId;

            if (creativeSource === 'existing') {
                if (!objectStoryId || !targetPage) {
                    throw new Error("Vui lòng xác thực bài viết có sẵn trước.");
                }
                const existingCreativeId = await facebookService.createAdCreativeFromPost(
                    selectedAccount.id,
                    objectStoryId,
                    targetPage.access_token
                );
                 addApiLog('Tạo Creative (Post)', 'success', `Tạo thành công Creative ID: ${existingCreativeId}`);
                 finalCreativeId = existingCreativeId;
            } 
            
            if (!finalCreativeId || !adSetId || !targetPage) {
                throw new Error("Thiếu Ad Set ID hoặc Creative ID. Vui lòng hoàn tất các bước trước.");
            }
            
            const newAdId = await facebookService.createAd(selectedAccount.id, targetPage.access_token, {
                adSetId: adSetId!,
                name: adData.name || `${adSetData.name || campaignData.name} - Ad`,
                creativeId: finalCreativeId,
            });

            setAdId(newAdId);
            addApiLog('Đăng Quảng Cáo', 'success', `Tạo thành công Ad ID: ${newAdId}`);
            setCurrentStep(4);
            return { success: true, id: newAdId };

        } catch (err: any) {
            setError(err.message);
            addApiLog('Đăng Quảng Cáo', 'error', err.message);
            return { success: false, error: err.message };
        } finally {
            setLoading(false);
        }
    };

  const handleMediaUploadSuccess = async (result: { type: 'image', value: {hash: string, url: string} } | { type: 'video', value: string }) => {
    let mediaType: 'image' | 'video';
    let previewUrl: string;

    if (result.type === 'image') {
        setNewAdContent(prev => ({ ...prev, imageHash: result.value.hash, videoId: '' }));
        setNewAdType('image');
        mediaType = 'image';
        previewUrl = result.value.url;
    } else { // video
        setNewAdContent(prev => ({ ...prev, videoId: result.value, imageHash: '' }));
        setNewAdType('video');
        mediaType = 'video';
        // Need to fetch thumbnail for preview
        if (targetPage?.access_token) {
            try {
                previewUrl = await facebookService.getVideoThumbnails(result.value, targetPage.access_token);
            } catch (thumbError: any) {
                previewUrl = ''; // fallback
                addApiLog('Thumbnail', 'error', thumbError.message);
            }
        } else {
            previewUrl = '';
        }
    }
    setShowUploader(false);
    setSuccessMessage(`Tải lên ${result.type} thành công!`);
    addApiLog('Upload Media', 'success', `${result.type === 'image' ? 'Image Hash' : 'Video ID'}: ${result.type === 'image' ? result.value.hash : result.value}`);

    if (aiUploadInProgress.current) {
        window.dispatchEvent(new CustomEvent('media-upload-complete', {
            detail: {
                mediaType,
                previewUrl,
            }
        }));
        aiUploadInProgress.current = false;
    }
  };

  const handleThumbnailUploadSuccess = (result: { type: 'image', value: { hash: string, url: string } }) => {
    setThumbnailUrl(result.value.url);
    setShowThumbnailUploader(false);
    addApiLog('Upload Thumbnail', 'success', `Tải lên thành công: ${result.value.url.substring(0, 40)}...`);
  };
  
    // --- Message Template Handlers ---
    const handleGreetingTypeChange = (type: GreetingType) => {
        setGreetingType(type);
        setGreetingMediaId(null);
    };

    const handleGreetingMediaUploadSuccess = (result: 
        | { type: 'greeting_image', value: { attachment_id: string, message: string } }
        | { type: 'greeting_video', value: { attachment_id: string, message: string } }
        | { type: 'image', value: any } // To satisfy typescript for non-greeting types
        | { type: 'video', value: any }
    ) => {
        if (result.type === 'greeting_image' || result.type === 'greeting_video') {
            setGreetingText(result.value.message);
            setGreetingMediaId(result.value.attachment_id);
            addApiLog('Greeting Media', 'success', `Tải media chào mừng thành công, ID: ${result.value.attachment_id}`);
        }
        setShowGreetingMediaUploader(false);
    };

    const handleAddIceBreaker = () => {
        if (iceBreakers.length < 4) {
            setIceBreakers([...iceBreakers, { question: '', payload: '' }]);
        }
    };

    const handleRemoveIceBreaker = (index: number) => {
        setIceBreakers(iceBreakers.filter((_, i) => i !== index));
    };

    const handleUpdateIceBreaker = (index: number, field: 'question' | 'payload', value: string) => {
        const newIceBreakers = [...iceBreakers];
        newIceBreakers[index] = { ...newIceBreakers[index], [field]: value };
        setIceBreakers(newIceBreakers);
    };
    
    const handleSaveTemplate = () => {
        const name = prompt("Nhập tên cho mẫu tin nhắn này:");
        if (name && name.trim()) {
            const newTemplate: MessageTemplate = {
                name: name.trim(),
                greetingType,
                greetingText,
                greetingMediaId,
                iceBreakers: iceBreakers.filter(ib => ib.question.trim()),
            };
            setTemplates(prev => [...prev.filter(t => t.name !== name.trim()), newTemplate]);
            setSuccessMessage(`Đã lưu mẫu "${name.trim()}"!`);
            setSelectedTemplate(name.trim());
        }
    };

    const handleUpdateTemplate = () => {
        if (!selectedTemplate) return;
        const updatedTemplate: MessageTemplate = {
            name: selectedTemplate,
            greetingType,
            greetingText,
            greetingMediaId,
            iceBreakers: iceBreakers.filter(ib => ib.question.trim()),
        };
        setTemplates(prev => prev.map(t => t.name === selectedTemplate ? updatedTemplate : t));
        setSuccessMessage(`Đã cập nhật mẫu "${selectedTemplate}"!`);
    };

    const handleDeleteTemplate = () => {
        if (!selectedTemplate || !window.confirm(`Bạn có chắc muốn xóa mẫu "${selectedTemplate}"?`)) return;
        setTemplates(prev => prev.filter(t => t.name !== selectedTemplate));
        setSelectedTemplate(''); // Reset selection
        setSuccessMessage(`Đã xóa mẫu "${selectedTemplate}"!`);
    };
    
    const handleLoadTemplate = (templateName: string) => {
        const template = templates.find(t => t.name === templateName);
        if (template) {
            setSelectedTemplate(templateName);
            setGreetingType(template.greetingType);
            setGreetingText(template.greetingText);
            setGreetingMediaId(template.greetingMediaId);
            const loadedIceBreakers = template.iceBreakers.length > 0 ? template.iceBreakers : [{ question: '', payload: '' }];
            setIceBreakers(loadedIceBreakers);
            setIceBreakerType(template.iceBreakers.length > 0 ? 'custom' : 'none');
            
            // Switch to the editor tab to show the loaded template
            setMessageTemplateTab('new');
            setCreationMode('start_conversation');
            setSuccessMessage(`Đã tải mẫu "${templateName}"!`);
        }
    };

    const handleInsertName = (name: '{{first_name}}' | '{{last_name}}' | '{{full_name}}') => {
        if (greetingTextRef.current) {
            const { selectionStart, selectionEnd, value } = greetingTextRef.current;
            const newText = value.substring(0, selectionStart) + name + value.substring(selectionEnd);
            setGreetingText(newText);
            setTimeout(() => {
                greetingTextRef.current?.focus();
                const newCursorPos = selectionStart + name.length;
                greetingTextRef.current!.selectionStart = newCursorPos;
                greetingTextRef.current!.selectionEnd = newCursorPos;
            }, 0);
        }
    };

    const handleTestMessageTemplate = async () => {
        if (!targetPage) {
            addApiLog('Test Template', 'error', 'Chưa tải được thông tin Page.');
            return;
        }

        // Add validation to ensure media is provided when the greeting type requires it.
        if (creationMode === 'start_conversation') {
            if (greetingType === 'text_image' && !greetingMediaId) {
                const msg = "Bạn phải upload media cho tin nhắn chào trước khi tạo quảng cáo.";
                setError(msg);
                addApiLog('Test Template', 'error', msg);
                return;
            }
            if (greetingType === 'text_video' && !greetingMediaId) {
                const msg = "Bạn phải upload media cho tin nhắn chào trước khi tạo quảng cáo.";
                setError(msg);
                addApiLog('Test Template', 'error', msg);
                return;
            }
        }
        
        let payload;
        try {
            payload = getMessageTemplatePayload();
        } catch (err: any) {
            // Error is already set by getMessageTemplatePayload, just log it.
            addApiLog('Test Template', 'error', `Lỗi: ${err.message}`);
            return;
        }

        if (!payload) {
            addApiLog('Test Template', 'error', 'Không có nội dung template để test. Vui lòng nhập lời chào, câu hỏi hoặc JSON.');
            return;
        }

        addApiLog('Test Template', 'success', 'Bắt đầu kiểm tra payload...');
        setLoading(true);
        setError(null);

        try {
            await facebookService.validateMessageTemplate(
                selectedAccount.id,
                targetPage.access_token,
                HARDCODED_PAGE_ID,
                payload
            );
            addApiLog('Test Template', 'success', 'Payload hợp lệ! Cấu hình tin nhắn của bạn có thể sử dụng được.');
            setSuccessMessage('Test thành công! Payload hợp lệ.');
        } catch (err: any) {
            addApiLog('Test Template', 'error', `Lỗi: ${err.message}`);
            setError(err.message); // Also show in main error display
        } finally {
            setLoading(false);
        }
    };

  
  const isTemplateSaveable = greetingText.trim() !== '' || iceBreakers.some(ib => ib.question.trim() !== '');
  
  const renderMessageTemplatePreview = () => (
    <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-900 rounded-lg flex justify-center">
        <div className="w-full max-w-xs bg-white dark:bg-gray-800 rounded-2xl shadow-md p-3 space-y-2">
            <div className="flex items-end gap-2">
                <div className="flex-shrink-0 w-8 h-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center font-bold text-white text-sm">
                    P
                </div>
                <div className="max-w-xs px-3 py-2 rounded-2xl bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 rounded-bl-none">
                    {greetingMediaId && (greetingType === 'text_image' || greetingType === 'text_video') && (
                        <div className="rounded-lg mb-2 bg-black flex items-center justify-center h-28">
                            {greetingType === 'text_image' ? 
                                <span className="text-white text-xs">Image Preview</span> : 
                                <PlayIcon className="w-8 h-8 text-white" />
                            }
                        </div>
                    )}
                    {greetingText ? (
                        <p className="text-sm whitespace-pre-wrap break-words">{greetingText.replace(/{{(.*?)}}/g, '[Tên]')}</p>
                    ) : (
                         (greetingType === 'text_image' || greetingType === 'text_video') ? null :
                        <p className="text-sm italic text-gray-400">Chưa có lời chào...</p>
                    )}
                </div>
            </div>
            {iceBreakerType === 'custom' && iceBreakers.some(ib => ib.question.trim()) && (
                <div className="flex flex-col items-end gap-1 pt-2">
                    {iceBreakers.filter(ib => ib.question.trim()).map((ib, index) => (
                        <div key={index} className="px-3 py-1.5 border border-blue-500 text-blue-500 dark:border-blue-400 dark:text-blue-400 rounded-full text-sm cursor-pointer max-w-full truncate">
                            {ib.question}
                        </div>
                    ))}
                </div>
            )}
        </div>
    </div>
);

  const renderStartConversationEditor = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
        {/* Left side: Configuration */}
        <div className="space-y-4">
            {/* Template Management */}
             <div className="space-y-2">
                 <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Quản lý Mẫu</label>
                <select onChange={(e) => handleLoadTemplate(e.target.value)} value={selectedTemplate} className="text-xs block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600">
                    <option value="" disabled>Chọn mẫu đã lưu để sửa...</option>
                    {templates.map(t => <option key={t.name} value={t.name}>{t.name}</option>)}
                </select>
                 <div className="flex items-center space-x-2">
                    <button onClick={handleSaveTemplate} disabled={!isTemplateSaveable} className="flex-1 text-xs px-2 py-1.5 font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400">Lưu mới</button>
                    <button onClick={handleUpdateTemplate} disabled={!selectedTemplate || !isTemplateSaveable} className="flex-1 text-xs px-2 py-1.5 font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-gray-400">Cập nhật</button>
                    <button onClick={handleDeleteTemplate} disabled={!selectedTemplate} className="flex-1 text-xs px-2 py-1.5 font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-red-700 disabled:bg-gray-400">Xóa</button>
                </div>
            </div>

            {/* Greeting */}
            <div className="space-y-2 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-md">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Lời chào</label>
                <select value={greetingType} onChange={(e) => handleGreetingTypeChange(e.target.value as GreetingType)} className="text-xs block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600">
                    <option value="text_only">Chỉ văn bản</option>
                    <option value="text_image">Văn bản & Hình ảnh</option>
                    <option value="text_video">Văn bản & Video</option>
                </select>
                <textarea ref={greetingTextRef} value={greetingText} onChange={e => setGreetingText(e.target.value)} rows={3} className="text-xs block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="Xin chào {{first_name}}..." />
                 <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-500 dark:text-gray-400">Chèn:</span>
                    <button type="button" onClick={() => handleInsertName('{{first_name}}')} className="text-xs px-1.5 py-0.5 bg-gray-200 dark:bg-gray-600 rounded">Tên</button>
                    <button type="button" onClick={() => handleInsertName('{{last_name}}')} className="text-xs px-1.5 py-0.5 bg-gray-200 dark:bg-gray-600 rounded">Họ</button>
                    <button type="button" onClick={() => handleInsertName('{{full_name}}')} className="text-xs px-1.5 py-0.5 bg-gray-200 dark:bg-gray-600 rounded">Họ & Tên</button>
                </div>

                {greetingType === 'text_image' && (
                    !greetingMediaId ? (
                        <button onClick={() => { setUploaderMediaType('image'); setShowGreetingMediaUploader(true); }} className="w-full text-xs py-1.5 px-3 bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500 rounded-md">Upload Ảnh cho Template</button>
                    ) : (
                        <div className="text-xs flex items-center justify-between"><span className="truncate">Image Attachment ID: {greetingMediaId}</span><button type="button" onClick={() => setGreetingMediaId(null)} className="ml-2 text-blue-500">Xóa</button></div>
                    )
                )}
                {greetingType === 'text_video' && (
                    !greetingMediaId ? (
                        <button onClick={() => { setUploaderMediaType('video'); setShowGreetingMediaUploader(true); }} className="w-full text-xs py-1.5 px-3 bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500 rounded-md">Upload Video cho Template</button>
                    ) : (
                        <div className="text-xs flex items-center justify-between"><span className="truncate">Video Attachment ID: {greetingMediaId}</span><button type="button" onClick={() => setGreetingMediaId(null)} className="ml-2 text-blue-500">Xóa</button></div>
                    )
                )}
            </div>

            {/* Ice Breakers */}
            <div className="space-y-2 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-md">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Câu hỏi thường gặp</label>
                <select value={iceBreakerType} onChange={e => setIceBreakerType(e.target.value as IceBreakerType)} className="text-xs block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600">
                    <option value="custom">Tùy chỉnh cho quảng cáo này</option>
                    <option value="business_suite" disabled>Nhập từ Business Suite (sắp có)</option>
                    <option value="none">Không dùng</option>
                </select>
                {iceBreakerType === 'custom' && (
                    <div className="space-y-3">
                        {iceBreakers.map((ib, index) => (
                            <div key={index} className="flex items-start space-x-2">
                                <div className="flex-grow space-y-1">
                                    <input type="text" maxLength={80} value={ib.question} onChange={e => handleUpdateIceBreaker(index, 'question', e.target.value)} className="flex-grow text-xs block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder={`Câu hỏi ${index + 1}`} />
                                    <input type="text" maxLength={1000} value={ib.payload || ''} onChange={e => handleUpdateIceBreaker(index, 'payload', e.target.value)} className="flex-grow text-xs block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="Payload (VD: USER_WANTS_ADVICE)" />
                                </div>
                                <button type="button" onClick={() => handleRemoveIceBreaker(index)} className="p-1 text-gray-400 hover:text-red-500 mt-1"><CloseIcon className="w-4 h-4" /></button>
                            </div>
                        ))}
                        {iceBreakers.length < 4 && (
                            <button type="button" onClick={handleAddIceBreaker} className="flex items-center text-xs text-blue-600 dark:text-blue-400 hover:underline pt-1">
                                <PlusIcon className="w-4 h-4 mr-1"/> Thêm câu hỏi
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
        {/* Right side: Preview */}
        <div>
            <h4 className="text-base font-semibold text-gray-800 dark:text-gray-200">Xem trước</h4>
            {renderMessageTemplatePreview()}
        </div>
    </div>
  );

  const renderMessageTemplateSection = () => {
      const isTestable = (creationMode === 'start_conversation' && isTemplateSaveable) || (creationMode === 'json' && customJson.trim() !== '');
      return (
            <div className="mt-6 p-4 border border-gray-200 dark:border-gray-600 rounded-lg space-y-4 text-sm">
              <h4 className="text-base font-semibold text-gray-800 dark:text-gray-200">Mẫu tin nhắn</h4>
              
              {/* Tabs */}
              <div className="flex border-b border-gray-200 dark:border-gray-600">
                  <button 
                      onClick={() => setMessageTemplateTab('new')}
                      className={`px-4 py-2 text-sm font-medium -mb-px border-b-2 ${messageTemplateTab === 'new' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                  >
                      Tạo mới
                  </button>
                  <button 
                      onClick={() => setMessageTemplateTab('saved')}
                      className={`px-4 py-2 text-sm font-medium -mb-px border-b-2 ${messageTemplateTab === 'saved' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                  >
                      Sử dụng mẫu có sẵn
                  </button>
              </div>

              {/* Tab Content */}
              <div className="pt-4">
                {messageTemplateTab === 'new' && (
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Chọn một loại mẫu để bắt đầu.</p>
                    <div className="space-y-3">
                        <label className={`flex items-center p-3 border rounded-lg cursor-pointer ${creationMode === 'start_conversation' ? 'bg-blue-50 border-blue-300 dark:bg-blue-900/50 dark:border-blue-700' : 'dark:border-gray-600'}`}>
                            <input type="radio" name="creation-mode" value="start_conversation" checked={creationMode === 'start_conversation'} onChange={(e) => setCreationMode(e.target.value as any)} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"/>
                            <span className="ml-3 text-sm font-medium text-gray-800 dark:text-gray-200">Bắt đầu cuộc trò chuyện</span>
                        </label>
                         <label className={`flex items-center p-3 border rounded-lg cursor-not-allowed bg-gray-100 dark:bg-gray-700/50 dark:border-gray-600 opacity-60`}>
                            <input type="radio" name="creation-mode" value="automated_chat" checked={creationMode === 'automated_chat'} onChange={(e) => setCreationMode(e.target.value as any)} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" disabled/>
                            <span className="ml-3 text-sm font-medium text-gray-800 dark:text-gray-200">Chat tự động (Sắp có)</span>
                        </label>
                         <label className={`flex items-center p-3 border rounded-lg cursor-pointer ${creationMode === 'json' ? 'bg-blue-50 border-blue-300 dark:bg-blue-900/50 dark:border-blue-700' : 'dark:border-gray-600'}`}>
                            <input type="radio" name="creation-mode" value="json" checked={creationMode === 'json'} onChange={(e) => setCreationMode(e.target.value as any)} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"/>
                            <span className="ml-3 text-sm font-medium text-gray-800 dark:text-gray-200">Thiết lập nâng cao (JSON)</span>
                        </label>
                    </div>

                    {creationMode === 'start_conversation' && (
                        <div className="pt-4 border-t dark:border-gray-600">
                            {renderStartConversationEditor()}
                        </div>
                    )}
                    {creationMode === 'json' && (
                        <div className="pt-4 border-t dark:border-gray-600 space-y-2">
                            <label htmlFor="customJson" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Page Welcome Message JSON
                            </label>
                            <textarea
                                id="customJson"
                                value={customJson}
                                onChange={e => setCustomJson(e.target.value)}
                                rows={8}
                                className="font-mono text-xs block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-900 dark:border-gray-600 dark:text-gray-200"
                                placeholder={`{\n  "message": {\n    "text": "Hello {{user_full_name}}!"\n  }\n}`}
                            />
                             <p className="text-xs text-gray-500 dark:text-gray-400">Dán nội dung JSON cho `page_welcome_message` vào đây.</p>
                        </div>
                    )}
                  </div>
                )}

                {messageTemplateTab === 'saved' && (
                  <div className="space-y-3">
                    <label htmlFor="saved-template-selector" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Chọn một mẫu đã lưu để áp dụng</label>
                    <select 
                      id="saved-template-selector"
                      onChange={(e) => handleLoadTemplate(e.target.value)} 
                      value="" // Reset after selection
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
                    >
                        <option value="" disabled>-- Chọn mẫu --</option>
                        {templates.map(t => <option key={t.name} value={t.name}>{t.name}</option>)}
                    </select>
                    {templates.length === 0 && <p className="text-xs text-gray-500 italic">Bạn chưa có mẫu nào được lưu.</p>}
                  </div>
                )}
              </div>
              
              <div className="mt-4 pt-4 border-t dark:border-gray-600">
                <button 
                    onClick={handleTestMessageTemplate} 
                    disabled={loading || !isTestable}
                    className="w-full flex justify-center items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:bg-gray-400"
                >
                    <BeakerIcon className="w-4 h-4 mr-2"/>
                    Test Message Template
                </button>
            </div>
            </div>
      );
  };


  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
             <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Bước 1: Tạo Chiến dịch</h3>
            <div>
              <label htmlFor="campaignName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tên chiến dịch</label>
              <input type="text" id="campaignName" value={campaignData.name} onChange={e => setCampaignData({...campaignData, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600" placeholder="VD: Khuyến mãi tháng 7" />
            </div>
            <div>
              <label htmlFor="objective" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Mục tiêu</label>
              <select id="objective" value={campaignData.objective} disabled className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 bg-gray-100 dark:bg-gray-700/50 cursor-not-allowed">
                <option value="OUTCOME_ENGAGEMENT">{objectiveMap['OUTCOME_ENGAGEMENT'].label}</option>
              </select>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Bước 2: Tạo Nhóm quảng cáo (Ad Set)</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Campaign ID</label>
                    <p className="mt-1 p-2 bg-gray-100 dark:bg-gray-700 rounded-md text-sm font-mono">{campaignId}</p>
                 </div>
                 <div>
                    <label htmlFor="adSetName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tên nhóm quảng cáo</label>
                    <input type="text" id="adSetName" value={adSetData.name} onChange={e => setAdSetData({...adSetData, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder={`VD: ${campaignData.name} - Target 1`} />
                </div>
             </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Loại ngân sách</label>
                <div className="flex space-x-4">
                    <label className="flex items-center">
                        <input type="radio" name="budgetType" value="daily" checked={budgetType === 'daily'} onChange={() => setBudgetType('daily')} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"/>
                        <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Hàng ngày</span>
                    </label>
                    <label className="flex items-center">
                        <input type="radio" name="budgetType" value="lifetime" checked={budgetType === 'lifetime'} onChange={() => setBudgetType('lifetime')} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"/>
                        <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Trọn đời</span>
                    </label>
                </div>
            </div>

            {budgetType === 'daily' ? (
                <div>
                    <label htmlFor="dailyBudget" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ngân sách hàng ngày ({selectedAccount.currency})</label>
                    <input type="text" id="dailyBudget" value={adSetData.dailyBudget} onChange={e => setAdSetData({...adSetData, dailyBudget: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder={`Tối thiểu ~${minBudget > 0 ? minBudget.toLocaleString('vi-VN') : '1 USD'}`} />
                </div>
            ) : (
                <div className="p-4 border rounded-md dark:border-gray-600 space-y-4">
                     <div>
                        <label htmlFor="lifetimeBudget" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ngân sách trọn đời ({selectedAccount.currency})</label>
                        <input type="text" id="lifetimeBudget" value={adSetData.lifetimeBudget} onChange={e => setAdSetData({...adSetData, lifetimeBudget: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ngày bắt đầu</label>
                            <input type="datetime-local" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" />
                        </div>
                        <div>
                            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Ngày kết thúc</label>
                            <input type="datetime-local" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" />
                        </div>
                    </div>
                     <div className="relative flex items-start pt-2">
                        <div className="flex items-center h-5">
                            <input id="isScheduled" type="checkbox" checked={isScheduled} onChange={e => setIsScheduled(e.target.checked)} className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"/>
                        </div>
                        <div className="ml-3 text-sm">
                            <label htmlFor="isScheduled" className="font-medium text-gray-700 dark:text-gray-300">Chạy quảng cáo theo lịch trình</label>
                        </div>
                    </div>
                    {isScheduled && (
                        <div className="mt-2 space-y-2">
                            <div className="p-3 bg-blue-50 dark:bg-gray-900/50 rounded-md border border-blue-200 dark:border-gray-700">
                               <p className="text-sm font-medium text-gray-800 dark:text-gray-200">Sử dụng múi giờ của tài khoản quảng cáo ({selectedAccount.timezone_name || 'N/A'})</p>
                               <p className="text-xs text-gray-500 dark:text-gray-400">Chúng tôi sẽ lên lịch chạy quảng cáo của bạn dựa trên {selectedAccount.timezone_name || 'múi giờ mặc định'}. Nhấp và kéo để lên lịch nhiều khung giờ cùng lúc.</p>
                            </div>
                            <AdScheduler value={adSchedule} onChange={setAdSchedule} />
                        </div>
                    )}
                </div>
            )}
             {minBudget > 0 && (
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    Ngân sách tối thiểu mỗi ngày tương đương 1 USD là khoảng {minBudget.toLocaleString('vi-VN')} {selectedAccount.currency}.
                </p>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Độ tuổi</label>
                    <div className="flex items-center space-x-2 mt-1">
                        <input type="number" value={adSetData.ageMin} onChange={e => setAdSetData({...adSetData, ageMin: e.target.value})} className="block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" />
                        <span>-</span>
                        <input type="number" value={adSetData.ageMax} onChange={e => setAdSetData({...adSetData, ageMax: e.target.value})} className="block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                </div>
                 <div>
                    <label htmlFor="gender" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Giới tính</label>
                    <select id="gender" value={adSetData.gender} onChange={e => setAdSetData({...adSetData, gender: e.target.value as Gender})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600">
                        <option value="all">Tất cả</option>
                        <option value="male">Nam</option>
                        <option value="female">Nữ</option>
                    </select>
                </div>
            </div>
             <LocationSelector 
                adAccountId={selectedAccount.id}
                adsToken={adsToken}
                value={adSetData.geo_locations}
                onChange={(locations) => setAdSetData({ ...adSetData, geo_locations: locations })}
             />
            <InterestsSelector
                adsToken={adsToken}
                selectedInterests={interests}
                onInterestsChange={setInterests}
            />
          </div>
        );
      case 3:
        return (
             <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Bước 3: Tạo Quảng cáo (Ad)</h3>
                <div>
                    <label htmlFor="adName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tên quảng cáo</label>
                    <input type="text" id="adName" value={adData.name} onChange={e => setAdData({...adData, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder={`${adSetData.name || 'Ad'} - Creative 1`} />
                </div>
                
                 <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Nội dung quảng cáo</label>
                  <div className="flex rounded-md shadow-sm">
                    <button
                      type="button"
                      onClick={() => setCreativeSource('existing')}
                      className={`relative inline-flex items-center px-4 py-2 rounded-l-md border text-sm font-medium focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${
                        creativeSource === 'existing' 
                          ? 'bg-blue-600 text-white border-blue-600' 
                          : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      Bài viết có sẵn
                    </button>
                    <button
                      type="button"
                      onClick={() => setCreativeSource('new')}
                      className={`relative -ml-px inline-flex items-center px-4 py-2 rounded-r-md border text-sm font-medium focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${
                        creativeSource === 'new' 
                          ? 'bg-blue-600 text-white border-blue-600' 
                          : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      Tạo mới
                    </button>
                  </div>
                </div>

                {creativeSource === 'existing' ? (
                  <>
                    <div>
                      <p className="block text-sm font-medium text-gray-700 dark:text-gray-300">Fanpage</p>
                      <p className="mt-1 font-semibold text-gray-900 dark:text-gray-100 p-2 bg-gray-100 dark:bg-gray-700 rounded-md">{targetPage ? targetPage.name : `Đang tải... (ID: ${HARDCODED_PAGE_ID})`}</p>
                    </div>
                    <div>
                        <label htmlFor="postUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link hoặc ID bài viết</label>
                        <div className="mt-1 flex rounded-md shadow-sm">
                            <input type="text" id="postUrl" value={adData.postUrl} onChange={e => setAdData({...adData, postUrl: e.target.value})} className="block w-full flex-1 rounded-none rounded-l-md border-gray-300 dark:bg-gray-700 dark:border-gray-600" />
                            <button onClick={() => triggerValidatePost()} disabled={!adData.postUrl || !targetPage || loading} className="inline-flex items-center px-3 rounded-r-md border border-l-0 border-gray-300 bg-gray-50 text-gray-500 hover:bg-gray-100 dark:bg-gray-600 dark:text-gray-300 dark:border-gray-500 disabled:opacity-50">Kiểm tra</button>
                        </div>
                    </div>
                    {postValidation.status !== 'idle' && (
                        <div className={`p-3 rounded-md text-sm ${postValidation.status === 'success' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'}`}>
                            {postValidation.message}
                        </div>
                    )}
                  </>
                ) : (
                  <div className="pt-4 border-t border-gray-200 dark:border-gray-600 space-y-6">
                    {/* --- START OF 'NEW' CONTENT INPUTS --- */}
                    {!newAdContent.imageHash && !newAdContent.videoId ? (
                        <div className="text-center p-6 border-2 border-dashed rounded-lg border-gray-300 dark:border-gray-500">
                            <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">1. Upload Media</h3>
                            <p className="mt-1 text-sm text-gray-500">Bắt đầu bằng việc tải lên một ảnh hoặc video.</p>
                            <div className="mt-6">
                                <button
                                    type="button"
                                    onClick={() => setShowUploader(true)}
                                    className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                >
                                    Tải lên Ảnh / Video
                                </button>
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <div className="p-3 rounded-md bg-gray-100 dark:bg-gray-700 flex justify-between items-center">
                                <div>
                                    <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                                        {newAdContent.imageHash ? 'Ảnh đã tải lên:' : 'Video đã tải lên:'}
                                    </p>
                                    <p className="text-xs font-mono text-gray-500 dark:text-gray-400 truncate max-w-xs md:max-w-sm">
                                        {newAdContent.imageHash || newAdContent.videoId}
                                    </p>
                                </div>
                                <button type="button" onClick={resetUploadedMedia} className="text-sm font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 flex-shrink-0 ml-2">
                                    Thay đổi
                                </button>
                            </div>

                            <div>
                                <label htmlFor="newMessage" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Nội dung chính</label>
                                <textarea id="newMessage" rows={3} value={newAdContent.message} onChange={e => setNewAdContent({...newAdContent, message: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="Nội dung sẽ hiển thị trong quảng cáo..."></textarea>
                            </div>

                            {newAdType === 'image' && (
                                <div>
                                    <label htmlFor="newName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tiêu đề</label>
                                    <input type="text" id="newName" value={newAdContent.name} onChange={e => setNewAdContent({...newAdContent, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="Tiêu đề cho quảng cáo ảnh"/>
                                </div>
                            )}
                             {newAdType === 'video' && (
                                <div className="space-y-4">
                                    <div>
                                        <label htmlFor="newTitle" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Tiêu đề video</label>
                                        <input type="text" id="newTitle" value={newAdContent.title} onChange={e => setNewAdContent({...newAdContent, title: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="Tiêu đề cho video"/>
                                    </div>
                                    <div className="p-3 border rounded-md dark:border-gray-600 space-y-2">
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Thumbnail Video</label>
                                        <div className="flex items-center space-x-4">
                                            <label className="flex items-center text-sm">
                                                <input type="radio" name="thumbnailSource" value="auto" checked={thumbnailSource === 'auto'} onChange={() => setThumbnailSource('auto')} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" />
                                                <span className="ml-2 text-gray-700 dark:text-gray-300">Tự động</span>
                                            </label>
                                            <label className="flex items-center text-sm">
                                                <input type="radio" name="thumbnailSource" value="manual" checked={thumbnailSource === 'manual'} onChange={() => setThumbnailSource('manual')} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" />
                                                <span className="ml-2 text-gray-700 dark:text-gray-300">Tải lên</span>
                                            </label>
                                        </div>
                                        {thumbnailSource === 'manual' && (
                                            <div className="mt-2">
                                                {thumbnailUrl ? (
                                                    <div className="flex items-center justify-between text-xs p-2 bg-gray-100 dark:bg-gray-700 rounded">
                                                        <p className="truncate">URL: <span className="font-mono">{thumbnailUrl}</span></p>
                                                        <button onClick={() => setThumbnailUrl(null)} className="ml-2 text-blue-600 hover:text-blue-800 dark:text-blue-400">Thay đổi</button>
                                                    </div>
                                                ) : (
                                                    <button onClick={() => setShowThumbnailUploader(true)} className="w-full text-sm py-1.5 px-3 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-md">
                                                        Tải ảnh thumbnail
                                                    </button>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                            
                            <div className="space-y-2">
                                <label htmlFor="ctaType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Kêu gọi hành động (CTA)</label>
                                <select 
                                    id="ctaType" 
                                    value={ctaType} 
                                    onChange={e => setCtaType(e.target.value as CtaType)} 
                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600"
                                >
                                    <option value="MESSAGE_PAGE">Gửi tin nhắn</option>
                                    <option value="LEARN_MORE">Tìm hiểu thêm</option>
                                    <option value="SHOP_NOW">Mua ngay</option>
                                </select>
                            </div>

                            {ctaType !== 'MESSAGE_PAGE' && (
                                <div>
                                    <label htmlFor="ctaLink" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link đích</label>
                                    <input 
                                        type="url" 
                                        id="ctaLink" 
                                        value={newAdContent.ctaLink} 
                                        onChange={e => setNewAdContent({...newAdContent, ctaLink: e.target.value})} 
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" 
                                        placeholder="https://example.com/product" 
                                    />
                                </div>
                            )}
                        </div>
                    )}
                    
                    {creativeSource === 'new' && ctaType === 'MESSAGE_PAGE' && renderMessageTemplateSection()}

                    <div className="space-y-4 p-4 border rounded-lg dark:border-gray-600 bg-gray-50 dark:bg-gray-900/50">
                        <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Workflow API</h4>
                         <div className="flex items-center space-x-3">
                            <button onClick={() => handleCreateDraftCreative()} disabled={loading || (!newAdContent.imageHash && !newAdContent.videoId)} className="px-3 py-1.5 text-xs font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-gray-400">
                                {creativeId ? 'Tạo lại Creative' : '2. Tạo Creative'}
                            </button>
                             <div className="flex-1 min-w-0 p-1.5 rounded bg-white dark:bg-gray-800 text-xs font-mono truncate">
                                <span className="font-semibold">Creative ID:</span> {creativeId || "Chưa có"}
                            </div>
                         </div>
                         <div className="flex items-center space-x-3">
                            <button onClick={() => triggerPublishAd()} disabled={loading || !creativeId || !adSetId} className="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400">
                                3. Đăng Quảng Cáo
                            </button>
                         </div>
                    </div>
                    
                    <div className="space-y-3">
                        <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Logs API</h4>
                        <div className="bg-gray-900 text-white font-mono text-xs rounded-md p-3 max-h-40 overflow-y-auto">
                            {apiLogs.length > 0 ? apiLogs.map((log, i) => (
                                <p key={i} className={`${log.status === 'error' ? 'text-red-400' : 'text-green-400'}`}>
                                    <span className="text-gray-500">{log.timestamp}</span> [{log.step}]: {log.message}
                                </p>
                            )) : <p className="text-gray-500">Chưa có hoạt động nào...</p>}
                        </div>
                    </div>
                    
                    {showUploader && (
                        <MediaUploader 
                            uploadContext="ad"
                            adAccountId={selectedAccount.id}
                            adsToken={adsToken}
                            onUploadSuccess={handleMediaUploadSuccess}
                            onClose={() => setShowUploader(false)}
                        />
                    )}
                    {showThumbnailUploader && (
                         <MediaUploader 
                            uploadContext="ad"
                            adAccountId={selectedAccount.id}
                            adsToken={adsToken}
                            onUploadSuccess={(result) => handleThumbnailUploadSuccess(result as { type: 'image', value: {hash: string, url: string} })}
                            onClose={() => setShowThumbnailUploader(false)}
                            accept="image/*"
                        />
                    )}
                    {showGreetingMediaUploader && (
                        <MediaUploader
                            uploadContext="template"
                            pageId={targetPage?.id}
                            pageAccessToken={targetPage?.access_token}
                            onUploadSuccess={handleGreetingMediaUploadSuccess}
                            onClose={() => setShowGreetingMediaUploader(false)}
                            accept={uploaderMediaType === 'image' ? "image/*" : "video/*"}
                        />
                    )}
                </div>
                )}
             </div>
         );
      case 4:
        return (
            <div className="text-center bg-green-50 dark:bg-green-900/50 p-6 rounded-lg">
                <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Hoàn tất!</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">Chiến dịch của bạn đã được tạo ở trạng thái Dừng (Paused).</p>
                <div className="mt-4 text-left space-y-2 text-sm font-mono bg-white dark:bg-gray-800 p-4 rounded-md">
                    <p>Campaign ID: <span className="font-bold text-blue-600 dark:text-blue-400">{campaignId}</span></p>
                    <p>Ad Set ID:   <span className="font-bold text-blue-600 dark:text-blue-400">{adSetId}</span></p>
                    <p>Ad ID:       <span className="font-bold text-blue-600 dark:text-blue-400">{adId}</span></p>
                </div>
            </div>
        );
      default: return null;
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
      <div className="min-h-[400px]">
        {renderStepContent()}
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-md text-sm flex items-center">
            <ExclamationCircleIcon className="w-5 h-5 mr-2"/>
            {error}
        </div>
      )}
       {successMessage && (
        <div className="mt-4 p-3 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-md text-sm flex items-center">
            <CheckCircleIcon className="w-5 h-5 mr-2"/>
            {successMessage}
        </div>
      )}
      
      <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
        <button 
          onClick={() => setCurrentStep(s => s - 1)} 
          disabled={loading}
          className={`px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500 ${currentStep === 1 || currentStep === 4 ? 'invisible' : ''}`}
        >
          <ArrowLeftIcon className="w-4 h-4 inline mr-1" />
          Quay lại
        </button>
        
        <div className="flex items-center space-x-2">
            {currentStep === 1 && (
                <>
                    <button
                        onClick={() => triggerCreateCampaign()}
                        disabled={!campaignData.name || loading || !!campaignId}
                        className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        {loading && !campaignId ? <Spinner /> : 'Tạo Campaign'}
                    </button>
                    <button
                        onClick={() => { setCurrentStep(2); setSuccessMessage(null); setError(null); }}
                        disabled={!campaignId || loading}
                        className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed"
                    >
                        Tiếp tục <ArrowRightIcon className="w-4 h-4 inline ml-1" />
                    </button>
                </>
            )}
            {currentStep === 2 && (
                 <>
                    <button
                        onClick={() => triggerCreateAdSet()}
                        disabled={loading || !!adSetId}
                        className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        {loading && !adSetId ? <Spinner /> : 'Tạo Ad Set'}
                    </button>
                    <button
                        onClick={() => { setCurrentStep(3); setSuccessMessage(null); setError(null); }}
                        disabled={!adSetId || loading}
                        className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed"
                    >
                        Tiếp tục <ArrowRightIcon className="w-4 h-4 inline ml-1" />
                    </button>
                </>
            )}
            {currentStep === 3 && (
                <button
                    onClick={() => triggerPublishAd()}
                    disabled={ loading || (creativeSource === 'existing' && !objectStoryId) }
                    className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-blue-400"
                >
                    {loading ? <Spinner /> : (creativeSource === 'existing' ? 'Đăng Quảng Cáo & Hoàn tất' : 'Chuyển sang Workflow API')}
                </button>
            )}
            {currentStep === 4 && (
                <button
                    onClick={resetWizard}
                    className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700"
                >
                    Tạo chiến dịch mới
                </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default PromotePostForm;