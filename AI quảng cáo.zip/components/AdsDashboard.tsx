import React, { useState, useEffect } from 'react';
import { AdAccount, CampaignDraft } from '../types';
import { LogoutIcon, MegaphoneIcon, ArrowLeftIcon, SparklesIcon, UsersIcon, BoltIcon, PhotoIcon, ChartBarIcon } from './Icons';
import PromotePostForm from './PromotePostForm';
import AiCampaignCreator from './AiCampaignCreator';
import AudienceCreator from './AudienceCreator';
import QuickCampaignCreator from './QuickCampaignCreator';
import QuickCreativeCreator from './QuickCreativeCreator';
import CampaignReports from './CampaignReports';

interface AdsDashboardProps {
  selectedAccount: AdAccount;
  adsToken: string;
  pageAccessToken: string | null;
  onLogout: () => void;
  onBack: () => void;
}

type CreatorMode = 'reporting' | 'manual' | 'ai' | 'audience' | 'quick' | 'quick_creative';

const AdsDashboard: React.FC<AdsDashboardProps> = ({ selectedAccount, adsToken, pageAccessToken, onLogout, onBack }) => {
  const [mode, setMode] = useState<CreatorMode>('reporting');
  const [aiDraft, setAiDraft] = useState<CampaignDraft | null>(null);
  const [aiAudienceCommands, setAiAudienceCommands] = useState<any[]>([]);
  const [aiCampaignCommands, setAiCampaignCommands] = useState<any[]>([]);


  useEffect(() => {
    const handleAiAudienceControl = (e: Event) => {
      const command = (e as CustomEvent).detail;
      if (command) {
        setMode('audience');
        setAiAudienceCommands(prev => [...prev, command]);
      }
    };
    
    const handleAiCampaignControl = (e: Event) => {
      const command = (e as CustomEvent).detail;
      if (command) {
        setMode('manual');
        setAiCampaignCommands(prev => [...prev, command]);
      }
    };

    // The AI Quick Creative flow is now self-contained in the widget, so this listener is removed.

    const handleResetFlow = () => {
        setMode('manual');
        setAiAudienceCommands([]);
        setAiCampaignCommands([]);
    };

    window.addEventListener('ai-control-audience', handleAiAudienceControl);
    window.addEventListener('ai-control-campaign', handleAiCampaignControl);
    window.addEventListener('ai-reset-flow', handleResetFlow);
    return () => {
      window.removeEventListener('ai-control-audience', handleAiAudienceControl);
      window.removeEventListener('ai-control-campaign', handleAiCampaignControl);
      window.removeEventListener('ai-reset-flow', handleResetFlow);
    };
  }, []);

  const handleDraftGenerated = (draft: CampaignDraft) => {
    setAiDraft(draft);
    setMode('manual');
  };
  
  const handleSelectMode = (targetMode: CreatorMode) => {
    setMode(targetMode);
    if (targetMode !== 'manual') setAiDraft(null);
  };

  const ModeButton: React.FC<{
    targetMode: CreatorMode;
    icon: React.ReactNode;
    label: string;
  }> = ({ targetMode, icon, label }) => (
    <button
      onClick={() => handleSelectMode(targetMode)}
      className={`flex-shrink-0 flex flex-col items-center justify-center space-y-1 w-28 h-24 p-2 rounded-lg border text-xs font-medium text-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors ${
        mode === targetMode
          ? 'bg-blue-600 text-white border-blue-700 shadow-md'
          : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600'
      }`}
    >
      {icon}
      <span className="whitespace-normal">{label}</span>
    </button>
  );

  const renderContent = () => {
    switch (mode) {
      case 'reporting':
        return <CampaignReports selectedAccount={selectedAccount} adsToken={adsToken} />;
      case 'quick':
        return <QuickCampaignCreator selectedAccount={selectedAccount} adsToken={adsToken} pageAccessToken={pageAccessToken} />;
      case 'quick_creative':
        return <QuickCreativeCreator selectedAccount={selectedAccount} adsToken={adsToken} pageAccessToken={pageAccessToken} />;
      case 'manual':
        return <PromotePostForm selectedAccount={selectedAccount} adsToken={adsToken} initialData={aiDraft} aiCommand={aiCampaignCommands[0]} onAiCommandProcessed={() => setAiCampaignCommands(prev => prev.slice(1))} />;
      case 'ai':
        return <AiCampaignCreator selectedAccount={selectedAccount} adsToken={adsToken} onDraftGenerated={handleDraftGenerated} />;
      case 'audience':
        return <AudienceCreator selectedAccount={selectedAccount} adsToken={adsToken} aiCommand={aiAudienceCommands[0]} onAiCommandProcessed={() => setAiAudienceCommands(prev => prev.slice(1))} />;
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-100 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow-md flex-shrink-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
                <div className="flex items-center min-w-0">
                    <MegaphoneIcon className="w-8 h-8 text-green-500 mr-3 flex-shrink-0" />
                    <div className="flex flex-col min-w-0">
                        <h1 className="text-xl font-bold text-gray-900 dark:text-white truncate">
                           {selectedAccount.name}
                        </h1>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">{selectedAccount.id}</p>
                    </div>
                </div>
                <div className="flex items-center space-x-2">
                    <button 
                        onClick={onBack} 
                        title="Chọn tài khoản khác" 
                        className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-400"
                    >
                        <ArrowLeftIcon className="w-5 h-5" />
                    </button>
                    <button 
                        onClick={onLogout} 
                        title="Đăng xuất" 
                        className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-400"
                    >
                        <LogoutIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>
        </div>
      </header>

      <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
          <div className="flex items-center space-x-3 overflow-x-auto pb-2">
              <ModeButton targetMode="reporting" icon={<ChartBarIcon className="w-6 h-6" />} label="1. Báo cáo" />
              <ModeButton targetMode="manual" icon={<MegaphoneIcon className="w-6 h-6" />} label="2. Tạo qc cơ bản" />
              <ModeButton targetMode="quick" icon={<BoltIcon className="w-6 h-6" />} label="3. Tạo Bài Viết sẵn nhanh" />
              <ModeButton targetMode="quick_creative" icon={<PhotoIcon className="w-6 h-6" />} label="4. Tạo QC tin nhắn mới" />
              <ModeButton targetMode="ai" icon={<SparklesIcon className="w-6 h-6" />} label="5. Trợ lý AI (Tạo nháp)" />
              <ModeButton targetMode="audience" icon={<UsersIcon className="w-6 h-6" />} label="6. Tạo tệp đối tượng" />
          </div>
      </div>
      
      <main className="flex-1 overflow-y-auto">
        {mode === 'reporting' ? (
          renderContent()
        ) : (
          <div className="p-4 md:p-8">
            <div className="max-w-2xl mx-auto">
              {renderContent()}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdsDashboard;