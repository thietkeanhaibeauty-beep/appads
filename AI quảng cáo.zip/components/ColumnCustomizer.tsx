import React, { useState } from 'react';
import { CloseIcon } from './Icons';

interface Column {
    key: string;
    label: string;
    group: string;
}

interface ColumnCustomizerProps {
    isOpen: boolean;
    onClose: () => void;
    allColumns: Column[];
    visibleColumns: Set<string>;
    onSave: (newVisibleColumns: Set<string>) => void;
}

const ColumnCustomizer: React.FC<ColumnCustomizerProps> = ({ isOpen, onClose, allColumns, visibleColumns, onSave }) => {
    const [tempVisibleColumns, setTempVisibleColumns] = useState(new Set(visibleColumns));

    const handleCheckboxChange = (key: string, checked: boolean) => {
        const newSet = new Set(tempVisibleColumns);
        if (checked) {
            newSet.add(key);
        } else {
            newSet.delete(key);
        }
        setTempVisibleColumns(newSet);
    };

    const handleSave = () => {
        onSave(tempVisibleColumns);
    };

    const groupedColumns = allColumns.reduce((acc, col) => {
        if (!acc[col.group]) {
            acc[col.group] = [];
        }
        acc[col.group].push(col);
        return acc;
    }, {} as Record<string, Column[]>);

    const groupOrder = [
        'Thông tin chung', 
        'Hiệu quả', 
        'Tương tác', 
        'Chi phí & Phân phối', 
        'Chuyển đổi', 
        'Video'
    ];

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4" role="dialog" aria-modal="true">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                <div className="flex justify-between items-center p-4 border-b dark:border-gray-600">
                    <div>
                        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Cài đặt hiển thị cột</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Chọn các chỉ số bạn muốn hiển thị trong bảng.</p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200" aria-label="Đóng">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>

                <div className="p-6 overflow-y-auto">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-6">
                        {groupOrder.map(groupName => {
                            const columnsInGroup = groupedColumns[groupName];
                            if (!columnsInGroup) return null;
                            return (
                                <div key={groupName} className="space-y-3">
                                    <h4 className="text-base font-semibold text-gray-900 dark:text-white border-b pb-2 dark:border-gray-600">{groupName}</h4>
                                    <div className="space-y-2">
                                        {columnsInGroup.map(col => (
                                            <label key={col.key} className="flex items-center space-x-3">
                                                <input
                                                    type="checkbox"
                                                    checked={tempVisibleColumns.has(col.key)}
                                                    onChange={(e) => handleCheckboxChange(col.key, e.target.checked)}
                                                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
                                                />
                                                <span className="text-sm text-gray-700 dark:text-gray-300">{col.label}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="flex justify-end items-center p-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-600 rounded-b-lg space-x-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500">
                        Hủy
                    </button>
                    <button onClick={handleSave} className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
                        Áp dụng
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ColumnCustomizer;