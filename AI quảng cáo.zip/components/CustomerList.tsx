
import React from 'react';
import { Customer } from '../types';
import { PhoneIcon } from './Icons';

interface CustomerListProps {
  customers: Customer[];
  selectedCustomerId: string | null;
  onSelectCustomer: (customer: Customer) => void;
}

const CustomerList: React.FC<CustomerListProps> = ({ customers, selectedCustomerId, onSelectCustomer }) => {
  if (customers.length === 0) {
    return <div className="p-4 text-center text-gray-500 dark:text-gray-400">Không tìm thấy khách hàng nào.</div>
  }

  return (
    <div className="overflow-y-auto">
      <ul>
        {customers.map((customer) => (
          <li key={customer.id}>
            <button
              onClick={() => onSelectCustomer(customer)}
              className={`w-full text-left p-4 flex items-center space-x-3 transition-colors duration-150 ${
                selectedCustomerId === customer.id
                  ? 'bg-blue-100 dark:bg-blue-900/50'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              <div className="flex-shrink-0 w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center font-bold text-white">
                {customer.facebookName.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate text-gray-900 dark:text-white">{customer.facebookName}</p>
                {customer.phoneNumber ? (
                    <p className="text-xs text-green-600 dark:text-green-400 flex items-center">
                        <PhoneIcon className="w-3 h-3 mr-1" />
                        {customer.phoneNumber}
                    </p>
                ) : (
                    <p className="text-xs text-gray-500 dark:text-gray-400 italic">Chưa có SĐT</p>
                )}
              </div>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CustomerList;