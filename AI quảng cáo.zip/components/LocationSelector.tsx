import React, { useState, useEffect, useCallback } from 'react';
import { Country, City, GeoLocationTargeting } from '../types';
import * as facebookService from '../services/facebookService';
import { SearchIcon, CloseIcon, ExclamationCircleIcon } from './Icons';
import Spinner from './Spinner';

interface LocationSelectorProps {
  adAccountId: string;
  adsToken: string;
  value: GeoLocationTargeting;
  onChange: (value: GeoLocationTargeting) => void;
}

type LocationType = 'country' | 'city' | 'coordinates';

const LocationSelector: React.FC<LocationSelectorProps> = ({ adAccountId, adsToken, value, onChange }) => {
  const [activeTab, setActiveTab] = useState<LocationType>('country');
  
  // Country State
  const [countryQuery, setCountryQuery] = useState('');
  const [countryResults, setCountryResults] = useState<Country[]>([]);
  const [countryLoading, setCountryLoading] = useState(false);

  // City State
  const [cityQuery, setCityQuery] = useState('');
  const [cityResults, setCityResults] = useState<City[]>([]);
  const [selectedCities, setSelectedCities] = useState<{ key: string; name: string; radius: number }[]>([]);
  const [cityLoading, setCityLoading] = useState(false);
  const [isCityDropdownOpen, setIsCityDropdownOpen] = useState(false);

  // Coordinates State
  const [coordsInput, setCoordsInput] = useState('');
  const [coordsRadius, setCoordsRadius] = useState(1);
  const [selectedCoords, setSelectedCoords] = useState<{ key: string; name: string; latitude: number; longitude: number; radius: number }[]>([]);
  const [coordsError, setCoordsError] = useState('');
  const [coordsLoading, setCoordsLoading] = useState(false);


  // Initialize state from parent's value prop and update when it changes
  useEffect(() => {
    if (value.countries && value.countries.length > 0) {
        setActiveTab('country');
        // When value changes, ensure we clear other location types from internal state
        setSelectedCities([]);
        setSelectedCoords([]);
    } else if (value.cities && value.cities.length > 0) {
        setActiveTab('city');
        // The name is not passed in the `value` prop, so we display the key as a fallback.
        // This will now correctly update when the prop changes.
        setSelectedCities(value.cities.map(c => ({...c, name: `ID: ${c.key}`, radius: c.radius})));
        setSelectedCoords([]);
    } else if (value.custom_locations && value.custom_locations.length > 0) {
        setActiveTab('coordinates');
        setSelectedCoords(value.custom_locations.map((c, i) => ({
            key: `${c.latitude},${c.longitude}`,
            name: `Vị trí tùy chỉnh ${i+1}`,
            ...c
        })));
        setSelectedCities([]);
    } else {
        // If `value` is empty or doesn't match, reset to a clean state
        setActiveTab('country');
        setSelectedCities([]);
        setSelectedCoords([]);
    }
  }, [value]); // Update whenever the `value` prop changes

  // Debounced search for countries
  useEffect(() => {
    if (countryQuery.length < 1) {
      setCountryResults([]);
      return;
    }
    setCountryLoading(true);
    const handler = setTimeout(async () => {
      const results = await facebookService.searchCountries(countryQuery, adsToken);
      setCountryResults(results);
      setCountryLoading(false);
    }, 500);
    return () => clearTimeout(handler);
  }, [countryQuery, adsToken]);

  // Debounced search for cities
  useEffect(() => {
    if (cityQuery.length < 2) {
      setCityResults([]);
      setIsCityDropdownOpen(false);
      return;
    }
    setCityLoading(true);
    const handler = setTimeout(async () => {
      const results = await facebookService.searchCities(cityQuery, adsToken);
      setCityResults(results);
      setCityLoading(false);
      setIsCityDropdownOpen(true);
    }, 500);
    return () => clearTimeout(handler);
  }, [cityQuery, adsToken]);
  
  const handleTabChange = (tab: LocationType) => {
    setActiveTab(tab);
  };

  const handleSelectCountry = (country: Country) => {
    setCountryQuery(country.name);
    setCountryResults([]);
    onChange({ countries: [country.key] });
  };
  
  // --- City Handlers ---
  const handleAddCity = (city: City) => {
    if (!selectedCities.some(c => c.key === city.key)) {
        const newCities = [...selectedCities, { key: city.key, name: city.name, radius: 17 }];
        setSelectedCities(newCities);
        onChange({ cities: newCities.map(c => ({ key: c.key, radius: c.radius, distance_unit: 'kilometer' })) });
    }
    setCityQuery('');
    setCityResults([]);
    setIsCityDropdownOpen(false);
  };
  
  const handleRemoveCity = (key: string) => {
    const newCities = selectedCities.filter(c => c.key !== key);
    setSelectedCities(newCities);
    onChange({ cities: newCities.map(c => ({ key: c.key, radius: c.radius, distance_unit: 'kilometer' })) });
  };
  
  const handleCityRadiusChange = (key: string, radius: number) => {
    const newCities = selectedCities.map(c => c.key === key ? { ...c, radius: Math.max(17, radius) } : c);
    setSelectedCities(newCities);
    onChange({ cities: newCities.map(c => ({ key: c.key, radius: c.radius, distance_unit: 'kilometer' })) });
  };
  
  // --- Coords Handlers ---
  const handleAddCoords = async () => {
    setCoordsError('');
    setCoordsLoading(true);
    const parts = coordsInput.split(',').map(s => s.trim());
    if (parts.length !== 2 || isNaN(parseFloat(parts[0])) || isNaN(parseFloat(parts[1]))) {
        setCoordsError("Định dạng tọa độ không hợp lệ. Dùng: 'latitude, longitude'.");
        setCoordsLoading(false);
        return;
    }
    if (coordsRadius < 1) {
        setCoordsError("Bán kính tối thiểu là 1km.");
        setCoordsLoading(false);
        return;
    }
    
    const lat = parseFloat(parts[0]);
    const lon = parseFloat(parts[1]);

    try {
        const estimate = await facebookService.getReachEstimate(adAccountId, adsToken, {
            geo_locations: { custom_locations: [{ latitude: lat, longitude: lon, radius: coordsRadius, distance_unit: 'kilometer' }] }
        });

        if (estimate.users < 1000) {
            setCoordsError(`Đối tượng quá hẹp (${estimate.users.toLocaleString()} người). Vui lòng tăng bán kính.`);
            setCoordsLoading(false);
            return;
        }

        const newCoord = { key: coordsInput, name: `Vị trí (${coordsInput})`, latitude: lat, longitude: lon, radius: coordsRadius };
        const newCoords = [...selectedCoords, newCoord];
        setSelectedCoords(newCoords);
        onChange({ custom_locations: newCoords.map(c => ({ latitude: c.latitude, longitude: c.longitude, radius: c.radius, distance_unit: 'kilometer' }))});
        setCoordsInput('');
        setCoordsRadius(1);

    } catch (err: any) {
        setCoordsError(err.message);
    } finally {
        setCoordsLoading(false);
    }
  };

  const handleRemoveCoord = (key: string) => {
    const newCoords = selectedCoords.filter(c => c.key !== key);
    setSelectedCoords(newCoords);
    onChange({ custom_locations: newCoords.map(c => ({ latitude: c.latitude, longitude: c.longitude, radius: c.radius, distance_unit: 'kilometer' }))});
  };


  const TabButton: React.FC<{ tab: LocationType, children: React.ReactNode }> = ({ tab, children }) => (
    <button
      onClick={() => handleTabChange(tab)}
      className={`w-1/3 py-2 px-4 text-sm font-medium focus:outline-none ${
        activeTab === tab 
          ? 'bg-blue-600 text-white' 
          : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600'
      }`}
    >
      {children}
    </button>
  );

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Vị trí</label>
      <div className="flex rounded-md shadow-sm border border-gray-300 dark:border-gray-600 mt-1">
        <TabButton tab="country">Quốc gia</TabButton>
        <TabButton tab="city">Thành phố</TabButton>
        <TabButton tab="coordinates">Tọa độ</TabButton>
      </div>

      <div className="mt-4">
        {activeTab === 'country' && (
           <div className="relative">
             <SearchIcon className="pointer-events-none absolute inset-y-0 left-0 h-full w-5 text-gray-400 ml-2" />
             <input type="text" value={countryQuery} onChange={e => setCountryQuery(e.target.value)} placeholder="Tìm quốc gia..." className="block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600 pl-9"/>
             { (countryLoading || countryResults.length > 0) && (
                <ul className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto">
                    {countryLoading ? <li className="px-4 py-2 text-sm text-gray-500">Đang tìm...</li> : 
                        countryResults.map(c => <li key={c.key} onMouseDown={() => handleSelectCountry(c)} className="px-4 py-2 text-sm cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700">{c.name}</li>)
                    }
                </ul>
             )}
           </div>
        )}

        {activeTab === 'city' && (
            <div className="space-y-4">
                <p className="text-xs text-gray-500 dark:text-gray-400">Thả ghim nhiều thành phố. Sau khi chọn, bạn có thể điều chỉnh bán kính (tối thiểu 17km).</p>
                <div className="relative">
                    <SearchIcon className="pointer-events-none absolute inset-y-0 left-0 h-full w-5 text-gray-400 ml-2" />
                    <input type="text" value={cityQuery} onChange={e => setCityQuery(e.target.value)} onFocus={() => cityQuery.length >= 2 && setIsCityDropdownOpen(true)} onBlur={() => setTimeout(() => setIsCityDropdownOpen(false), 200)} placeholder="Tìm thành phố (VD: Hà Nội)..." className="block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600 pl-9"/>
                    {isCityDropdownOpen && (
                         <ul className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto">
                             {cityLoading ? <li className="px-4 py-2 text-sm text-gray-500">Đang tìm...</li> : 
                                 cityResults.length > 0 ? cityResults.map(c => <li key={c.key} onMouseDown={() => handleAddCity(c)} className="px-4 py-2 text-sm cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700">{c.name}{c.region ? `, ${c.region}` : ''}</li>)
                                 : <li className="px-4 py-2 text-sm text-gray-500">Không có kết quả.</li>
                             }
                         </ul>
                    )}
                </div>
                <div className="space-y-2">
                    {selectedCities.map(city => (
                        <div key={city.key} className="flex items-center space-x-2 p-2 bg-gray-50 dark:bg-gray-900/50 rounded-md">
                            <p className="flex-1 text-sm">{city.name}</p>
                            <input type="number" value={city.radius} min={17} onChange={e => handleCityRadiusChange(city.key, parseInt(e.target.value, 10))} className="w-20 rounded-md border-gray-300 shadow-sm text-sm dark:bg-gray-700 dark:border-gray-600" />
                            <span className="text-sm">km</span>
                            <button onClick={() => handleRemoveCity(city.key)} className="text-gray-400 hover:text-red-500"><CloseIcon className="w-4 h-4" /></button>
                        </div>
                    ))}
                    {selectedCities.length === 0 && <p className="text-xs text-center text-gray-500 italic">Chưa có thành phố nào được chọn.</p>}
                </div>
            </div>
        )}

        {activeTab === 'coordinates' && (
            <div className="space-y-4">
                 <p className="text-xs text-gray-500 dark:text-gray-400">Nhập vĩ độ, kinh độ và bán kính (tối thiểu 1km). Hệ thống sẽ kiểm tra tính hợp lệ của vị trí thông qua API của Facebook.</p>
                 <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 items-start">
                    <input type="text" value={coordsInput} onChange={e => setCoordsInput(e.target.value)} placeholder="VD: 21.0285, 105.8542" className="sm:col-span-2 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600"/>
                    <div className="relative">
                        <input type="number" value={coordsRadius} min={1} onChange={e => setCoordsRadius(parseInt(e.target.value, 10))} className="block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600 pr-8" />
                        <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500">km</span>
                    </div>
                 </div>
                 <button onClick={handleAddCoords} disabled={coordsLoading} className="w-full flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400">
                    {coordsLoading ? <Spinner /> : 'Thêm vị trí & Kiểm tra'}
                </button>
                {coordsError && <p className="text-sm text-red-600 dark:text-red-400 flex items-center"><ExclamationCircleIcon className="w-4 h-4 mr-1"/> {coordsError}</p>}
                
                 <div className="space-y-2">
                    {selectedCoords.map(coord => (
                        <div key={coord.key} className="flex items-center space-x-2 p-2 bg-gray-50 dark:bg-gray-900/50 rounded-md">
                            <p className="flex-1 text-sm font-mono">{coord.key} (+{coord.radius}km)</p>
                            <button onClick={() => handleRemoveCoord(coord.key)} className="text-gray-400 hover:text-red-500"><CloseIcon className="w-4 h-4" /></button>
                        </div>
                    ))}
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default LocationSelector;