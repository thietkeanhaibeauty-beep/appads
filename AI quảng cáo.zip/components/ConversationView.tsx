
import React from 'react';
import { Customer } from '../types';
import { ChatIcon, UserIcon, PhoneIcon } from './Icons';

interface ConversationViewProps {
  customer: Customer | null;
  pageId: string;
}

const ConversationView: React.FC<ConversationViewProps> = ({ customer, pageId }) => {
  if (!customer) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400">
        <ChatIcon className="w-16 h-16 mb-4"/>
        <h2 className="text-xl font-semibold">Chọn một khách hàng</h2>
        <p>Lịch sử trò chuyện sẽ được hiển thị ở đây.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex-shrink-0">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center">
            <UserIcon className="w-5 h-5 mr-2" />
            {customer.facebookName}
        </h2>
        {customer.phoneNumber && (
          <p className="text-sm text-green-600 dark:text-green-400 flex items-center mt-1">
            <PhoneIcon className="w-4 h-4 mr-1.5" />
            {customer.phoneNumber}
          </p>
        )}
      </div>
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {customer.conversationHistory.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-end gap-2 ${msg.from.id === pageId ? 'justify-end' : 'justify-start'}`}
          >
            {msg.from.id !== pageId && (
                <div className="flex-shrink-0 w-8 h-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center font-bold text-white text-sm">
                    {msg.from.name.charAt(0).toUpperCase()}
                </div>
            )}
            <div
              className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${
                msg.from.id === pageId
                  ? 'bg-blue-500 text-white rounded-br-none'
                  : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 rounded-bl-none'
              }`}
            >
              <p className="text-sm">{msg.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConversationView;