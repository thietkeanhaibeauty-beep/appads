
import React, { useState, useCallback } from 'react';
import { AdAccount, Interest } from '../types';
import * as quickAiService from '../services/quickAiService';
import * as quickFacebookService from '../services/quickFacebookService';
import * as quickPostValidatorService from '../services/quickPostValidatorService';
import { BoltIcon, CheckCircleIcon, ExclamationCircleIcon } from './Icons';
import Spinner from './Spinner';

interface QuickCampaignCreatorProps {
    selectedAccount: AdAccount;
    adsToken: string;
    pageAccessToken: string | null;
}

type Status = 'idle' | 'parsing' | 'validating' | 'confirming' | 'creating' | 'completed' | 'error';

interface EnrichedData extends quickAiService.QuickCampaignParseResult {
    validatedPostUrl: { valid: boolean, objectStoryId?: string, pageId?: string, message: string };
    validatedInterests: Interest[];
}

const QuickCampaignCreator: React.FC<QuickCampaignCreatorProps> = ({ selectedAccount, adsToken, pageAccessToken }) => {
    const [rawInput, setRawInput] = useState('');
    const [status, setStatus] = useState<Status>('idle');
    const [enrichedData, setEnrichedData] = useState<EnrichedData | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [apiLogs, setApiLogs] = useState<{ step: string, status: 'success' | 'error', message: string }[]>([]);
    const [createdIds, setCreatedIds] = useState({ campaignId: '', adSetId: '', adId: '' });

    const addApiLog = useCallback((step: string, status: 'success' | 'error', message: string) => {
        setApiLogs(prev => [...prev, { step, status, message }]);
    }, []);

    const resetState = () => {
        setStatus('idle');
        setEnrichedData(null);
        setError(null);
        setApiLogs([]);
        setCreatedIds({ campaignId: '', adSetId: '', adId: '' });
    };

    const handleParse = async () => {
        if (!rawInput.trim()) return;
        if (!pageAccessToken) {
            setError("Page Access Token không có sẵn. Không thể xác thực bài viết.");
            setStatus('error');
            return;
        }
        setStatus('parsing');
        setError(null);
        setApiLogs([]);
        setEnrichedData(null);

        try {
            const parsedData = await quickAiService.parseQuickCampaignPrompt(rawInput);
            setStatus('validating');
            
            // Use pageAccessToken for validation
            const postValidation = await quickPostValidatorService.validatePostId(parsedData.postUrl, pageAccessToken);
            if (!postValidation.valid || !postValidation.pageId || !postValidation.postId) {
                throw new Error(`Lỗi xác thực bài viết: ${postValidation.message}`);
            }

            const interestPromises = parsedData.interestKeywords.map(keyword => quickFacebookService.searchInterests(keyword, adsToken));
            const interestResults = await Promise.all(interestPromises);
            const flatInterests = interestResults.flat();
            const uniqueInterests = Array.from(new Map(flatInterests.map(item => [item.id, item])).values());
            
            setEnrichedData({
                ...parsedData,
                validatedPostUrl: { ...postValidation, objectStoryId: `${postValidation.pageId}_${postValidation.postId}`},
                validatedInterests: uniqueInterests,
            });
            setStatus('confirming');

        } catch (err: any) {
            setError(err.message || "Lỗi không xác định khi phân tích dữ liệu.");
            setStatus('error');
        }
    };

    const handleCreate = async () => {
        if (!enrichedData || !pageAccessToken) {
            setError("Dữ liệu không đầy đủ hoặc thiếu Page Access Token để tạo quảng cáo.");
            setStatus('error');
            return;
        };
        setStatus('creating');

        try {
            addApiLog('Bước 1: Tạo Campaign', 'success', 'Bắt đầu...');
            const campaignId = await quickFacebookService.createCampaign(
                selectedAccount.id, 
                adsToken, // Campaign creation uses adsToken
                enrichedData.campaignName, 
                'OUTCOME_ENGAGEMENT'
            );
            addApiLog('Bước 1: Tạo Campaign', 'success', `Thành công! ID: ${campaignId}`);
            setCreatedIds(prev => ({ ...prev, campaignId }));

            addApiLog('Bước 2: Tạo Ad Set', 'success', 'Bắt đầu...');
            const targeting: any = {
                age_min: enrichedData.ageMin,
                age_max: enrichedData.ageMax,
                geo_locations: {},
                targeting_automation: { advantage_audience: 0 },
            };
            if (enrichedData.gender !== 'all') {
                targeting.genders = [enrichedData.gender === 'male' ? 1 : 2];
            }
            if (enrichedData.latitude && enrichedData.longitude) {
                targeting.geo_locations.custom_locations = [{ 
                    latitude: enrichedData.latitude, 
                    longitude: enrichedData.longitude, 
                    radius: 10,
                    distance_unit: 'kilometer' 
                }];
            } else {
                targeting.geo_locations.countries = ['VN'];
            }
            if (enrichedData.validatedInterests.length > 0) {
                targeting.flexible_spec = [{ interests: enrichedData.validatedInterests.map(i => ({ id: i.id, name: i.name })) }];
            }

            const adSetId = await quickFacebookService.createAdSet(selectedAccount.id, adsToken, { // AdSet creation uses adsToken
                campaignId,
                name: `${enrichedData.campaignName} Ad Set`,
                dailyBudget: enrichedData.dailyBudget,
                currency: selectedAccount.currency!,
                targeting,
                optimizationGoal: 'CONVERSATIONS',
                promotedObject: { page_id: enrichedData.validatedPostUrl.pageId! },
            });
            addApiLog('Bước 2: Tạo Ad Set', 'success', `Thành công! ID: ${adSetId}`);
            setCreatedIds(prev => ({ ...prev, adSetId }));

            addApiLog('Bước 3: Tạo Ad', 'success', 'Bắt đầu...');
            // Use pageAccessToken for creative and ad
            const creativeId = await quickFacebookService.createAdCreativeFromPost(
                selectedAccount.id,
                enrichedData.validatedPostUrl.objectStoryId!,
                pageAccessToken 
            );
            addApiLog('Bước 3: Tạo Ad', 'success', `Tạo Creative thành công! ID: ${creativeId}`);

            const adId = await quickFacebookService.createAd(selectedAccount.id, pageAccessToken, {
                adSetId,
                name: `${enrichedData.campaignName} Ad`,
                creativeId,
            });
            addApiLog('Bước 3: Tạo Ad', 'success', `Thành công! Ad ID: ${adId}`);
            setCreatedIds(prev => ({ ...prev, adId }));

            setStatus('completed');

        } catch (err: any) {
            setError(err.message);
            addApiLog('Lỗi nghiêm trọng', 'error', err.message);
            setStatus('error');
        }
    };
    
    const isBusy = status === 'parsing' || status === 'validating' || status === 'creating';

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                <BoltIcon className="w-6 h-6 mr-2" />
                Tạo chiến dịch nhanh
            </h3>
            
            {status !== 'confirming' && status !== 'creating' && status !== 'completed' && (
                <>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                        Dán thông tin chiến dịch của bạn vào ô bên dưới. AI sẽ tự động phân tích và thiết lập.
                    </p>
                    <textarea 
                        value={rawInput}
                        onChange={e => setRawInput(e.target.value)}
                        rows={10}
                        className="w-full p-2 border rounded-md font-mono text-sm bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                        placeholder={`Tên chiến dịch: Anh tuấn\n20 40t\nnữ\n400k\nvị trí: 21.3941, 106.6228\nsở thích: làm đẹp, spa\nlink bài viết: ...`}
                        disabled={isBusy}
                    />
                    <button onClick={handleParse} disabled={isBusy || !rawInput.trim()} className="w-full inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 disabled:bg-gray-400">
                        {isBusy ? <Spinner /> : 'Phân tích với AI'}
                    </button>
                </>
            )}

            {enrichedData && (status === 'confirming' || status === 'creating' || status === 'completed') && (
                <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg space-y-3">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Vui lòng xác nhận thông tin:</h4>
                    <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
                        <li><strong>Tên chiến dịch:</strong> {enrichedData.campaignName}</li>
                        <li><strong>Ngân sách hàng ngày:</strong> {enrichedData.dailyBudget}</li>
                        <li><strong>Độ tuổi:</strong> {enrichedData.ageMin} - {enrichedData.ageMax}</li>
                        <li><strong>Giới tính:</strong> {enrichedData.gender}</li>
                        <li>
                            <strong>Vị trí:</strong> 
                            {enrichedData.latitude && enrichedData.longitude 
                                ? `Lat: ${enrichedData.latitude}, Lon: ${enrichedData.longitude} (+10km)`
                                : 'Mặc định: Việt Nam'}
                        </li>
                        <li><strong>Sở thích:</strong> {enrichedData.validatedInterests.length > 0 ? enrichedData.validatedInterests.map(i => i.name).join(', ') : '(Không có)'}</li>
                        <li className="flex items-start">
                            <strong className="flex-shrink-0 mr-1">Bài viết:</strong> 
                            <span className={`truncate ${enrichedData.validatedPostUrl.valid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                {enrichedData.postUrl} ({enrichedData.validatedPostUrl.message})
                            </span>
                        </li>
                    </ul>
                    {status === 'confirming' && (
                        <div className="flex items-center space-x-2 pt-2">
                             <button onClick={handleCreate} className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700">
                                Xác nhận & Tạo
                            </button>
                            <button onClick={resetState} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-500">
                                Sửa lại
                            </button>
                        </div>
                    )}
                </div>
            )}
            
            {apiLogs.length > 0 && (
                <div className="space-y-2">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200">Tiến trình thực thi:</h4>
                    <div className="bg-gray-900 text-white font-mono text-xs rounded-md p-3 max-h-48 overflow-y-auto">
                        {apiLogs.map((log, i) => (
                            <p key={i} className={log.status === 'error' ? 'text-red-400' : 'text-green-400'}>
                                {log.step}: {log.message}
                            </p>
                        ))}
                    </div>
                </div>
            )}

            {status === 'completed' && (
                <div className="p-4 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-md text-center">
                    <CheckCircleIcon className="w-12 h-12 mx-auto mb-2" />
                    <h4 className="font-semibold">Hoàn tất!</h4>
                    <p className="text-sm">Chiến dịch đã được tạo thành công ở trạng thái Dừng (Paused).</p>
                    <button onClick={resetState} className="mt-4 px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
                        Tạo chiến dịch nhanh khác
                    </button>
                </div>
            )}

            {status === 'error' && error && (
                <div className="p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-md text-sm">
                    <div className="flex items-center">
                        <ExclamationCircleIcon className="w-5 h-5 mr-2"/>
                        <p className="font-semibold">Đã xảy ra lỗi:</p>
                    </div>
                    <p className="mt-1 ml-7">{error}</p>
                     <button onClick={resetState} className="mt-2 ml-7 text-sm font-medium text-blue-700 dark:text-blue-300 hover:underline">
                        Thử lại
                    </button>
                </div>
            )}
        </div>
    );
};

export default QuickCampaignCreator;
