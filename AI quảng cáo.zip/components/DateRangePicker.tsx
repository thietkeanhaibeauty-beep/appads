import React, { useState, useEffect, useRef } from 'react';
import { CalendarIcon } from './Icons';

// Helper function to format date as YYYY-MM-DD
const formatDate = (date: Date): string => {
    return date.toISOString().split('T')[0];
};

interface DateRangePickerProps {
    value: string; // "YYYY-MM-DD - YYYY-MM-DD"
    onChange: (value: string) => void;
}

const DateRangePicker: React.FC<DateRangePickerProps> = ({ value, onChange }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [startDate, setStartDate] = useState<Date | null>(null);
    const [endDate, setEndDate] = useState<Date | null>(null);
    const [hoverDate, setHoverDate] = useState<Date | null>(null);
    const [visibleDate, setVisibleDate] = useState(new Date());
    const wrapperRef = useRef<HTMLDivElement>(null);

    // Parse initial value from parent
    useEffect(() => {
        const [startStr, endStr] = value.split(' - ');
        if (startStr && endStr) {
            const start = new Date(startStr);
            const end = new Date(endStr);
            if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
                setStartDate(start);
                setEndDate(end);
                setVisibleDate(start); 
            }
        }
    }, [value]);

    // Click outside handler
    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [wrapperRef]);
    
    const handleDayClick = (day: Date) => {
        if (!startDate || (startDate && endDate)) {
            setStartDate(day);
            setEndDate(null);
            setHoverDate(null);
        } else if (startDate && !endDate) {
            if (day < startDate) {
                setEndDate(startDate);
                setStartDate(day);
            } else {
                setEndDate(day);
            }
            setHoverDate(null);
        }
    };
    
    const quickRanges = [
        { label: 'Hôm nay', days: 0 },
        { label: 'Hôm qua', days: 1, yesterday: true },
        { label: '7 ngày qua', days: 6 },
        { label: '14 ngày qua', days: 13 },
        { label: '28 ngày qua', days: 27 },
        { label: '30 ngày qua', days: 29 },
        { label: 'Tháng này', type: 'this_month' },
        { label: 'Tháng trước', type: 'last_month' },
    ];
    
    const handleQuickSelect = (range: typeof quickRanges[0]) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        let newStart: Date;
        let newEnd: Date;

        if (range.type === 'this_month') {
            newStart = new Date(today.getFullYear(), today.getMonth(), 1);
            newEnd = today;
        } else if (range.type === 'last_month') {
            newStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            newEnd = new Date(today.getFullYear(), today.getMonth(), 0);
        } else if (range.yesterday) {
            const yesterday = new Date(today);
            yesterday.setDate(today.getDate() - 1);
            newStart = yesterday;
            newEnd = yesterday;
        } else {
            newEnd = new Date(today);
            newStart = new Date(today);
            newStart.setDate(today.getDate() - range.days!);
        }
        setStartDate(newStart);
        setEndDate(newEnd);
        setVisibleDate(newStart);
    };

    const handleUpdate = () => {
        if (startDate && endDate) {
            onChange(`${formatDate(startDate)} - ${formatDate(endDate)}`);
        }
        setIsOpen(false);
    };

    const handleCancel = () => {
        const [startStr, endStr] = value.split(' - ');
        if (startStr && endStr) {
            setStartDate(new Date(startStr));
            setEndDate(new Date(endStr));
        }
        setIsOpen(false);
    };
    
    const changeMonth = (amount: number) => {
        setVisibleDate(prev => {
            const newDate = new Date(prev);
            newDate.setDate(1);
            newDate.setMonth(newDate.getMonth() + amount);
            return newDate;
        });
    };

    const renderMonth = (date: Date) => {
        const year = date.getFullYear();
        const month = date.getMonth();
        const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0=Sun
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        const blanks = Array.from({ length: firstDayOfMonth });
        const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
        
        const weekDays = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];

        return (
            <div className="p-2 w-64">
                <div className="grid grid-cols-7 gap-1 text-center text-xs">
                    {weekDays.map(d => <div key={d} className="font-semibold text-gray-500 dark:text-gray-400 w-8 h-8 flex items-center justify-center">{d}</div>)}
                    {blanks.map((_, i) => <div key={`blank-${i}`}></div>)}
                    {days.map(d => {
                        const dayDate = new Date(year, month, d);
                        dayDate.setHours(0,0,0,0);
                        
                        const isSelectedStart = startDate && formatDate(dayDate) === formatDate(startDate);
                        const isSelectedEnd = endDate && formatDate(dayDate) === formatDate(endDate);
                        
                        const isHovering = hoverDate && !endDate && startDate;
                        const potentialEndDate = isHovering && hoverDate < startDate! ? startDate : hoverDate;
                        const potentialStartDate = isHovering && hoverDate < startDate! ? hoverDate : startDate;

                        const isInRange = (startDate && endDate && dayDate > startDate && dayDate < endDate) ||
                                          (isHovering && dayDate >= potentialStartDate! && dayDate <= potentialEndDate!);

                        let classes = 'w-8 h-8 flex items-center justify-center rounded-full cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600';
                        
                        if ((isSelectedStart && !endDate) || (isSelectedStart && isSelectedEnd)) {
                            classes = 'w-8 h-8 flex items-center justify-center rounded-full cursor-pointer bg-blue-600 text-white';
                        } else if (isInRange) {
                            classes = 'w-8 h-8 flex items-center justify-center rounded-none cursor-pointer bg-blue-100 dark:bg-blue-900/50';
                            if(isSelectedStart || (potentialStartDate && formatDate(dayDate) === formatDate(potentialStartDate))) {
                                classes = 'w-8 h-8 flex items-center justify-center rounded-l-full cursor-pointer bg-blue-600 text-white';
                            }
                            if(isSelectedEnd || (potentialEndDate && formatDate(dayDate) === formatDate(potentialEndDate))) {
                                 classes = 'w-8 h-8 flex items-center justify-center rounded-r-full cursor-pointer bg-blue-600 text-white';
                            }
                        }
                        
                        return (
                            <button key={d} 
                                 onClick={() => handleDayClick(dayDate)} 
                                 onMouseEnter={() => setHoverDate(dayDate)}
                                 className={classes}>
                                {d}
                            </button>
                        );
                    })}
                </div>
            </div>
        );
    };

    const nextVisibleMonth = new Date(visibleDate);
    nextVisibleMonth.setMonth(visibleDate.getMonth() + 1);

    return (
        <div ref={wrapperRef} className="relative">
            <button onClick={() => setIsOpen(!isOpen)} className="w-[250px] flex items-center gap-2 px-3 py-2 text-sm bg-white border border-gray-300 rounded-md dark:bg-gray-900 dark:border-gray-600 dark:text-white">
                <CalendarIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                <span>{value}</span>
            </button>
            {isOpen && (
                <div className="absolute top-full mt-2 z-20 bg-white dark:bg-gray-800 rounded-lg shadow-xl border dark:border-gray-700 flex flex-col" onMouseLeave={() => setHoverDate(null)}>
                    <div className="flex">
                        <div className="w-40 border-r dark:border-gray-700 p-2 flex flex-col space-y-1">
                            <h4 className="text-sm font-semibold mb-1 px-2">Chọn nhanh</h4>
                            {quickRanges.map(range => (
                                <button key={range.label} onClick={() => handleQuickSelect(range)} className="w-full text-left text-sm px-2 py-1.5 rounded hover:bg-gray-100 dark:hover:bg-gray-700">
                                    {range.label}
                                </button>
                            ))}
                        </div>
                        <div className="p-2">
                             <div className="flex justify-around items-center mb-2 px-4">
                                <button onClick={() => changeMonth(-1)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-600">&lt;</button>
                                <span className="font-semibold text-sm w-32 text-center">Tháng {visibleDate.getMonth() + 1}, {visibleDate.getFullYear()}</span>
                                <span className="font-semibold text-sm w-32 text-center">Tháng {nextVisibleMonth.getMonth() + 1}, {nextVisibleMonth.getFullYear()}</span>
                                <button onClick={() => changeMonth(1)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-600">&gt;</button>
                            </div>
                            <div className="flex">
                                {renderMonth(visibleDate)}
                                {renderMonth(nextVisibleMonth)}
                            </div>
                        </div>
                    </div>
                    <div className="border-t dark:border-gray-700 p-2 flex justify-end gap-2">
                        <button onClick={handleCancel} className="px-3 py-1.5 text-sm font-medium border rounded-md hover:bg-gray-100 dark:border-gray-600 dark:hover:bg-gray-700">Hủy</button>
                        <button onClick={handleUpdate} className="px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">Cập nhật</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DateRangePicker;
