import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { AdAccount, Insight } from '../types';
import * as facebookService from '../services/facebookService';
import useLocalStorage from '../hooks/useLocalStorage';
import Spinner from './Spinner';
import { FilterIcon, SettingsIcon, UploadIcon as ExportIcon, FolderIcon, Squares2X2Icon, DocumentIcon } from './Icons';
import DateRangePicker from './DateRangePicker';
import ColumnCustomizer from './ColumnCustomizer';

// --- Data Extractor Helpers ---
const formatNumber = (value: string | number | undefined, fractionDigits = 2) => {
    if (value === undefined || value === null || value === 'N/A') return 'N/A';
    const num = Number(value);
    if (isNaN(num)) return 'N/A';
    return num.toLocaleString('vi-VN', {
        minimumFractionDigits: fractionDigits,
        maximumFractionDigits: fractionDigits,
    });
};

const getPrimaryAction = (insight: Insight, actionPrefix: string[]): { value: string; type: string } | undefined => {
    if (!insight.actions) return undefined;
    for (const prefix of actionPrefix) {
        const action = insight.actions.find(a => a.action_type.startsWith(prefix));
        if (action) return { value: action.value, type: action.action_type };
    }
    return undefined;
};

const getPrimaryResult = (insight: Insight): { value?: string, type?: string } => {
    if (!insight.actions || !insight.objective) return {};

    const objectiveToActionMap: { [key: string]: string[] } = {
        'OUTCOME_LEADS': ['lead', 'onsite_lead'],
        'LEAD_GENERATION': ['lead', 'onsite_lead'],
        'OUTCOME_SALES': ['purchase', 'offsite_conversion.fb_pixel_purchase'],
        'CONVERSIONS': ['purchase', 'offsite_conversion.fb_pixel_purchase'],
        'OUTCOME_ENGAGEMENT': ['post_engagement'],
        'POST_ENGAGEMENT': ['post_engagement'],
        'MESSAGES': ['onsite_conversion.messaging_conversation_started_7d', 'conversations'],
        'OUTCOME_AWARENESS': ['reach'],
        'REACH': ['reach'],
        'OUTCOME_TRAFFIC': ['link_click', 'landing_page_view'],
        'TRAFFIC': ['link_click', 'landing_page_view'],
        'VIDEO_VIEWS': ['video_view'],
    };

    const possibleActions = objectiveToActionMap[insight.objective.toUpperCase()] || [];

    for (const actionType of possibleActions) {
        const action = insight.actions.find(a => a.action_type === actionType);
        if (action) {
            return { value: action.value, type: action.action_type };
        }
    }
    return insight.actions[0] ? { value: insight.actions[0].value, type: insight.actions[0].action_type } : {};
};

const getCostPerPrimaryResult = (insight: Insight): string | undefined => {
    if (!insight.cost_per_action_type) return undefined;
    const primaryResult = getPrimaryResult(insight);
    if (!primaryResult.type) return undefined;

    const costAction = insight.cost_per_action_type.find(cpa => cpa.action_type === primaryResult.type);
    return costAction?.value;
};

const getActionValue = <T extends keyof Insight>(insight: Insight, actionKey: T, actionType: string): string | undefined => {
    const actions = insight[actionKey] as { action_type: string; value: string }[] | undefined;
    return actions?.find(a => a.action_type === actionType)?.value;
};


const ALL_COLUMNS = [
    // Thông tin chung
    { key: 'campaign_name', label: 'Tên chiến dịch', group: 'Thông tin chung', apiField: 'campaign_name', default: true },
    { key: 'adset_name', label: 'Tên nhóm quảng cáo', group: 'Thông tin chung', apiField: 'adset_name', default: true },
    { key: 'ad_name', label: 'Tên quảng cáo', group: 'Thông tin chung', apiField: 'ad_name', default: false },
    { key: 'objective', label: 'Mục tiêu', group: 'Thông tin chung', apiField: 'objective' },
    { key: 'date_start', label: 'Ngày bắt đầu', group: 'Thông tin chung', apiField: 'date_start' },
    { key: 'date_stop', label: 'Ngày kết thúc', group: 'Thông tin chung', apiField: 'date_stop' },
    { key: 'campaign_id', label: 'ID Chiến dịch', group: 'Thông tin chung', apiField: 'campaign_id' },
    { key: 'adset_id', label: 'ID Nhóm quảng cáo', group: 'Thông tin chung', apiField: 'adset_id' },
    { key: 'ad_id', label: 'ID Quảng cáo', group: 'Thông tin chung', apiField: 'ad_id' },
    // Hiệu quả
    { key: 'impressions', label: 'Lượt hiển thị', group: 'Hiệu quả', apiField: 'impressions', default: true, align: 'right', extractor: (r: Insight) => formatNumber(r.impressions, 0) },
    { key: 'reach', label: 'Lượt tiếp cận', group: 'Hiệu quả', apiField: 'reach', align: 'right', extractor: (r: Insight) => formatNumber(r.reach, 0) },
    { key: 'frequency', label: 'Tần suất', group: 'Hiệu quả', apiField: 'frequency', align: 'right', extractor: (r: Insight) => formatNumber(r.frequency, 2) },
    // Tương tác
    { key: 'clicks', label: 'Lượt nhấp', group: 'Tương tác', apiField: 'clicks', default: true, align: 'right', extractor: (r: Insight) => formatNumber(r.clicks, 0) },
    { key: 'ctr', label: 'CTR', group: 'Tương tác', apiField: 'ctr', default: true, align: 'right', extractor: (r: Insight) => formatNumber(r.ctr, 2) + '%' },
    { key: 'actions', label: 'Hành động', group: 'Tương tác', apiField: 'actions', align: 'right', extractor: (r: Insight) => formatNumber(getPrimaryAction(r, ['post_engagement'])?.value, 0) },
    { key: 'engagement_rate_ranking', label: 'Xếp hạng tỷ lệ tương tác', group: 'Tương tác', apiField: 'engagement_rate_ranking' },
    { key: 'quality_ranking', label: 'Xếp hạng chất lượng', group: 'Tương tác', apiField: 'quality_ranking' },
    // Chi phí & Phân phối
    { key: 'spend', label: 'Chi tiêu', group: 'Chi phí & Phân phối', apiField: 'spend', default: true, align: 'right', extractor: (r: Insight) => formatNumber(r.spend, 0) },
    { key: 'budget', label: 'Ngân sách', group: 'Chi phí & Phân phối', default: true, align: 'left' },
    { key: 'cpc', label: 'CPC', group: 'Chi phí & Phân phối', apiField: 'cpc', default: true, align: 'right', extractor: (r: Insight) => formatNumber(r.cpc, 0) },
    { key: 'cpm', label: 'CPM', group: 'Chi phí & Phân phối', apiField: 'cpm', default: true, align: 'right', extractor: (r: Insight) => formatNumber(r.cpm, 0) },
    { key: 'cpp', label: 'CPP', group: 'Chi phí & Phân phối', apiField: 'cpp', align: 'right', extractor: (r: Insight) => formatNumber(r.cpp, 0) },
    { key: 'cost_per_unique_click', label: 'Chi phí/lượt nhấp duy nhất', group: 'Chi phí & Phân phối', apiField: 'cost_per_unique_click', align: 'right', extractor: (r: Insight) => formatNumber(r.cost_per_unique_click, 0) },
    { key: 'cost_per_result', label: 'Chi phí/Kết quả', group: 'Chi phí & Phân phối', apiField: ['cost_per_action_type', 'objective', 'actions'], default: true, align: 'right', extractor: (r: Insight) => formatNumber(getCostPerPrimaryResult(r), 0) },
    // Chuyển đổi
    { key: 'results', label: 'Kết quả', group: 'Chuyển đổi', apiField: ['actions', 'objective'], default: true, align: 'right', extractor: (r: Insight) => formatNumber(getPrimaryResult(r)?.value, 0) },
    { key: 'website_purchase_roas', label: 'ROAS', group: 'Chuyển đổi', apiField: 'website_purchase_roas', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'website_purchase_roas', 'purchase'), 2) },
    { key: 'action_values', label: 'Giá trị hành động', group: 'Chuyển đổi', apiField: 'action_values', align: 'right', extractor: (r: Insight) => formatNumber(getPrimaryAction(r, ['purchase'])?.value, 0) },
    { key: 'cost_per_action_type', label: 'Chi phí/loại hành động', group: 'Chuyển đổi', apiField: 'cost_per_action_type', align: 'right', extractor: (r: Insight) => formatNumber(getCostPerPrimaryResult(r), 0) },
    { key: 'conversion_rate_ranking', label: 'Xếp hạng tỷ lệ chuyển đổi', group: 'Chuyển đổi', apiField: 'conversion_rate_ranking' },
    // Video
    { key: 'video_play_actions', label: 'Lượt phát video', group: 'Video', apiField: 'video_play_actions', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'video_play_actions', 'video_view'), 0) },
    { key: 'video_p25_watched_actions', label: 'Xem video 25%', group: 'Video', apiField: 'video_p25_watched_actions', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'video_p25_watched_actions', 'video_view'), 0) },
    { key: 'video_p50_watched_actions', label: 'Xem video 50%', group: 'Video', apiField: 'video_p50_watched_actions', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'video_p50_watched_actions', 'video_view'), 0) },
    { key: 'video_p75_watched_actions', label: 'Xem video 75%', group: 'Video', apiField: 'video_p75_watched_actions', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'video_p75_watched_actions', 'video_view'), 0) },
    { key: 'video_p100_watched_actions', label: 'Xem video 100%', group: 'Video', apiField: 'video_p100_watched_actions', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'video_p100_watched_actions', 'video_view'), 0) },
    { key: 'cost_per_thruplay', label: 'Chi phí/ThruPlay', group: 'Video', apiField: 'cost_per_thruplay', align: 'right', extractor: (r: Insight) => formatNumber(getActionValue(r, 'cost_per_thruplay', 'video_view'), 0) },
];


const DEFAULT_COLUMNS = new Set(ALL_COLUMNS.filter(c => c.default).map(c => c.key));


// A simple toggle switch component
const ToggleSwitch: React.FC<{
  checked: boolean;
  onChange: (checked: boolean) => Promise<void>;
  disabled?: boolean;
}> = ({ checked, onChange, disabled }) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const handleChange = async () => {
    if (disabled || isUpdating) return;
    setIsUpdating(true);
    try {
        await onChange(!checked);
    } catch (e) {
        console.error("Failed to toggle status:", e);
    } finally {
        setIsUpdating(false);
    }
  };

  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={handleChange}
      disabled={disabled || isUpdating}
      className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed ${
        checked ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'
      }`}
    >
      <span
        className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${
          checked ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
       {isUpdating && <div className="absolute inset-0 flex items-center justify-center"><div className="w-3 h-3 border-2 border-t-transparent border-blue-200 rounded-full animate-spin"></div></div>}
    </button>
  );
};

interface CampaignReportsProps {
    selectedAccount: AdAccount;
    adsToken: string;
}

const CampaignReports: React.FC<CampaignReportsProps> = ({ selectedAccount, adsToken }) => {
    const today = new Date().toISOString().split('T')[0];
    const [dateRange, setDateRange] = useState(`${today} - ${today}`);
    const [insights, setInsights] = useState<Insight[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [isColumnModalOpen, setIsColumnModalOpen] = useState(false);
    const [visibleColumns, setVisibleColumns] = useLocalStorage<string[]>('campaign_report_columns_v3', Array.from(DEFAULT_COLUMNS));
    
    // State for reordering and resizing
    const [columnOrder, setColumnOrder] = useLocalStorage<string[]>('campaign_report_order_v1', ALL_COLUMNS.map(c => c.key));
    const [columnWidths, setColumnWidths] = useLocalStorage<Record<string, number>>('campaign_report_widths_v1', {});

    // State for drill-down
    type ReportLevel = 'campaign' | 'adset' | 'ad';
    const [level, setLevel] = useState<ReportLevel>('campaign');
    const [path, setPath] = useState<{ level: ReportLevel, id: string, name: string }[]>([]);
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

    const fetchInsights = useCallback(async () => {
        const [since, until] = dateRange.split(' - ').map(d => d.trim());
        if (!since || !until || !/^\d{4}-\d{2}-\d{2}$/.test(since) || !/^\d{4}-\d{2}-\d{2}$/.test(until)) {
            setError("Định dạng ngày không hợp lệ. Vui lòng sử dụng 'YYYY-MM-DD - YYYY-MM-DD'.");
            return;
        }

        setLoading(true);
        setError(null);
        setInsights([]);
        // Reset navigation on new fetch
        setLevel('campaign');
        setPath([]);
        setSelectedIds(new Set());

        try {
            const visibleSet = new Set(visibleColumns);
            const apiFields = new Set<string>();
            ALL_COLUMNS.forEach(col => {
                if (visibleSet.has(col.key) && col.apiField) {
                    if (Array.isArray(col.apiField)) {
                        col.apiField.forEach(f => apiFields.add(f));
                    } else {
                        apiFields.add(col.apiField as string);
                    }
                }
            });

            const requiredApiFields = Array.from(apiFields);
            const data = await facebookService.getInsights(selectedAccount.id, adsToken, selectedAccount.currency || 'USD', { since, until }, requiredApiFields);
            setInsights(data);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    }, [dateRange, selectedAccount, adsToken, visibleColumns]);

    const handleStatusToggle = async (objectId: string, currentStatus: Insight['status']) => {
        try {
            const newStatus = currentStatus === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
            await facebookService.updateAdObjectStatus(objectId, adsToken, newStatus);
            // Refetch to get the most accurate state across all levels
            fetchInsights();
        } catch (err: any) {
            setError(`Lỗi cập nhật trạng thái: ${err.message}`);
        }
    };
    
    useEffect(() => {
        fetchInsights();
    }, []); // Fetch only once on mount, then manually via button

    const handleSaveColumns = (newColumns: Set<string>) => {
        setVisibleColumns(Array.from(newColumns));
        setIsColumnModalOpen(false);
    };

    const orderedVisibleColumns = useMemo(() => {
        const visibleSet = new Set(visibleColumns);
        return columnOrder
            .map(key => ALL_COLUMNS.find(c => c.key === key))
            .filter((c): c is typeof ALL_COLUMNS[0] => {
                if (!c || !visibleSet.has(c.key)) return false;
                
                // Rule 1: Hide lower-level names in higher-level views
                if (level === 'campaign' && (c.key === 'adset_name' || c.key === 'ad_name')) return false;
                if (level === 'adset' && c.key === 'ad_name') return false;
    
                // Rule 2: Hide higher-level names in lower-level views
                if (level === 'adset' && c.key === 'campaign_name') return false;
                if (level === 'ad' && (c.key === 'campaign_name' || c.key === 'adset_name')) return false;
                
                return true;
            });
    }, [columnOrder, visibleColumns, level]);
    
    // --- Column Drag & Drop ---
    const draggedItem = useRef<string | null>(null);
    const handleDragStart = (e: React.DragEvent<HTMLTableCellElement>, key: string) => {
        draggedItem.current = key;
        e.dataTransfer.effectAllowed = 'move';
    };
    const handleDragOver = (e: React.DragEvent<HTMLTableCellElement>) => e.preventDefault();
    const handleDrop = (e: React.DragEvent<HTMLTableCellElement>, dropTargetKey: string) => {
        e.preventDefault();
        const draggedKey = draggedItem.current;
        if (!draggedKey || draggedKey === dropTargetKey) return;
        
        const newOrder = [...columnOrder];
        const draggedIndex = newOrder.indexOf(draggedKey);
        const targetIndex = newOrder.indexOf(dropTargetKey);

        if (draggedIndex > -1 && targetIndex > -1) {
            const [removed] = newOrder.splice(draggedIndex, 1);
            newOrder.splice(targetIndex, 0, removed);
            setColumnOrder(newOrder);
        }
        draggedItem.current = null;
    };

    // --- Column Resizing ---
    const resizerState = useRef({ isResizing: false, key: '', startX: 0, startWidth: 0 }).current;
    const handleResizeMouseMove = useCallback((e: MouseEvent) => {
        if (!resizerState.isResizing) return;
        const width = resizerState.startWidth + (e.clientX - resizerState.startX);
        if (width > 50) setColumnWidths(prev => ({ ...prev, [resizerState.key]: width }));
    }, [resizerState, setColumnWidths]);

    const handleResizeMouseUp = useCallback(() => {
        resizerState.isResizing = false;
        document.removeEventListener('mousemove', handleResizeMouseMove);
        document.removeEventListener('mouseup', handleResizeMouseUp);
    }, [resizerState, handleResizeMouseMove]);

    const handleResizeMouseDown = (e: React.MouseEvent, key: string) => {
        e.preventDefault();
        e.stopPropagation();
        resizerState.isResizing = true;
        resizerState.key = key;
        resizerState.startX = e.clientX;
        resizerState.startWidth = (e.target as HTMLElement).closest('th')?.offsetWidth || 150;
        document.addEventListener('mousemove', handleResizeMouseMove);
        document.addEventListener('mouseup', handleResizeMouseUp);
    };

    const renderCellContent = (row: any, col: typeof ALL_COLUMNS[0]) => {
        if (col.extractor) return col.extractor(row);
        return row[col.key] || 'N/A';
    };

    const handleSelectRow = (id: string) => {
        setSelectedIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) newSet.delete(id);
            else newSet.add(id);
            return newSet;
        });
    };

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>, data: any[]) => {
        const idKey = level === 'campaign' ? 'campaign_id' : level === 'adset' ? 'adset_id' : 'ad_id';
        if (e.target.checked) {
            setSelectedIds(new Set(data.map(row => row[idKey])));
        } else {
            setSelectedIds(new Set());
        }
    };
    
    // --- Data Aggregation and Display Logic ---
    const displayedData = useMemo(() => {
        if (insights.length === 0) return [];
    
        const aggregate = (data: Insight[], groupBy: 'campaign_id' | 'adset_id') => {
            const groups = new Map<string, any>();
            for (const insight of data) {
                const key = insight[groupBy];
                if (!key) continue;
    
                if (!groups.has(key)) {
                    groups.set(key, {
                        ...insight,
                        spend: 0, impressions: 0, clicks: 0, reach: 0,
                        results: 0
                    });
                }
    
                const group = groups.get(key);
                group.spend += parseFloat(insight.spend || '0');
                group.impressions += parseInt(insight.impressions || '0', 10);
                group.clicks += parseInt(insight.clicks || '0', 10);
                group.reach += parseInt(insight.reach || '0', 10);
                const result = getPrimaryResult(insight);
                group.results += parseInt(result?.value || '0', 10);
            }
            
            return Array.from(groups.values()).map(group => ({
                ...group,
                ctr: group.impressions > 0 ? (group.clicks / group.impressions) * 100 : 0,
                cpc: group.clicks > 0 ? group.spend / group.clicks : 0,
                cpm: group.impressions > 0 ? (group.spend / group.impressions) * 1000 : 0,
                cost_per_result: group.results > 0 ? group.spend / group.results : 0,
            }));
        };
    
        if (level === 'campaign') return aggregate(insights, 'campaign_id');
        if (level === 'adset') {
            const campaignId = path[0]?.id;
            if (!campaignId) return [];
            const filtered = insights.filter(i => i.campaign_id === campaignId);
            return aggregate(filtered, 'adset_id');
        }
        if (level === 'ad') {
            const adsetId = path[1]?.id;
            if (!adsetId) return [];
            return insights.filter(i => i.adset_id === adsetId);
        }
        return [];
    }, [insights, level, path]);

    const handleBreadcrumbClick = (targetLevel: ReportLevel, index?: number) => {
        setLevel(targetLevel);
        setSelectedIds(new Set());
        if (index !== undefined) {
            setPath(path.slice(0, index + 1));
        } else {
            setPath([]);
        }
    };
    
    const handleDrillDown = (nextLevel: ReportLevel) => {
        if (selectedIds.size === 0) return;
        const currentIdKey = level === 'campaign' ? 'campaign_id' : 'adset_id';
        const currentNameKey = level === 'campaign' ? 'campaign_name' : 'adset_name';

        // For simplicity in this UI, we drill down into the first selected item
        const firstSelectedId = Array.from(selectedIds)[0];
        const selectedItem = displayedData.find(d => d[currentIdKey] === firstSelectedId);
        
        if (selectedItem) {
            setPath([...path, { level: level, id: firstSelectedId, name: selectedItem[currentNameKey] }]);
            setLevel(nextLevel);
            setSelectedIds(new Set());
        }
    };


    const idKey = level === 'campaign' ? 'campaign_id' : level === 'adset' ? 'adset_id' : 'ad_id';
    const isAllSelected = displayedData.length > 0 && selectedIds.size === displayedData.length;

    return (
        <div className="bg-white dark:bg-gray-800 p-4 lg:p-6 flex flex-col h-full text-gray-800 dark:text-gray-200">
            {isColumnModalOpen && (
                <ColumnCustomizer isOpen={isColumnModalOpen} onClose={() => setIsColumnModalOpen(false)} allColumns={ALL_COLUMNS} visibleColumns={new Set(visibleColumns)} onSave={handleSaveColumns} />
            )}
            
            <div className="flex items-center justify-between mb-4 flex-wrap gap-4">
                <div className="flex items-center gap-2 flex-wrap">
                    <DateRangePicker value={dateRange} onChange={setDateRange} />
                    <button onClick={fetchInsights} disabled={loading} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-blue-400 flex items-center justify-center">
                        {loading ? <Spinner /> : 'Tải lại dữ liệu'}
                    </button>
                </div>
                <div className="flex items-center gap-2">
                    <button className="p-2 border rounded-md dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><FilterIcon className="w-5 h-5" /></button>
                    <button onClick={() => setIsColumnModalOpen(true)} className="p-2 border rounded-md dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><SettingsIcon className="w-5 h-5" /></button>
                    <button className="p-2 border rounded-md dark:border-gray-600 flex items-center gap-2 text-sm px-3 hover:bg-gray-100 dark:hover:bg-gray-700">
                        <ExportIcon className="w-5 h-5" /> Export
                    </button>
                </div>
            </div>

            {/* Breadcrumb Navigation */}
            <div className="mb-4 flex items-center gap-1 bg-gray-100 dark:bg-gray-900 p-1 rounded-lg">
                <button onClick={() => handleBreadcrumbClick('campaign')} disabled={loading} className={`flex items-center gap-2 p-2 rounded-md text-sm font-medium ${level === 'campaign' ? 'bg-white dark:bg-gray-700 shadow' : 'hover:bg-gray-200 dark:hover:bg-gray-700/50'}`}>
                    <FolderIcon className={`w-5 h-5 ${level==='campaign' ? 'text-blue-600' : ''}`} /> Chiến dịch
                </button>
                <button onClick={() => handleDrillDown('adset')} disabled={loading || selectedIds.size === 0 || level !== 'campaign'} className={`flex items-center gap-2 p-2 rounded-md text-sm font-medium ${level === 'adset' ? 'bg-white dark:bg-gray-700 shadow' : 'hover:bg-gray-200 dark:hover:bg-gray-700/50'} disabled:opacity-50 disabled:cursor-not-allowed`}>
                    <Squares2X2Icon className={`w-5 h-5 ${level==='adset' ? 'text-blue-600' : ''}`} /> Nhóm quảng cáo {level === 'campaign' && selectedIds.size > 0 && <span className="text-xs bg-blue-500 text-white rounded-full px-2 py-0.5">{selectedIds.size}</span>}
                </button>
                 <button onClick={() => handleDrillDown('ad')} disabled={loading || selectedIds.size === 0 || level !== 'adset'} className={`flex items-center gap-2 p-2 rounded-md text-sm font-medium ${level === 'ad' ? 'bg-white dark:bg-gray-700 shadow' : 'hover:bg-gray-200 dark:hover:bg-gray-700/50'} disabled:opacity-50 disabled:cursor-not-allowed`}>
                    <DocumentIcon className={`w-5 h-5 ${level==='ad' ? 'text-blue-600' : ''}`} /> Quảng cáo {level === 'adset' && selectedIds.size > 0 && <span className="text-xs bg-blue-500 text-white rounded-full px-2 py-0.5">{selectedIds.size}</span>}
                </button>
            </div>
             {path.length > 0 && (
                <div className="text-xs text-gray-500 dark:text-gray-400 mb-2 flex items-center flex-wrap">
                    {path.map((p, i) => (
                        <React.Fragment key={p.id}>
                            <button className="hover:underline" onClick={() => handleBreadcrumbClick(p.level, i)}>{p.name}</button>
                            <span className="mx-1">&gt;</span>
                        </React.Fragment>
                    ))}
                </div>
            )}


             {error && <div className="p-3 bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300 rounded-md mb-4">{error}</div>}

            <div className="flex-1 overflow-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400 table-fixed">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 sticky top-0 z-10">
                        <tr>
                            <th scope="col" className="p-3" style={{ width: '50px' }}><input type="checkbox" onChange={(e) => handleSelectAll(e, displayedData)} checked={isAllSelected} className="rounded border-gray-300 dark:bg-gray-900 dark:border-gray-600" /></th>
                            <th scope="col" className="p-3 whitespace-nowrap" style={{ width: '100px' }}>Nhãn Dán</th>
                            <th scope="col" className="p-3 whitespace-nowrap" style={{ width: '90px' }}>Tắt/Bật</th>
                             {orderedVisibleColumns.map(col => (
                                <th key={col.key} scope="col" className={`p-3 whitespace-nowrap relative ${col.align === 'right' ? 'text-right' : ''}`} style={{ width: columnWidths[col.key] ? `${columnWidths[col.key]}px` : '150px' }} draggable onDragStart={e => handleDragStart(e, col.key)} onDragOver={handleDragOver} onDrop={e => handleDrop(e, col.key)}>
                                    {col.label}
                                    <div onMouseDown={e => handleResizeMouseDown(e, col.key)} className="absolute top-0 right-0 h-full w-2 cursor-col-resize"/>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {loading && displayedData.length === 0 ? (
                             <tr><td colSpan={orderedVisibleColumns.length + 3} className="text-center p-6"><Spinner /></td></tr>
                        ) : displayedData.length === 0 ? (
                            <tr><td colSpan={orderedVisibleColumns.length + 3} className="text-center p-6">Không có dữ liệu cho cấp độ này.</td></tr>
                        ) : (
                            displayedData.map(row => (
                                <tr key={row[idKey]} className={`bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-600 ${selectedIds.has(row[idKey]) ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}>
                                    <td className="p-3"><input type="checkbox" checked={selectedIds.has(row[idKey])} onChange={() => handleSelectRow(row[idKey])} className="rounded border-gray-300 dark:bg-gray-900 dark:border-gray-600" /></td>
                                    <td className="p-3"><button className="text-xs text-blue-600 dark:text-blue-400 hover:underline">Gán nhãn</button></td>
                                    <td className="p-3">
                                        <ToggleSwitch 
                                            checked={row.status === 'ACTIVE'}
                                            onChange={() => handleStatusToggle(row[idKey], row.status)}
                                        />
                                    </td>
                                    {orderedVisibleColumns.map(col => (
                                        <td key={col.key} className={`p-3 whitespace-nowrap overflow-hidden text-ellipsis ${col.align === 'right' ? 'text-right' : ''} ${['_name'].some(s => col.key.includes(s)) ? 'font-medium text-gray-900 dark:text-white' : ''}`}>
                                            {renderCellContent(row, col)}
                                        </td>
                                    ))}
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default CampaignReports;