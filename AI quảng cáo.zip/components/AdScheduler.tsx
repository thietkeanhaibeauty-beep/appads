
import React, { useState, useRef } from 'react';

interface AdSchedulerProps {
  value: Set<string>;
  onChange: (newValue: Set<string>) => void;
}

const daysOfWeek = [
  { label: 'Thứ Hai', key: 1 },
  { label: 'Thứ Ba', key: 2 },
  { label: 'Thứ Tư', key: 3 },
  { label: 'Thứ Năm', key: 4 },
  { label: 'Thứ Sáu', key: 5 },
  { label: 'Thứ Bảy', key: 6 },
  { label: 'Chủ Nhật', key: 0 },
];

const AdScheduler: React.FC<AdSchedulerProps> = ({ value, onChange }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragMode, setDragMode] = useState<'select' | 'deselect' | null>(null);
  const schedulerRef = useRef<HTMLTableElement>(null);

  const handleSelection = (day: number, hour: number, isClick: boolean = false) => {
    const key = `${day}-${hour}`;
    let newMode = dragMode;
    
    // On the first click of a drag, determine if we are selecting or deselecting
    if (isClick && !dragMode) {
      newMode = value.has(key) ? 'deselect' : 'select';
      setDragMode(newMode);
    }
    
    const newSchedule = new Set(value);
    if (newMode === 'select') {
      newSchedule.add(key);
    } else if (newMode === 'deselect') {
      newSchedule.delete(key);
    }
    onChange(newSchedule);
  };
  
  const handleDailySelection = (hour: number, isClick: boolean = false) => {
      let newMode = dragMode;
      const firstKey = `0-${hour}`; // Use Sunday to check status

      if (isClick && !dragMode) {
          newMode = value.has(firstKey) ? 'deselect' : 'select';
          setDragMode(newMode);
      }

      const newSchedule = new Set(value);
      daysOfWeek.forEach(day => {
          const key = `${day.key}-${hour}`;
          if (newMode === 'select') {
              newSchedule.add(key);
          } else if (newMode === 'deselect') {
              newSchedule.delete(key);
          }
      });
      onChange(newSchedule);
  };


  const handleMouseDown = (day: number | 'daily', hour: number) => {
    setIsDragging(true);
    if (day === 'daily') {
        handleDailySelection(hour, true);
    } else {
        handleSelection(day, hour, true);
    }
  };

  const handleMouseEnter = (day: number | 'daily', hour: number) => {
    if (isDragging) {
      if (day === 'daily') {
          handleDailySelection(hour, false);
      } else {
          handleSelection(day, hour, false);
      }
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragMode(null);
  };

  React.useEffect(() => {
    const endDrag = () => handleMouseUp();
    window.addEventListener('mouseup', endDrag);
    return () => window.removeEventListener('mouseup', endDrag);
  }, []);

  return (
    <div className="overflow-x-auto">
      <table 
        ref={schedulerRef}
        className="w-full border-collapse select-none text-xs text-center table-fixed"
        onMouseLeave={handleMouseUp}
      >
        <thead>
          <tr>
            <th className="p-1 border border-gray-200 dark:border-gray-700 w-28"></th>
            {Array.from({ length: 24 }).map((_, i) => (
              <th key={i} className="p-1 border border-gray-200 dark:border-gray-700 font-normal text-gray-500 dark:text-gray-400">
                {i % 3 === 0 ? `${i}h` : ''}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {daysOfWeek.map(({ label, key: dayKey }) => (
            <tr key={dayKey}>
              <td className="p-1 border border-gray-200 dark:border-gray-700 font-medium text-gray-700 dark:text-gray-300">{label}</td>
              {Array.from({ length: 24 }).map((_, hour) => {
                const isSelected = value.has(`${dayKey}-${hour}`);
                return (
                  <td
                    key={hour}
                    onMouseDown={() => handleMouseDown(dayKey, hour)}
                    onMouseEnter={() => handleMouseEnter(dayKey, hour)}
                    className={`p-1 border border-gray-200 dark:border-gray-700 cursor-pointer ${isSelected ? 'bg-blue-500' : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
                  ></td>
                );
              })}
            </tr>
          ))}
          {/* Daily row */}
          <tr>
              <td className="p-1 border border-gray-200 dark:border-gray-700 font-medium text-gray-700 dark:text-gray-300">Hàng ngày</td>
              {Array.from({ length: 24 }).map((_, hour) => {
                 const isSelected = daysOfWeek.every(day => value.has(`${day.key}-${hour}`));
                 return (
                    <td
                      key={`daily-${hour}`}
                      onMouseDown={() => handleMouseDown('daily', hour)}
                      onMouseEnter={() => handleMouseEnter('daily', hour)}
                      className={`p-1 border border-gray-200 dark:border-gray-700 cursor-pointer ${isSelected ? 'bg-blue-400' : 'bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600'}`}
                    ></td>
                 );
              })}
          </tr>
        </tbody>
      </table>
      <div className="flex items-center space-x-4 mt-2 text-xs">
          <div className="flex items-center">
              <span className="w-4 h-4 bg-blue-500 inline-block mr-1 border border-gray-300 dark:border-gray-600"></span>
              <span>Giờ đã lên lịch</span>
          </div>
           <div className="flex items-center">
              <span className="w-4 h-4 bg-gray-100 dark:bg-gray-800 inline-block mr-1 border border-gray-300 dark:border-gray-600"></span>
              <span>Giờ trống</span>
          </div>
      </div>
    </div>
  );
};

export default AdScheduler;
