
import React, { useState, useEffect, useCallback } from 'react';
import { Customer } from '../types';
import * as facebookService from '../services/facebookService';
import * as geminiService from '../services/geminiService';
import CustomerList from './CustomerList';
import ConversationView from './ConversationView';
import useLocalStorage from '../hooks/useLocalStorage';
import Spinner from './Spinner';
import { LogoutIcon, RefreshIcon } from './Icons';

interface PageDashboardProps {
  pageId: string;
  accessToken: string;
  onLogout: () => void;
}

const PageDashboard: React.FC<PageDashboardProps> = ({ pageId, accessToken, onLogout }) => {
  const [customers, setCustomers] = useLocalStorage<Customer[]>('customers', []);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processConversations = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const conversations = await facebookService.getConversations(pageId, accessToken);
      const newCustomers: Customer[] = [];

      // Create a map of existing customers for faster lookup
      const existingCustomerMap = new Map(customers.map(c => [c.id, c]));

      for (const conv of conversations) {
        const participant = conv.participants.data.find(p => p.id !== pageId);
        if (!participant) continue;
        
        // Check if customer already exists and has been processed to avoid re-calling Gemini
        const existingCustomer = existingCustomerMap.get(conv.id);
        if (existingCustomer) {
            newCustomers.push(existingCustomer);
            continue;
        }

        const messages = await facebookService.getMessages(conv.id, accessToken);
        const conversationText = messages.map(m => `${m.from.name}: ${m.message}`).join('\n');
        const phoneNumber = await geminiService.extractPhoneNumber(conversationText);

        newCustomers.push({
          id: conv.id,
          facebookName: participant.name,
          facebookId: participant.id,
          phoneNumber: phoneNumber,
          conversationHistory: messages,
        });
      }
      setCustomers(newCustomers);
    } catch (err: any) {
      setError(err.message || 'An unknown error occurred.');
      if (err.message.includes('token')) {
        onLogout();
      }
    } finally {
      setIsLoading(false);
    }
  }, [pageId, accessToken, setCustomers, onLogout, customers]);

  useEffect(() => {
    if (customers.length === 0) {
      processConversations();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
      if(selectedCustomer) {
          const updatedSelected = customers.find(c => c.id === selectedCustomer.id);
          setSelectedCustomer(updatedSelected || null);
      }
  }, [customers, selectedCustomer]);

  const handleSelectCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      <div className="flex flex-col w-1/3 max-w-sm border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Khách hàng</h1>
          <div className="flex items-center space-x-2">
            <button onClick={processConversations} disabled={isLoading} title="Làm mới danh sách" className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-400 disabled:opacity-50">
                <RefreshIcon className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`}/>
            </button>
            <button onClick={onLogout} title="Đăng xuất" className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-400">
              <LogoutIcon className="w-5 h-5"/>
            </button>
          </div>
        </div>
        {isLoading && customers.length === 0 ? (
          <div className="flex items-center justify-center flex-grow">
            <Spinner />
          </div>
        ) : error ? (
           <div className="p-4 m-4 text-center text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800">
            <p className="font-semibold">Lỗi!</p>
            <p>{error}</p>
          </div>
        ) : (
          <CustomerList
            customers={customers}
            selectedCustomerId={selectedCustomer?.id || null}
            onSelectCustomer={handleSelectCustomer}
          />
        )}
      </div>
      <main className="flex-1">
        <ConversationView customer={selectedCustomer} pageId={pageId} />
      </main>
    </div>
  );
};

export default PageDashboard;