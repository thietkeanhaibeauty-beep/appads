import React, { useState, useEffect } from 'react';
import { Interest } from '../types';
import * as facebookService from '../services/facebookService';
import { CloseIcon, SearchIcon, ExclamationCircleIcon } from './Icons';

interface InterestsSelectorProps {
  adsToken: string;
  selectedInterests: Interest[];
  onInterestsChange: (interests: Interest[]) => void;
}

const InterestsSelector: React.FC<InterestsSelectorProps> = ({ adsToken, selectedInterests, onInterestsChange }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Interest[]>([]);
  const [loading, setLoading] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (query.length < 2) {
      setResults([]);
      setIsDropdownOpen(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);
    const handler = setTimeout(async () => {
      try {
        const searchResults = await facebookService.searchInterests(query, adsToken);
        setResults(searchResults);
        setIsDropdownOpen(true);
      } catch (err: any) {
        console.error("Failed to search for interests:", err);
        setError(err.message || "Lỗi không xác định khi tìm kiếm.");
        setResults([]);
        setIsDropdownOpen(true);
      } finally {
        setLoading(false);
      }
    }, 500); // Debounce API call

    return () => {
      clearTimeout(handler);
    };
  }, [query, adsToken]);

  const addInterest = (interest: Interest) => {
    if (!selectedInterests.some(i => i.id === interest.id)) {
      onInterestsChange([...selectedInterests, interest]);
    }
    setQuery('');
    setResults([]);
    setIsDropdownOpen(false);
    setError(null);
  };

  const removeInterest = (interestId: string) => {
    onInterestsChange(selectedInterests.filter(i => i.id !== interestId));
  };
  
  const renderDropdownContent = () => {
    if (loading) {
      return <li className="px-4 py-2 text-sm text-gray-500">Đang tìm...</li>;
    }
    if (error) {
      return (
        <li className="px-4 py-2 text-sm text-red-600 dark:text-red-400 flex items-center">
          <ExclamationCircleIcon className="w-4 h-4 mr-2 flex-shrink-0" />
          <span>{error}</span>
        </li>
      );
    }
    if (results.length > 0) {
      return results.map(interest => (
        <li
          key={interest.id}
          onMouseDown={() => addInterest(interest)}
          className="px-4 py-2 text-sm cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <p className="font-medium">{interest.name}</p>
          {interest.audience_size && (
             <p className="text-xs text-gray-500">Quy mô: {interest.audience_size.toLocaleString()}</p>
          )}
        </li>
      ));
    }
    if (query.length >= 2) {
        return <li className="px-4 py-2 text-sm text-gray-500">Không tìm thấy kết quả.</li>;
    }
    return null;
  }


  return (
    <div className="relative">
      <div>
        <label htmlFor="interest-search" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Sở thích & Hành vi (Targeting chi tiết)
        </label>
        <p className="text-xs text-gray-500 dark:text-gray-400">Thêm 3-5 sở thích để có kết quả tốt nhất. Có thể bỏ qua.</p>
      </div>
      <div className="relative mt-1">
        <SearchIcon className="pointer-events-none absolute inset-y-0 left-0 h-full w-5 text-gray-400 ml-2" />
        <input
          type="text"
          id="interest-search"
          value={query}
          onChange={e => setQuery(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 pl-9"
          placeholder="Tìm kiếm sở thích, VD: Spa, Thẩm mỹ viện..."
          onFocus={() => (query.length >= 2 || !!error) && setIsDropdownOpen(true)}
          onBlur={() => setTimeout(() => setIsDropdownOpen(false), 200)} // Delay to allow click
        />
      </div>

      {isDropdownOpen && (
        <ul className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto">
          {renderDropdownContent()}
        </ul>
      )}

      <div className="flex flex-wrap gap-2 mt-2 min-h-[24px]">
        {selectedInterests.map(interest => (
          <span key={interest.id} className="inline-flex items-center px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-medium rounded-full">
            {interest.name}
            <button
              type="button" // prevent form submission
              onClick={() => removeInterest(interest.id)}
              className="ml-2 text-blue-500 hover:text-blue-700"
            >
              <CloseIcon className="w-3 h-3" />
            </button>
          </span>
        ))}
      </div>
    </div>
  );
};

export default InterestsSelector;