
import React, { useCallback } from 'react';
import useLocalStorage from './hooks/useLocalStorage';
import { AdAccount } from './types';

// Import components
import ModeSelector from './components/ModeSelector';
import PageDashboard from './components/Dashboard';
import AdAccountSelector from './components/AdAccountSelector';
import AdsDashboard from './components/AdsDashboard';
import AiChatWidget from './components/AiChatWidget';

type AppMode = 'page_flow' | 'ads_flow';

// Hardcoded values as per user request
const DEFAULT_PAGE_ID = '159211580792822';
const DEFAULT_PAGE_TOKEN = 'EAAPybbjh7bYBPUYcXoCsggbfLJpf8lJ8pkYrQGxx3dCnZBLm47JCOZBcf7uh15ayjqHHKACZC9rtakZCC4j87iDWjM1I88o7FQn6Dt4vcxiNZAZCbeqVah4zDoiML26sdF233I25PVFJHbwN8L5ppRNrRszEMsouOFUDLV39KZBiz3CH9TOPQ6bMnE8IzYUkOpDC8RJesT6JlB9XaSc9aZAn6bwZD';
const DEFAULT_ADS_TOKEN = 'EAAVVRSZBo9ngBPSAfYAPWLnJlz5qomU5RftqOciQOP0mY65AUZCMvZAqZCXx86EvooZAKblqON5ve5EfHKCwrXawsmsU5ZByTZC0JrjkU1uBEbALhUD8ZCeS9cZAn89Kdk6yPv3an89jVZB86YWVP2aQXvrv41bSKdFFF4esR50RTTEplXJOHuZAsF6uZCUF2rUUZAedTyZBlcs7yZCO3ZBvyEAw';
const DEFAULT_AD_ACCOUNT: AdAccount = {
  id: 'act_1391302155119266',
  name: 'Tài khoản quảng cáo mặc định',
  business_name: 'Doanh nghiệp mặc định',
  account_status: 1,
  currency: 'VND',
  timezone_name: 'Asia/Ho_Chi_Minh'
};

const App: React.FC = () => {
  // Default to 'ads_flow' mode, login/selection is skipped.
  const [mode, setMode] = useLocalStorage<AppMode>('app_mode', 'ads_flow');

  // Centralized credentials from localStorage, now with hardcoded defaults
  const [pageId] = useLocalStorage<string | null>('fb_page_id', DEFAULT_PAGE_ID);
  const [pageAccessToken] = useLocalStorage<string | null>('fb_page_access_token', DEFAULT_PAGE_TOKEN);
  const [adsToken] = useLocalStorage<string | null>('fb_ads_token', DEFAULT_ADS_TOKEN);
  const [selectedAdAccount, setSelectedAdAccount] = useLocalStorage<AdAccount | null>('selected_ad_account', DEFAULT_AD_ACCOUNT);
  
  const handleAdsLogout = useCallback(() => {
    // Logout is disabled in this configuration.
  }, []);

  const handleBackToAccountSelection = useCallback(() => {
    // Back action is disabled in this configuration.
  }, []);

  const renderContent = () => {
    // The logic will always fall into the ads_flow case because mode and selectedAdAccount are pre-filled.
    if (mode === 'page_flow') {
      if (pageId && pageAccessToken) {
        // Fallback in case user manually changes mode in local storage
        return <PageDashboard pageId={pageId} accessToken={pageAccessToken} onLogout={() => setMode('ads_flow')} />;
      }
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <h2 className="text-xl font-semibold">Thiếu thông tin Page</h2>
            <p className="mt-2 text-gray-600 dark:text-gray-400">Thông tin Page đã được cấu hình sẵn.</p>
        </div>
      );
    }

    if (mode === 'ads_flow') {
      if (!adsToken) {
         return (
            <div className="flex flex-col items-center justify-center h-full text-center p-4">
                <h2 className="text-xl font-semibold">Thiếu thông tin Quảng cáo</h2>
                <p className="mt-2 text-gray-600 dark:text-gray-400">Thông tin quảng cáo đã được cấu hình sẵn.</p>
            </div>
         );
      }
      if (!selectedAdAccount) {
        // This case is unlikely to be hit due to the default value.
        return <AdAccountSelector adsAccessToken={adsToken} onAccountSelect={setSelectedAdAccount} onLogout={handleAdsLogout} />;
      }
      return <AdsDashboard 
                selectedAccount={selectedAdAccount} 
                adsToken={adsToken}
                pageAccessToken={pageAccessToken} 
                onLogout={handleAdsLogout} 
                onBack={handleBackToAccountSelection} 
             />;
    }
    
    // This mode is effectively removed by setting the default to 'ads_flow'.
    return <ModeSelector onSelectMode={setMode} />;
  };

  return (
    <div className="h-screen font-sans grid grid-cols-2 gap-4 p-4 bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="col-span-1 flex flex-col rounded-lg shadow-lg overflow-hidden">
        {renderContent()}
      </div>
      <div className="col-span-1 bg-white dark:bg-gray-800 rounded-lg shadow-lg flex flex-col">
        <AiChatWidget 
          adsToken={adsToken} 
          pageId={pageId} 
          pageAccessToken={pageAccessToken} 
          selectedAdAccount={selectedAdAccount}
        />
      </div>
    </div>
  );
};

export default App;
