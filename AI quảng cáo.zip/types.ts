
export interface Message {
  id: string;
  created_time: string;
  from: {
    name: string;
    id: string;
  };
  message: string;
}

export interface Conversation {
  id:string;
  participants: {
    data: {
      name: string;
      id: string;
    }[];
  };
}

export interface Customer {
  id: string;
  facebookName: string;
  facebookId: string;
  phoneNumber: string | null;
  conversationHistory: Message[];
}

export interface AdAccount {
  id: string; // e.g. "act_123456789"
  name: string;
  business_name?: string;
  account_status: number; // 1: ACTIVE, 2: DISABLED, ...
  currency?: string;
  timezone_name?: string;
}

export interface Page {
    id: string;
    name: string;
    access_token: string;
}

export type Gender = 'all' | 'male' | 'female';

export interface Country {
    key: string;
    name: string;
}

export interface City {
    key: string;
    name: string;
    region?: string;
    country_code?: string;
}

export interface GeoLocationTargeting {
    countries?: string[];
    cities?: { key: string; radius: number; distance_unit: 'kilometer' }[];
    custom_locations?: { latitude: number; longitude: number; radius: number; distance_unit: 'kilometer' }[];
}

export interface ReachEstimate {
    users: number;
    estimate_ready: boolean;
}

export interface PostPreview {
    message: string;
    full_picture?: string;
    permalink_url: string;
}

export interface PostValidationResult {
    status: 'idle' | 'loading' | 'success' | 'error';
    message: string | null;
    preview?: PostPreview | null;
}

export interface Interest {
    id: string;
    name: string;
    audience_size?: number;
    path?: string[];
}

// NEW: Type for campaign objectives
export type CampaignObjective = 'OUTCOME_TRAFFIC' | 'OUTCOME_ENGAGEMENT' | 'MESSAGES' | 'LEAD_GENERATION';

// NEW: Types for Message Templates
export interface IceBreaker {
    question: string;
    payload?: string;
}

export type GreetingType = 'text_only' | 'text_image' | 'text_video';
export type IceBreakerType = 'custom' | 'business_suite' | 'none';

export interface MessageTemplate {
    name: string;
    greetingType: GreetingType;
    greetingText: string;
    greetingMediaId: string | null;
    iceBreakers: IceBreaker[];
}

// NEW: Type for AI-generated campaign drafts
export interface CampaignDraft {
  campaignName: string;
  objective: CampaignObjective;
  dailyBudget: string;
  ageMin: string;
  ageMax: string;
  gender: Gender;
  location: Country;
  interests: Interest[];
}

// NEW: Ad Schedule type
export interface AdScheduleItem {
    day: number; // 0=Sun, 1=Mon, ..., 6=Sat
    start_minute: number;
    end_minute: number;
}

export interface CustomAudience {
  id: string;
  name: string;
}

export interface Insight {
  // Always present for logic
  campaign_id: string;
  adset_id: string;
  ad_id: string;

  // Optional fields based on user selection
  date_start?: string;
  date_stop?: string;

  campaign_name?: string;
  adset_name?: string;
  ad_name?: string;

  objective?: string;

  status?: 'ACTIVE' | 'PAUSED' | 'ARCHIVED' | 'DELETED';
  budget?: string;

  spend?: string;
  impressions?: string;
  reach?: string;
  frequency?: string;
  
  clicks?: string;
  ctr?: string;
  cpc?: string;
  cpm?: string;
  cpp?: string;

  unique_clicks?: string;
  cost_per_unique_click?: string;

  actions?: { action_type: string; value: string }[];
  cost_per_action_type?: { action_type: string; value: string }[];

  video_play_actions?: { action_type: 'video_view', value: string }[];
  video_p25_watched_actions?: { action_type: 'video_view', value: string }[];
  video_p50_watched_actions?: { action_type: 'video_view', value: string }[];
  video_p75_watched_actions?: { action_type: 'video_view', value: string }[];
  video_p100_watched_actions?: { action_type: 'video_view', value: string }[];
  video_thruplay_watched_actions?: { action_type: 'video_view', value: string }[];
  cost_per_thruplay?: { action_type: 'video_view', value: string }[];
  
  action_values?: { action_type: string; value: string }[];
  website_purchase_roas?: { action_type: 'purchase'; value: string }[];

  quality_ranking?: 'AVERAGE' | 'ABOVE_AVERAGE' | 'BELOW_AVERAGE' | 'BELOW_AVERAGE_10' | 'BELOW_AVERAGE_20' | 'BELOW_AVERAGE_35';
  engagement_rate_ranking?: 'AVERAGE' | 'ABOVE_AVERAGE' | 'BELOW_AVERAGE' | 'BELOW_AVERAGE_10' | 'BELOW_AVERAGE_20' | 'BELOW_AVERAGE_35';
  conversion_rate_ranking?: 'AVERAGE' | 'ABOVE_AVERAGE' | 'BELOW_AVERAGE' | 'BELOW_AVERAGE_10' | 'BELOW_AVERAGE_20' | 'BELOW_AVERAGE_35';
}